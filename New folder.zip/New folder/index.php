<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clapstart</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
       rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
       rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/sections/clapstart/js/header.js"></script>
    <link href="/sections/clapstart/css/header.css"
       rel="stylesheet">
    <link href="/sections/clapstart/css/footer.css"
       rel="stylesheet">
    <style>
        body{
    margin: 0;
    padding: 0;
    font-family: 'Lato', sans-serif;
    }
    .main {
    width: 100%;
    display: block;
    margin-top:70px
}
.hero {
    background: #fff6de;
    width: 100%;
    height: 600px;
    display: flex;
    align-items: center;
    justify-content: space-evenly;
}
.hero_left {
    width: 40%;
}
.hero_tag {
    font-size: 30px;
    font-weight: 800;
    color: #172B4D;
}
.hero_desc {
    font-size: 15px;
    font-weight: 500;
    color: #172B4D;
    margin-top: 20px;
}
.hero_btn {
    padding: 10px;
    background: #0C66E4;
    color: white;
    font-size: 15px;
    font-weight: 600;
    width: fit-content;
    border-radius: 3px;
    margin-top: 20px;
}

.hero_right img {
    width: 400px;
}
.world {
    width: 700px;
    margin: 10px auto;
    display: block;
    margin-top: 60px;
}
.what_title {
    font-size: 30px;
    font-weight: 800;
    color: #172B4D;
    display: block;
    text-align: center;
}
.what_ans {
    font-size: 15px;
    font-weight: 500;
    color: #172B4D;
    width: 50%;
    display: block;
    margin: 10px auto;
    margin-top: 20px;
}
.products {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-evenly;
    margin-top: 50px;
    margin-bottom: 60px;
    flex-wrap:wrap
}

.product {
    width: 300px;
    padding: 15px;
    border: 1px solid #091E4224;
    border-radius: 5px;
    background:white;
    margin-top:20px
}

.product_title {
    font-size: 25px;
    font-weight: 800;
    color: #0c66e4;
}

.product_desc {
    font-size: 13px;
    font-weight: 500;
    color: #172B4D;
    display: block;
    margin-top: 20px;
}

.product_features {
    border-top: 1px solid #091E4224;
    margin-top: 20px;
    padding-top: 20px;
}

.product_feature_title {
    font-size: 15px;
    font-weight: 600;
    color: #44546F;
    margin-bottom: 10px;
}

.product_feature {
    display: flex;
    align-items: center;
    font-size: 12px;
    font-weight: 600;
    margin-left: 10px;
    margin-top: 10px;
    color: #172B4D;
}

.product_feature span {
    font-size: 20px;
    margin-right: 10px;
    color: #0c66e4;
}
.product_btn {
    display: flex;
    align-items: center;
    margin-right: 20px;
    padding: 6px 10px;
    border-radius: 2px;
    font-size: 14px;
    font-weight: 600;
    color: white;
    background: #0c66e4;
    cursor: pointer;
    margin-top: 20px;
    margin-bottom: 10px;
}
.allinone {
    background: #e2ffe7;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    padding: 50px 0;
}
.allinone_left {
    width: 40%;
    min-width:300px
}
.allinone_left img {
    width: 100%;
}
.allinone_right {
    width: 40%;
    min-width: 280px;
}

.allinone_title {
    font-size: 30px;
    font-weight: 800;
    color: #172B4D;
    white-space: pre-line;
}

.allinone_desc {
    font-size: 15px;
    font-weight: 500;
    color: #172B4D;
}
.getstarted {
    margin: 100px 0;
    display: block;
    text-align: center;
}

.getstarted_title {
    font-size: 30px;
    font-weight: 800;
    color: #172B4D;
}

.getstarted_desc {
    font-size: 15px;
    font-weight: 500;
    color: #172B4D;
    width: 50%;
    margin: 10px auto;
}

.getstarted_btn {padding: 10px;background: #0C66E4;color: white;font-size: 15px;font-weight: 600;width: fit-content;border-radius: 3px;margin: 10px auto;margin-top: 20px;}



@media screen and (max-width: 768px) {
    .hero{
        flex-wrap: wrap-reverse;
    }
    .hero_left {
    width: 40%;
    min-width: 300px;
}
    .world{
        width:90%
    }
    .hero_tag {
    font-size: 25px;
}
.hero_desc {
    font-size: 13px;
}
.getstarted_title {
    padding: 0 20px;
}
.hero_btn {
    font-size: 13px;
}
.hero_right img {
    width: 300px;
}
.what_ans {
    width: 90%;
    font-size:13px
}
.getstarted_title {
    font-size: 25px;
}
.getstarted_desc {
    font-size: 13px;
    width: 80%;
}
.getstarted_btn {
    font-size: 13px;
}
}

    </style>
</head>
<body>
    <?php
include_once("./sections/clapstart/header.php") 
    ?>
    <div class="main">
        <div class="hero">
            <div class="hero_left">
                <div class="hero_tag">Unlocking the Power of Collaboration</div>
                <div class="hero_desc">Our company provides innovative tools and platforms that enable businesses to connect, collaborate, and optimize their workflow for enhanced productivity and success.</div>
                <div  onclick="location.href = '/create-account';" class="hero_btn">Create account for free</div>
            </div>
            <div class="hero_right">
                <img src="/assets/work.svg">
            </div>
        </div>

    <img class="world" src="/assets/world.svg">

    <div class="what">
        <div class="what_title">What is clapstart?</div>
        <div class="what_ans">Clapstart is a SaaS company that offers a range of services to businesses, teams, and individuals. They currently provide a project management tool called Street and are preparing to launch a CRM (Customer Relationship Management) product soon. With their suite of tools, Clapstart aims to assist users in managing their projects effectively and streamlining customer interactions.</div>
    </div>

    <div class="products">
        <div class="product">
            <div class="product_title">Street</div>
            <div class="product_desc">Marketing software to help you grow traffic, convert more visitors, and run complete inbound marketing campaigns at scale.</div>
            <div class="product_features">
                <div class="product_feature_title">Popular feature</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Easy customization</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Communication</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Workspaces</div>
            </div>
            <div  onclick="location.href = '/products/street';" class="product_btn">Try now</div>
        </div>
        <div class="product">
            <div class="product_title">CRM</div>
            <div class="product_desc">Marketing software to help you grow traffic, convert more visitors, and run complete inbound marketing campaigns at scale.</div>
            <div class="product_features">
                <div class="product_feature_title">Popular feature</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Easy customization</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Communication</div>
                <div class="product_feature"><span class="material-icons">check_circle</span>Workspaces</div>
            </div>
            <div class="product_btn">Coming soon</div>
        </div>
    </div>

    <div class="allinone">
        <div class="allinone_left">
            <img src="/assets/connect.svg">
        </div>
        <div class="allinone_right">
            <div class="allinone_title">Connect and collaborate</div>
            <div class="allinone_desc">Our company provides innovative tools and platforms that enable businesses to connect, collaborate, and optimize their workflow for enhanced productivity and success.</div>
        </div>
    </div>

    <div class="getstarted">
        <div class="getstarted_title">Grow Better With HubSpot Today</div>
        <div class="getstarted_desc">With tools to make every part of your process more human and a support team excited to help you, getting started with HubSpot has never been easier.</div>
        <div onclick="location.href = '/create-account';" class="getstarted_btn">Get started free</div>
    </div>

</div>


<?php
include_once("./sections/clapstart/footer.php") 
    ?>

</body>
</html>