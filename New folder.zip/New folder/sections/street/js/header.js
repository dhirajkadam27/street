$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
  });
  $(document).ready(function() {
  $('body').keydown(function(event) {
    if (event.keyCode === 191) { // 191 is the key code for the slash (/) key
      event.preventDefault(); // Prevent the slash character from being entered into the input
      $('#src').focus(); // Activate the input field
    }
  });

  $('#src').keyup(function() {
if ($('#src').is(':focus')) {
$('#src').width("250px");
console.log('Input is currently in focus');
}
});
});

function theme(theme){
  $.ajax({
url: "http://localhost/api/street/theme.php",
type: "POST",
data: { theme: theme },
dataType: "json",
success: function(response) {
location.reload();
},
error: function(xhr, status, error) {
console.log(error);
}
});

}