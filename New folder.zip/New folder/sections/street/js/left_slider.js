function slider_close(){
    if($('#left_slider_01').width()>100){
        $('#left_slider_01').width(20);
        $('#workspaces').hide();
        $('#projects').hide();
    }else{
        $('#left_slider_01').width(250);
        setTimeout(function() {
            $('#workspaces').show();
            $('#projects').show();
          }, 800);
    }
}

function collapse(id){
    console.log($(id)[0].firstChild.innerHTML);
    if($(id)[0].getAttribute('aria-expanded')=="false"){
        $(id)[0].firstChild.innerHTML = "arrow_right";
}else{
    $(id)[0].firstChild.innerHTML = "arrow_drop_down";
}
}


function collapse_workspace(id){
    console.log($($(id)[0]).find('span')[0].innerHTML);
    if($(id)[0].getAttribute('aria-expanded')=="false"){
        $($(id)[0]).find('span')[0].innerHTML = "navigate_next";
}else{
    $($(id)[0]).find('span')[0].innerHTML = "expand_more";
}
}
