<?php

if (!isset($_SESSION['user_id'])) {
  header('Location: ../../login');
  exit();
}
$lite = true; 

if (isset($_SESSION['theme'])) {
   if($_SESSION['theme']=="dark"){
    $lite = false; 
   }

}

function getInitials($name) {
   $words = explode(" ", $name);  // Split the name into individual words
   $initials = "";

   foreach ($words as $word) {
       $initials .= strtoupper(substr($word, 0, 1));  // Append the first letter of each word to the initials string
   }

   if (count($words) > 1) {
       $initials = substr($initials, 0, 2);  // Keep only the first two initials if there are more than one word
   }

   return $initials;
}

?>
<style>
.nav_02 {
    width: 100%;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: white;
        <?php echo ($lite) ? 'border-bottom: 1px solid #091E4224;' : 'border-bottom: 1px solid #A6C5E229;' ?>
    <?php echo ($lite) ? 'background: white;' : 'background: #1d2125;' ?>
    padding: 0 20px;
    position: fixed;
    top: 0;
    left: 0;
    z-index:10
}
    .nav_02_left {
    display: flex;
    align-items: center;
    }
    .nav_02_left_logo {
    font-size: 20px;
    font-weight: 700;
    color: #0c66e4;
}

.nav_02_left_links {display: flex;align-items: center;margin-left: 20px;margin-right: 15px;}


.nav_02_left_link_border {
    margin: 0px 10px;
    height: 54px;
    border-bottom: 3px solid #ffffff00;
    display: flex;
    align-items: center;
}
.nav_02_left_link_border_active {
    margin: 0px 10px;
    height: 54px;
    border-bottom: 3px solid #0c66e4;
    display: flex;
    align-items: center;
}
.nav_02_left_linK {
    display: flex;
    align-items: center;
    <?php echo ($lite) ? 'color: #44546F;' : 'color: #B6C2CF;' ?>
    padding: 5px 7px;
    border-radius: 3px;
    cursor: pointer;
}
.nav_02_left_linK:hover {
    <?php echo ($lite) ? 'background: #091E4224;' : 'background: #A6C5E229;' ?>
}
 .nav_02 .dropdown-menu{
        width: 250px;
        <?php echo ($lite) ? 'background: white;' : 'background: #22272b;' ?>
        <?php echo ($lite) ? 'border: 1px solid #091E4224;' : 'border: 1px solid #A6C5E229;' ?>
      }
       .dropdown_title {
    font-size: 10px;
    font-weight: 900;
    margin-top: 10px;
    margin-bottom: 10px;
    margin-left: 10px;
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
.nav_02 .dropdown_link {
    display: flex;
    align-items: center;
    padding: 10px;
    cursor: pointer;
}
.nav_02 .dropdown_link:hover {
    <?php echo ($lite) ? 'background: #091E4224;' : 'background: #A6C5E229;' ?>
}

.nav_02 .dropdown_logo{
    width: 30px;
    height: 30px;
    background: #ffac73;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 700;
    border-radius: 2px;
}
.nav_02 .dropdown_text {
    font-size: 13px;
    font-weight: 600;
    margin-left: 10px;
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
.nav_02_left_btn {
    background: #0c66e4;
    color: white;
    font-size: 15px;
    padding: 5px 7px;
    border-radius: 2px;
    cursor: pointer;
}
   
.nav_02_right {
        display: flex;
        align-items: center;
      }

      .nav_02_right_src {
        display: flex;
        align-items: center;
        padding: 5px 5px;
        <?php echo ($lite) ? 'border: 2px solid #091E4224;' : 'border: 2px solid #A6C5E229;' ?>
        border-radius: 5px;
        <?php echo ($lite) ? 'background: white;' : 'background: #22272b;' ?>
      }

      .nav_02_right_src input {
        width: 150px;
        font-size: 15px;
        font-family: 'Lato', sans-serif;
        font-weight: 500;
        border: none;
    <?php echo ($lite) ? 'color: #44546F;' : 'color: #B6C2CF;' ?>
        outline: none;
        margin-top: -2px;
        transition: width 1s;
        <?php echo ($lite) ? 'background: white;' : 'background: #22272b;' ?>
      }

      .nav_02_right_src_icon {
    display: flex;
    align-items: center;
}

      .nav_02_right_src .material-icons {
        font-size: 20px;
    <?php echo ($lite) ? 'color: #44546F;' : 'color: #B6C2CF;' ?>
      }

      .nav_02_right_notification {
    margin-left: 10px;
    border-radius: 100px;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
}

      .nav_02_right_notification:hover {
    <?php echo ($lite) ? 'background: #091E4224;' : 'background: #A6C5E229;' ?>
      }

      .nav_02_right_notification .material-icons {
        font-size: 25px;
    <?php echo ($lite) ? 'color: #44546F;' : 'color: #B6C2CF;' ?>
      }

      .nav_02_right_color_mode {
    margin-left: 10px;
    border-radius: 100px;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
      }

      .nav_02_right_color_mode:hover {
    <?php echo ($lite) ? 'background: #091E4224;' : 'background: #A6C5E229;' ?>
      }

      .nav_02_right_color_mode .material-icons {
        font-size: 25px;
    <?php echo ($lite) ? 'color: #44546F;' : 'color: #B6C2CF;' ?>
      }

      
      .nav_02_right_account {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        background: #ffb939;
        border-radius: 100px;
        font-weight: 600;
        margin-left: 10px;
      }

      .nav_02_right .dropdown-menu{
        right: 0;
        left: auto;
        <?php echo ($lite) ? 'background: white;' : 'background: #22272b;' ?>
        <?php echo ($lite) ? 'border: 1px solid #091E4224;' : 'border: 1px solid #A6C5E229;' ?>
      }

.nav_02_right_dropdown_link {
    display: flex;
    align-items: center;
    padding: 10px;
}
.nav_02_right_dropdown_link:hover {
    background: #44546f3b;
}

.nav_02_right_dropdown_text {
    font-size: 13px;
    font-weight: 600;
    margin-left: 10px;
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}

#notifications{
    <?php echo ($lite) ? 'background: white;' : 'background: #1d2125;' ?>
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
#notifications .btn-close{
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
#create{
    <?php echo ($lite) ? 'background: white;' : 'background: #1d2125;' ?>
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
#create .btn-close{
    <?php echo ($lite) ? 'color: #172B4D;' : 'color: #B6C2CF;' ?>
}
#create .nav_02_left_linK{
  margin-top:20px
}

  </style>


    <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="notifications" aria-labelledby="offcanvasWithBothOptionsLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Notifications</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <p>Try scrolling the rest of the page to see this option in action.</p>
        </div>
      </div>

      <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="create" aria-labelledby="offcanvasWithBothOptionsLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Create</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
             <div class="nav_02_left_linK">Create a new project</div>
             <div class="nav_02_left_linK">Create a new task</div>
             <div class="nav_02_left_linK">Send a message</div>
             <div class="nav_02_left_linK">Create a new workspace</div>
        </div>
      </div>


    <div class="nav_02">
        <div class="nav_02_left">
            <div class="nav_02_left_logo">Street</div>
       
        <div class="nav_02_left_links">
            <div class="<?php echo ($_SERVER['PHP_SELF']=='/street/index.php') ?  'nav_02_left_link_border_active' : 'nav_02_left_link_border'?>">
                <div onclick="location.href='/street/'" class="nav_02_left_linK">Home</div>
            </div>
            <div class="<?php echo ($_SERVER['PHP_SELF']=='/street/inbox.php') ?  'nav_02_left_link_border_active' : 'nav_02_left_link_border'?>">
                <div onclick="location.href='/street/inbox.php'" class="nav_02_left_linK">Inbox</div>
            </div>
            <div class="dropdown">
                <div data-bs-toggle="dropdown" aria-expanded="false" class="nav_02_left_link_border">
                <div class="nav_02_left_linK">Recent<span class="material-icons-outlined">expand_more</span></div>
                </div>
                <div class="dropdown-menu">
                    <div class="dropdown_title">YOUR WORKSPACES</div>
                    <div class="dropdown_link">
                      <div class="dropdown_logo">W</div>
                      <div class="dropdown_text">Workspace 1</div>
                    </div>
                    <div class="dropdown_link">
                      <div class="dropdown_logo">W</div>
                      <div class="dropdown_text">Workspace 1</div>
                    </div>
                </div>
             </div>
        </div>
        <div class="nav_02_left_btns">
            <div class="nav_02_left_btn_border">
                <div data-bs-toggle="offcanvas" data-bs-target="#create" aria-controls="offcanvasWithBothOptions" class="nav_02_left_btn">Create</div>
            </div>
        </div>
    </div>
        <div class="nav_02_right">
            
        <div data-toggle="tooltip" data-placement="bottom" title="Search &nbsp; /" class="nav_02_right_src">
            <div class="nav_02_right_src_icon">
              <span class="material-icons"> search </span>
            </div>
            <input placeholder="search" id="src" type="text" class="nav_02_right_src_input">
          </div>
          <div data-toggle="tooltip" data-placement="bottom" title="Notifications" class="nav_02_right_notification" data-bs-toggle="offcanvas" data-bs-target="#notifications" aria-controls="offcanvasWithBothOptions">
            <span class="material-icons"> notifications </span>
          </div>
          <div data-toggle="tooltip" data-placement="bottom" title="Theme" class="nav_02_right_color_mode">
            
          <?php
            if (isset($_SESSION['theme'])) {
   if($_SESSION['theme']=="dark"){
    echo '<span onclick="theme('."'".'light'."'".')" class="material-icons"> light_mode</span>';
   }else{
    echo '<span onclick="theme('."'".'dark'."'".')" class="material-icons"> dark_mode</span>';
   }

  }else{
    echo '<span onclick="theme('."'".'dark'."'".')" class="material-icons"> dark_mode</span>';
   }
   ?> 
          
          </div>
  
          <div class="dropdown">
            <div class="nav_02_right_account" data-bs-toggle="dropdown" aria-expanded="false"><?php echo getInitials($_SESSION['name']); ?>
            </div>
            <div class="dropdown-menu">
                
                <div class="nav_02_right_dropdown_link">
                  <div class="nav_02_right_dropdown_text">Profile</div>
                </div>
                <div class="nav_02_right_dropdown_link">
                  <div class="nav_02_right_dropdown_text">Activity</div>
                </div>
                <div class="nav_02_right_dropdown_link">
                  <div class="nav_02_right_dropdown_text">Setting</div>
                </div>
                <div class="nav_02_right_dropdown_link">
                  <div onclick="location.href='/api/account/logout'" class="nav_02_right_dropdown_text">Logout</div>
                </div>
  
            </div>
          </div>

        </div>
    </div>

