        <div id="left_slider_01"  class="left_slider_01">
            
            <button onclick="slider_close()" class="slider">
                <span class="material-icons">
                    keyboard_double_arrow_left
                    </span>
            </button>

            <div id="projects" class="projects">
                <div class="projects_title"> <div class="projects_title_txt" onclick="collapse(this)" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"><span class="material-icons">arrow_drop_down</span>Projects</div> <span class="material-icons add_project">add</span></div>
                <div class="collapse show" id="collapseExample">
                    <div class="card card-body">
                        <div class="project">Project name</div>
                        <div class="project">Project name</div>
                    </div>
                  </div>
            </div>
            <div id="workspaces" class="workspaces">
                <div class="workspaces_title"> <div class="workspaces_title_txt" onclick="collapse(this)" data-bs-toggle="collapse" data-bs-target="#collapseExample1" aria-expanded="false" aria-controls="collapseExample"><span class="material-icons">arrow_drop_down</span>Workspaces</div> <span class="material-icons add_workspace">add</span></div>
                <div class="collapse show" id="collapseExample1">
                    <div class="card card-body">
                        <div class="workspace" onclick="collapse_workspace(this)" data-bs-toggle="collapse" data-bs-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample">Workspace name<span class="material-icons">navigate_next</span></div>
                        <div class="collapse" id="collapseExample2">
                            <div class="card card-body">
                                <div class="project">Project name</div>
                                <div class="project">Project name</div>
                            </div>
                          </div>

                        <div class="workspace" onclick="collapse_workspace(this)" data-bs-toggle="collapse" data-bs-target="#collapseExample3" aria-expanded="false" aria-controls="collapseExample">Workspace name<span class="material-icons">navigate_next</span></div>
                        <div class="collapse" id="collapseExample3">
                            <div class="card card-body">
                                <div class="project">Project name</div>
                                <div class="project">Project name</div>
                            </div>
                          </div>
                        <div class="workspace" onclick="collapse_workspace(this)" data-bs-toggle="collapse" data-bs-target="#collapseExample4" aria-expanded="false" aria-controls="collapseExample">Workspace name<span class="material-icons">navigate_next</span></div>
                        <div class="collapse" id="collapseExample4">
                            <div class="card card-body">
                                <div class="project">Project name</div>
                                <div class="project">Project name</div>
                            </div>
                          </div>
                    </div>
                  </div>
            </div>
        </div>
