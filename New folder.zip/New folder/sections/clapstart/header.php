<div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
         <div class="offcanvas-header">
            <div class="nav_01_left_logo">Clapstart</div>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
            <div class="nav_01_left_link" onclick="team_btn(this)"  data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Prodcuts<span class="material-icons-outlined">expand_more</span></div>
            <div id="collapseExample" class="collapse">
               <div onclick="location.href = '/products/street';"  class="nav_01_left_link">Street</div>
               <div class="nav_01_left_link">CRM (comming soon)</div>
            </div>
            <div class="nav_01_left_link">Pricing</div>
            <div class="nav_01_left_link" onclick="team_btn(this)"  data-bs-toggle="collapse" data-bs-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample2">Prodcuts<span class="material-icons-outlined">expand_more</span></div>
            <div id="collapseExample2" class="collapse">
               <div class="nav_01_left_link">About us</div>
               <div class="nav_01_left_link">Career</div>
               <div class="nav_01_left_link">Contact us</div>
            </div>
            
            <?php

if (isset($_SESSION['user_id'])) {
   echo '<div class="offcanvas_btn">Go to dashboard</div>
   <div onclick="location.href='."'".'/api/account/logout'."'".'" class="offcanvas_btn_2">Logout</div>';
 }else{
echo '<div onclick="location.href = '."'".'/login'."'".'"  class="offcanvas_btn">Login</div>
<div onclick="location.href = '."'".'/create-account'."'".'"  class="offcanvas_btn_2">Get started free</div>';
 }

?>
            

           

         </div>
      </div>
      <div class="nav_01">
         <div class="nav_01_left">
            <div onclick="location.href='/'" class="nav_01_left_logo">Clapstart</div>
            <div class="nav_01_left_links">
               <div class="dropdown">
                  <div class="nav_01_left_link" data-bs-toggle="dropdown" aria-expanded="false">Products<span class="material-icons-outlined">expand_more</span></div>
                  <div class="dropdown-menu">
                     <div onclick="location.href = '/products/street';" class="nav_01_left_link">Street</div>
                     <div class="nav_01_left_link">CRM (comming soon)</div>
                  </div>
               </div>
               <div class="nav_01_left_link">Pricing</div>
               <div class="dropdown">
                  <div class="nav_01_left_link" data-bs-toggle="dropdown" aria-expanded="false">Resources<span class="material-icons-outlined">expand_more</span></div>
                  <div class="dropdown-menu">
                     <div class="nav_01_left_link">About us</div>
                     <div class="nav_01_left_link">Career</div>
                     <div class="nav_01_left_link">Contact us</div>
                  </div>
               </div>
            </div>
         </div>
         <div class="nav_01_right">
            <div class="nav_01_right_btns">

            

            <?php

if (isset($_SESSION['user_id'])) {
   echo '<div class="nav_01_right_btn_4">Dashboard</div>
   <div class="dropdown">
                  <div class="nav_01_right_btn_3" data-bs-toggle="dropdown" aria-expanded="false">DK</div>
                  <div class="dropdown-menu">
                     <div onclick="location.href ='."'".'/products/street'."'".'" class="nav_01_left_link">Profile</div>
                     <div onclick="location.href='."'".'/api/account/logout'."'".'" class="nav_01_left_link">Logout</div>
                  </div>
               </div>';
 }else{
echo '<div  onclick="location.href = '."'".'/login'."'".'" class="nav_01_right_btn">Login</div>
<div onclick="location.href ='."'".'/create-account'."'".'" class="nav_01_right_btn_2">Get started free</div>';
 }

?>
     

               
               
               

               <span class="material-icons-outlined" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">menu</span>
            </div>
         </div>
      </div>
 