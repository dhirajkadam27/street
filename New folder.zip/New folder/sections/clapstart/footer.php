 <div class="footer_01">
        <div class="footer_01_up">
            <div class="footer_01_up_logo">Clapstart</div>
            <div class="footer_01_up_links">
                <div class="footer_01_up_link">
                    <div class="footer_01_up_link_url">About us</div>
                    <div class="footer_01_up_link_desc">What’s behind the boards.</div>
                </div>
                <div class="footer_01_up_link">
                    <div class="footer_01_up_link_url">Career</div>
                    <div class="footer_01_up_link_desc">Learn about open roles on the Trello team.</div>
                </div>
                <div class="footer_01_up_link">
                    <div class="footer_01_up_link_url">Pricing</div>
                    <div class="footer_01_up_link_desc">Get all pricing details.</div>
                </div>
                <div class="footer_01_up_link">
                    <div class="footer_01_up_link_url">Contact us</div>
                    <div class="footer_01_up_link_desc">Need anything? Get in touch and we can help.</div>
                </div>
            </div>
        </div>
        <div class="footer_01_down">
            <div class="footer_01_down_left">
                <div class="footer_01_down_left_link">Privacy policy</div>
                <div class="footer_01_down_left_link">terms</div>
                <div class="footer_01_down_left_text">Copyright © 2023 Clapstart</div>
            </div>
            <div class="footer_01_down_right">
                <div class="footer_01_down_right_link"><img src="/assets/Instagram.svg"></div>
                <div class="footer_01_down_right_link"><img src="/assets/Facebook.svg"></div>
                <div class="footer_01_down_right_link"><img src="/assets/Twitter.svg"></div>
                <div class="footer_01_down_right_link"><img src="/assets/YouTube.svg"></div>
            </div>
        </div>
    </div>