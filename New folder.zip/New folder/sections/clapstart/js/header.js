  function team_btn(id){
          if($(id)[0].getAttribute('aria-expanded')=="true"){
            $(id).find('span')[0].innerHTML = "expand_more";
          }else if($(id)[0].getAttribute('aria-expanded')=="false"){
            $(id).find('span')[0].innerHTML = "expand_less";
          }else{
            $(id).find('span')[0].innerHTML = "expand_less";
          }
         }