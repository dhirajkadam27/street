<?php
session_start();

if (isset($_SESSION['user_id'])) {
  header('Location: ./apps');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clapstart</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
       rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
       rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/sections/clapstart/js/header.js"></script>
    <link href="/sections/clapstart/css/header.css"
       rel="stylesheet">
    <link href="/sections/clapstart/css/footer.css"
       rel="stylesheet">

       <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>


    <style>
        body{
    margin: 0;
    padding: 0;
    font-family: 'Lato', sans-serif;
    }
    .main {
    width: 100%;
    height:80vh;
    display: flex;
    align-items:center;
    justify-content: center;
}
.main_title {
    font-size: 30px;
    font-weight: 800;
    color: #172B4D;
    cursor: pointer;
    text-align: center;
    padding-top: 50px;
    padding-bottom: 10px;
}

.main_btn {
    text-align: center;
    margin-right: 20px;
    padding: 6px 10px;
    border-radius: 2px;
    font-size: 14px;
    font-weight: 600;
    color: white;
    background: #0c66e4;
    cursor: pointer;
    width: 250px;
    margin: 20px auto;
}

.main_link {
    font-size: 12px;
    font-weight: 500;
    color: #44546F;
    text-align: center;
}
    </style>
</head>
<body>
    <?php
include_once("./sections/clapstart/header.php") 
    ?>

    <div class="main">
        <div class="login">
      <div class="main_title">Sign in</div>
      <div id="liveAlertPlaceholder"></div>
      <div id="google-signin-btn" class="main_btn">Sign in with Google</div>
      <div id="github-signin-btn" class="main_btn">Sign in with Github</div>

      <div class="main_link">By pressing 'Continue' you agree to our Terms & Conditions</div>
      <div class="main_link">You don't have an account? Sign up for free.</div>
        </div>
    </div>


<?php
include_once("./sections/clapstart/footer.php") 
    ?>


<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyABfZ1GZ9Eti6e50EgOGkQqJ1s5nzCoIRc",
    authDomain: "clapstart-1492e.firebaseapp.com",
    projectId: "clapstart-1492e",
    storageBucket: "clapstart-1492e.appspot.com",
    messagingSenderId: "953994364799",
    appId: "1:953994364799:web:5269e513f208af7fca3c4a",
    measurementId: "G-HLT4ZP6LHC"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);


  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Google sign-in
const googleProvider = new firebase.auth.GoogleAuthProvider();
document.getElementById('google-signin-btn').addEventListener('click', () => {
  firebase.auth().signInWithPopup(googleProvider)
    .then((result) => {
      // Handle successful sign-in
      const user = result.user;
      console.log('Signed in with Google:', user.email);
      
      $.ajax({
  url: "http://localhost/api/account/login.php",
  type: "POST",
  data: { email: user.email },
  dataType: "json",
  success: function(response) {
    if(response.status){
        window.location.replace("http://localhost/apps");
    }else if(response.msg=="Not email found"){
        window.location.replace("http://localhost/create-account");
    }else{
    appendAlert(response.msg);
    }
  },
  error: function(xhr, status, error) {
    appendAlert('Something went wrong');
  }
});

firebase.auth().signOut()
  .then(() => {
    console.log('User successfully signed out');
  })
  .catch((error) => {
    console.error('Error signing out:', error);
  });


    })
    .catch((error) => {
      // Handle errors
    appendAlert('Something went wrong');
    });
});

// GitHub sign-in
const githubProvider = new firebase.auth.GithubAuthProvider();
document.getElementById('github-signin-btn').addEventListener('click', () => {
  firebase.auth().signInWithPopup(githubProvider)
    .then((result) => {
      // Handle successful sign-in
      const user = result.user;
      console.log('Signed in with GitHub:', user.email);
       
      $.ajax({
  url: "http://localhost/api/account/login.php",
  type: "POST",
  data: { email: user.email },
  dataType: "json",
  success: function(response) {
    if(response.status){
        // window.location.replace("http://localhost/apps");
    }else if(response.msg=="Not email found"){
        // window.location.replace("http://localhost/create-account");
    }else{
    appendAlert(response.msg);
    }
  },
  error: function(xhr, status, error) {
    appendAlert('Something went wrong');
  }
});

firebase.auth().signOut()
  .then(() => {
    console.log('User successfully signed out');
  })
  .catch((error) => {
    console.error('Error signing out:', error);
  });


    })
    .catch((error) => {
      // Handle errors
    appendAlert('Something went wrong');
    });
});


const alertPlaceholder = document.getElementById('liveAlertPlaceholder')
const appendAlert = (message) => {
  const wrapper = document.createElement('div')
  wrapper.innerHTML = [
    `<div class="alert alert-danger alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('')

  alertPlaceholder.append(wrapper)
}


</script>



</body>
</html>