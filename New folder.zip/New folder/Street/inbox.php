<?php
session_start();

// if (isset($_SESSION['user_id'])) {
//   header('Location: ./apps');
//   exit();
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clapstart</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
       rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
       rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/sections/street/js/header.js"></script>
    <script src="/sections/street/js/left_slider.js"></script>
    <link href="/sections/street/css/left_slider.css"
       rel="stylesheet">



    <style>
        body{
    margin: 0;
    padding: 0;
    font-family: 'Lato', sans-serif;
    }
   .main{
    display:flex;
    width:100%;
   }
   .inbox {
    width: 100%;
    margin-top: 100px;
}

.inbox_title {
    font-size: 25px;
    font-weight: 800;
    margin-left: 40px;
    color: #172B4D;
}
.inbox_navigations {
    margin-top: 20px;
    display: flex;
    width: 100%;
    border-bottom: 1px solid #091E4224;
    align-items: center;
    height: 50px;
}

.inbox_navigation {
    display: flex;
    align-items: center;
    color: #44546F;
    padding: 5px 7px;
    border-radius: 3px;
    cursor: pointer;
}
.inbox_navigation:hover {
    background:#091E4224
}
.inbox_navigation_border_active {
    height: 47px;
    border-bottom: 3px solid #0c66e4;
    margin: 0px 20px;
}
.inbox_navigation_border {
    height: 47px;
    border-bottom: 3px solid #ffffff00;
    margin: 0px 20px;
}

    </style>
</head>
<body>
    <?php
include_once("../sections/street/header.php") 
    ?>

  <div class="main">
    <?php
include_once("../sections/street/left_silder.php") 
    ?>
    <div class="inbox">
        <div class="inbox_title">Inbox</div>
        <div class="inbox_navigations">
            <div class="inbox_navigation_border_active"><div class="inbox_navigation">Messages</div></div>
            <div class="inbox_navigation_border"><div class="inbox_navigation">Send</div></div>
        </div>
    </div>
  </div>




</body>
</html>