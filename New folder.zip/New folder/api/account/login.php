<?php
require_once '../config.php';

$email = $_POST['email'];
if($status){
    try {
      
        $sql = "SELECT * FROM users WHERE email='".$email."'";
        $result = $conn->query($sql);
        
         // Check if email exists in the database
         if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $status = true;
            $message = "".$row['id']."";
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['email'] = $row['email'];
        } else {
            $status = false;
            $message = "Not email found";
        }
        $conn->close();
    } catch (Exception $e) {
        $status = false;
        $message = "Something went wrong";
    }
}


$data = array(
    "status" => $status,
    "msg" => $message
);

$json = json_encode($data);

echo $json;
?>
