<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clapstart";


$status = false;
$message = "Something went wrong";


try {
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    $status = false;
    $message = "Failed to connect";
}else{
    $status = true;
    $message = "Connected successfully";
}
} catch(Exception $e) {
    $status = false;
    $message = "Failed to connect";
}


// $data = array(
//     "status" => $status,
//     "msg" => $message
// );

// $json = json_encode($data);

// echo $json;

?>