<?php
session_start();

if (!isset($_SESSION['user_id'])) {
  header('Location: ./login');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clapstart</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
       rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
       rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/sections/clapstart/js/header.js"></script>
    <link href="/sections/clapstart/css/header.css"
       rel="stylesheet">
    <link href="/sections/clapstart/css/footer.css"
       rel="stylesheet">


       


    <style>
        body{
    margin: 0;
    padding: 0;
    font-family: 'Lato', sans-serif;
    }
    .main {
    width: 100%;
    margin-top:100px;
}
.products {
    font-size: 30px;
    font-weight: 900;
    color: #172B4D;
    margin-left: 50px;
}
.product {
    background: #0c66e4;
    border-radius: 3px;
    margin-top: 30px;
    margin-left: 60px;
    align-items: center;
    justify-content: center;
    color: white;
    width: 230px;
    padding: 15px;
    cursor:pointer
}
.product_name {
    font-size: 25px;
    font-weight: 700;
}

.product_desc {
    font-size: 15px;
    font-weight: 500;
    margin-top:10px
}
    </style>
</head>
<body>
    <?php
include_once("./sections/clapstart/header.php") 
    ?>

  
<div class="main">
    <div class="products">Products</div>
    <div class="product" onclick="location.href='./street'">
        <div class="product_name">Street</div>
        <div class="product_desc">Project Management Tool</div>
    </div>
</div>


</body>
</html>