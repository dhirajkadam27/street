function account_loading(){
    const account_loading = `
    <div id="account_loading">
    <style>
    .account_loading {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
    animation: blur .1s linear forwards;
    }
    
    
    .account_loading_box {
        width: 300px;
        height: 300px;
        border-radius: 20px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin-top: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
      animation: popup .5s; 
      transform: scale(0,0) translate(0, -200px);
      animation-fill-mode: forwards;
    }
    .account_loading_icon img {
        width: 30px;
    }
    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div class="account_loading">
    <div class="account_loading_box">
        <div class="account_loading_icon">
            <img src="https://i.stack.imgur.com/kOnzy.gif">
        </div>
    </div>
</div>
</div>
    `;
    $('body').append($(account_loading));
}

function close_account_loading(){
    $('#account_loading').remove();
}

function login(){
    const login = `
    <div id="login">
    <style>
    .login {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
    }
    
    .login_box {
        width: 350px;
        height: fit-content;
        border-radius: 20px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin-top: 20px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
        padding: 40px 10px;
    }
    
    .login_txt {
        color: #78859D;
        font-size: 20px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 40px;
    }
    
    .login_box_btn {
        border-radius: 5px;
        border: 1px solid #C5E1FF;
        background: #EAF4FF;
        padding: 5px 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #526587;
        font-size: 13px;
        font-weight: 600;
        margin: 20px 10px;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .login_box_btn:active{
        background: #d7e9fd;
        transform: scale(0.99);
    }
    .login_box_btn img {
        width: 13px;
        margin-right: 10px;
    }
    
    .login_link {
        color: #78859D;
        font-size: 12px;
        font-weight: 500;
        text-align: center;
        padding-top: 5px;
    }
    
    .login_link span {
        color: #2E71EB;
        cursor: pointer;
    }
    .close_btn {
        position: absolute;
        right: 10px;
        top: 10px;
        padding: 2px;
        color: #78859D;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .close_btn:active{
        color: #636e81;
        transform: scale(0.99);
    }
    
    .close_btn span {
        font-size: 25px;
    }
    
    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div class="login">
    <div class="login_box">
        <div onclick="close_login()" class="close_btn"><span class="material-icons">cancel</span></div>
        <div class="login_txt">Login into your account</div>
        <div onclick="close_login();google()" class="login_box_btn"><img src="./assets/img/google.webp"> Sign in with Google</div>
        <div onclick="close_login();apple()" class="login_box_btn"><img src="./assets/img/apple.svg"> Sign in with Apple</div>
        <div class="login_link">I don't have a account, <span onclick="close_login();signup()" >create a new account</span></div>
    </div>
</div>
</div>
    `;
    $('body').append($(login));
}

function close_login(){
    $('#login').remove();
}


function signup(){
    const signup = `
    <div id="signup">
    <style>
    .signup {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
    }
    
    .signup_box {
        width: 350px;
        height: fit-content;
        border-radius: 20px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin-top: 20px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
        padding: 40px 10px;
    }
    
    .signup_txt {
        color: #78859D;
        font-size: 20px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 40px;
    }
    
    .signup_box_btn {
        border-radius: 5px;
        border: 1px solid #C5E1FF;
        background: #EAF4FF;
        padding: 5px 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #526587;
        font-size: 13px;
        font-weight: 600;
        margin: 20px 10px;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .signup_box_btn:active{
        background: #d7e9fd;
        transform: scale(0.99);
    }
    .signup_box_btn img {
        width: 13px;
        margin-right: 10px;
    }
    
    .signup_link {
        color: #78859D;
        font-size: 12px;
        font-weight: 500;
        text-align: center;
        padding-top: 5px;
    }
    
    .signup_link span {
        color: #2E71EB;
        cursor: pointer;
    }
    .close_btn {
        position: absolute;
        right: 10px;
        top: 10px;
        padding: 2px;
        color: #78859D;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .close_btn:active{
        color: #636e81;
        transform: scale(0.99);
    }
    
    .close_btn span {
        font-size: 25px;
    }

    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div class="signup">
    <div class="signup_box">
        <div onclick="close_signup();" class="close_btn"><span class="material-icons">cancel</span></div>
        <div class="signup_txt">Create your new account</div>
        <div onclick="close_signup();google()" class="signup_box_btn"><img src="./assets/img/google.webp"> Sign up with Google</div>
        <div onclick="close_signup();apple()" class="signup_box_btn"><img src="./assets/img/apple.svg"> Sign up with Apple</div>
        <div class="signup_link">I have a account, <span onclick="close_signup();login()">login to existing account</span></div>
    </div>
</div>
</div>
    `;
    $('body').append($(signup));
}

function close_signup(){
    $('#signup').remove();
}



function account_setup(email){
    const account_setup = `
    <div id="account_setup">
    <style>
    
.account_setup {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.10);
    animation: blur .1s linear forwards;
    position: fixed;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
}

.account_setup_box {
    width: 350px;
    height: fit-content;
    border-radius: 20px;
    border: 1px solid #C5CEDF;
    background: #FFF;
    margin-top: 20px;
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
    padding: 40px 10px;
}

.account_setup_box_title {
    color: #78859D;
    font-size: 20px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 20px;
}


.account_setup_box input {
    width: 96%;
    margin: 0px 2%;
    padding: 8px 10px;
    border-radius: 5px;
    border: 1px solid #C5CEDF;
    background: #F7F7F7;
    color: #526587;
    font-family: Inter;
    font-size: 13px;
    font-weight: 500;
    margin-top: 5px;
    margin-bottom: 15px;
    outline-color: #2698F0;
}
.account_setup_box input::placeholder{
    color: #778cb3;
    font-family: Inter;
    font-size: 12px;
    font-weight: 500;
}

.account_setup_box_button {
    width: 96%;
    height: 30px;
    margin: 0px 2%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #2698F0;
    border-radius: 6px;
    color: #FFF;
    font-size: 13px;
    font-weight: 600;
    margin-top: 10px;
    cursor: pointer;
    transition: all .2s ease-in-out;
    border:none
}
.account_setup_box_button:active{
    background: #1c8be1;
    transform: scale(0.99);
}
    .close_btn {
        position: absolute;
        right: 10px;
        top: 10px;
        padding: 2px;
        color: #78859D;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .close_btn:active{
        color: #636e81;
        transform: scale(0.99);
    }
    
    .close_btn span {
        font-size: 25px;
    }
    
    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div class="account_setup">
    <div class="account_setup_box">
        <div onclick="close_account_setup()" class="close_btn"><span class="material-icons">cancel</span></div>
        <div class="account_setup_box_title">Account Setup</div>
        <form id="account_setup_form">
        <input required type="text" name="email" id="account_setup_input_email" value="${email}" disabled placeholder="Email">
        <input required type="text" name="name" id="account_setup_input_name" placeholder="Full name">
        <input required type="text" name="username" id="account_setup_input_username" placeholder="Username">
        <button onclick="account_setup_btn()" class="account_setup_box_button">Create</button>
        </form>
    </div>
</div>
</div>
    `;
    $('body').append($(account_setup));
}

function close_account_setup(){
    $('#account_setup').remove();
}



function oops(msg){
    const oops = `
    <div id="oops">
    <style>
  
.oops {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.10);
    animation: blur .1s linear forwards;
    position: fixed;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
}

.oops_box {
    width: 280px;
    height: fit-content;
    border-radius: 20px;
    border: 1px solid #C5CEDF;
    background: #FFF;
    margin-top: 20px;
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
    padding: 20px 10px;
}

.oops_title {
    color: #78859D;
    font-size: 20px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 20px;
}

.oops_icon {
    text-align: center;
}

.oops_icon span {
    font-size: 70px;
    color: #FFBB38;
}

.oops_txt {
    color: #78859D;
    font-size: 15px;
    font-weight: 500;
    text-align: center;
    margin-top: 10px;
    margin-bottom: 25px;
}

.oops_btn {
    width: 96%;
    height: 30px;
    margin: 0px 2%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #2698F0;
    border-radius: 6px;
    color: #FFF;
    font-size: 13px;
    font-weight: 600;
    margin-top: 10px;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>

    <div class="oops">
    <div class="oops_box">
        <div class="oops_title">Oops</div>
        <div class="oops_icon"><span class="material-icons">error</span></div>
        <div class="oops_txt">${msg}</div>
        <div onclick="location.reload();" class="oops_btn">Retry</div>
    </div>
</div>
</div>
    `;
    $('body').append($(oops));
}

function close_oops(){
    $('#oops').remove();
}


function google() {
    account_loading();
	const googleProvider = new firebase.auth.GoogleAuthProvider();
	firebase.auth().signInWithPopup(googleProvider).then((result) => {
		close_account_loading();
		const user = result.user;
		console.log('Signed in with Google:', user.email);
		account(user.email);
	}).catch((error) => {
		close_account_loading();
		oops('Something went wrong');
		console.log('Something went wrong');
	});
}

function apple() {
    account_loading();
	const appleProvider = new firebase.auth.OAuthProvider('apple.com');
	firebase.auth().signInWithPopup(appleProvider).then((result) => {
		close_account_loading();
		const user = result.user;
		console.log('Signed in with Apple:', user.email);
		account(user.email);

	}).catch((error) => {
		close_account_loading();
		oops('Something went wrong');
	});
}

function account_setup_btn(){
    $('#account_setup_form').submit(function(e) {
        e.preventDefault(); 
        account_setup_api($('#account_setup_input_email').val(),$('#account_setup_input_name').val(),$('#account_setup_input_username').val());
    });
}



function account(email) {
	$.ajax({
		url: "/api/clapstart/account/account.php",
		type: "GET",
		data: {
			email: email
		},
		dataType: 'text',
		success: function(response) {
			if(response=="Email not found"){
				oops("Email not found");
			}else if(response=="Login"){
				window.location.href='./store.php';
			}else if(response=="Account setup"){
                account_setup(email);
			}else if(response=="Failed to create account"){
				oops("Failed to create account");
			}else{
				oops("Something went wrong");
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
            oops("Unable to connect the server");
		}
	});
}

function account_setup_api(email,name,username) {
	$.ajax({
		url: "/api/clapstart/account/account-setup.php",
		type: "GET",
		data: {
			email: email,
			name: name,
			username: username
		},
		dataType: 'text',
		success: function(response) {
            console.log(response);
			if(response=="Email not found"){
				oops("Email not found");
			}else if(response=="Name not found"){
				oops("Name not found");
			}else if(response=="Username not found"){
				oops("Username not found");
			}else if(response=="Login"){
				window.location.href='./store.php';
			}else{
				oops("Something went wrong");
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
            oops("Unable to connect the server");
		}
	});
}


function search(){
    const search = `
    <div id="search">
    <style>
    .search {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
    }
    
    .search_box {
        width: 40%;
        height: 30px;
        border-radius: 10px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        display: flex;
        align-items: center;
        margin: 10px auto;
        margin-top: 50px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
    }
    
    .search_box span {
        font-size: 20px;
        margin-left: 10px;
        margin-right: 10px;
        color: #78859D;
    }
    
    .search_box input {
        width: -webkit-fill-available;
        height: fit-content;
        margin-right: 10px;
        color: #78859D;
        font-size: 15px;
        font-weight: 500;
        border: none;
        outline: none;
    }
    
    .search_box input::placeholder {
        color: #78859D;
        font-size: 15px;
        font-weight: 500;
    }
    
    .search_results {
        width: 40%;
        border-radius: 10px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin: 10px auto;
        margin-top: 50px;
        padding-top: 20px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
        display:none
    }
    
    .search_result {
        display: flex;
        align-items: center;
        margin: 0px 15px;
        padding: 7px 10px;
        border-radius: 10px;
        margin-bottom: 10px;
        transition: all .2s ease-in-out;
        cursor: pointer;
        text-deocration:none;
    }
    .search_result:hover {
        background: #F0F2F7;
    }
    .search_result:active {
        transform: scale(0.99);
    }
    
    .search_result_img {
        border-radius: 8px;
        background: #E1E6F0;
        overflow: hidden;
        margin-right: 10px;
    }
    
    .search_result_img img {
        width: 40px;
    }
    
    .search_result_name {
        color: #001930;
        font-size: 15px;
        font-weight: bold;
        margin-bottom: 3px;
    }
    
    .search_result_type {
        color: #78859D;
        font-size: 10px;
        font-weight: 500;
    }
    
    .search_result_icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        font-weight: 600;
        color: #fff;
    }
    .no_src {
        text-align: center;
        padding-bottom: 15px;
        color: #78859D;
        font-size: 15px;
        font-weight: 500;
    }
    
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div onclick="unblur_onclick('search');" class="search">
        <div class="search_box"><span class="material-icons">search</span><input onkeyup="search_api(this)" placeholder="Search"></div>
        <div class="search_results">
            // <div class="search_result">
            //     <div class="search_result_img"><img src="./assets/img/street.svg"></div>
            //     <div class="search_result_txt">
            //         <div class="search_result_name">Street</div>
            //         <div class="search_result_type">Site page</div>
            //     </div>
            // </div>
            // <div class="search_result">
            //     <div class="search_result_img"><div class="search_result_icon">D</div></div>
            //     <div class="search_result_txt">
            //         <div class="search_result_name">Street</div>
            //         <div class="search_result_type">Site page</div>
            //     </div>
            // </div>
        </div>
    </div>
</div>
    `;
    $('body').append($(search));
}

function close_search(){
    $('#search').remove();
}


function search_api(div){

        var query = $(div).val().trim();
    
        if (query !== '') {
          $.ajax({
            url: '/api/clapstart/account/search.php',
            method: 'GET',
            data: { query: query },
            success: function(response) {
                if(response=="Not found"){
                    $('.search_results').html('<div class="no_src">Not search found</div>');
                }else{
                    $('.search_results').html(response);
                }
              $('.search_results').show();
            }
          });
        } else {
          $('.search_results').hide();
        }

}

function profile(email,name,username){
    if(!$('#profile_context').length){
    const profile = `
    <div id="blur">
    <style> 
    .blur {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        position: fixed;
        top: 0;
        left: 0;
        animation: blur .1s linear forwards;
    }
@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    </style>
    <div onclick="unblur_onclick('blur');close_profile()" class="blur">
    </div>
</div>
    `;
    $('body').append($(profile));

    
    const profile_context = `
    <div id="profile_context">
    <style> 

    
.profile_context {
    position: absolute;
    right: 30px;
    background: white;
    border-radius: 10px;
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
}
.profile_context_profile {
    border-bottom: 1px solid #C5CEDF;
    padding: 15px 15px;
    display: flex;
    align-items: center;
}

.profile_context_profile_img {
    width: 30px;
    height: 30px;
    border-radius: 100px;
    background: #63BEFF;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}

.profile_context_profile_icon {
    font-size: 15px;
    font-weight: 600;
    color: white;
}

.profile_context_profile_name {
    color: #001930;
    font-size: 13px;
    font-weight: 600;
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.profile_context_profile_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.profile_context_profile_txt {
    width: 110px;
}

.profile_context_btn {
    border-radius: 7px;
    margin: 10px;
    padding: 5px 10px;
    color: #001930;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.profile_context_btn:hover{
    background: #E1E6F0;
}
.profile_context_btn_line{
    width:100%;
    height: 0.8px;
    background:  #C5CEDF;
}

@keyframes popup {
    100% {
        transform: scale(1,1) translate(0, 0);
        transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
    }
}
    </style>
    <div class="profile_context">
    <div class="profile_context_profile">
        <div id="profile_icon_color" class="profile_context_profile_img">
            <div id="profile_icon_color" class="profile_context_profile_icon">${name[0]}</div>
        </div>
        <div class="profile_context_profile_txt">
            <div class="profile_context_profile_name">${name}</div>
            <div class="profile_context_profile_username">@${username}</div>
        </div>
    </div>
    
    <div class="profile_context_btn" onclick="close_profile();user('${email}','${name}','${username}');">Profile</div>
    <div onclick="close_profile();user_logout('${email}','${name}','${username}');" class="profile_context_btn">Logout</div>
    <div class="profile_context_btn_line"></div>
    <div class="profile_context_btn">Privacy</div>
    <div class="profile_context_btn">Terms</div>

 </div> 

</div>
    `;
    
    $('#store_nav_profile_box').css('zIndex','10');
    $('#store_nav_profile_box').append($(profile_context));
}
}

function close_profile(){
    $('#blur').remove();
    $('#profile_context').remove();
    $('#store_nav_profile_box').css('zIndex','0');
}

 

function user(email,name,username){
    const user = `
    <div id="user">
    <style>

    
.user {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.10);
    animation: blur .1s linear forwards;
    position: fixed;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
}

.user_popup {
    width: 350px;
    height: fit-content;
    border-radius: 20px;
    border: 1px solid #C5CEDF;
    background: #FFF;
    margin-top: 20px;
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
    padding: 20px 10px;
    padding-top: 40px;
}

.close_btn {
    position: absolute;
    right: 10px;
    top: 10px;
    padding: 2px;
    color: #78859D;
    cursor: pointer;
    transition: all .2s ease-in-out;
}

    .close_btn:active{
        color: #636e81;
        transform: scale(0.99);
    }
    
    .close_btn span {
        font-size: 25px;
    }

.edit {
    position: absolute;
    left: 20px;
    top: 15px;
    color: #2698F0;
    font-size: 13px;
    font-weight: 600;
    padding: 2px 5px;
    background: #fff;
    border-radius: 4px;
    cursor:pointer;
    transition: all .2s ease-in-out;
}

    .edit:active{
        background: #ced0d5;
        transform: scale(0.99);
    }
.edit:hover {
    background: #dee0e4;
}

.user_icon {
    margin: 10px auto;
    width: 50px;
    height: 50px;
    border-radius: 100px;
    background: #63BEFF;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #FFF;
    font-size: 20px;
    font-weight: 600;
}

.user_name {
    color: #001930;
    font-size: 15px;
    font-weight: 600;
    text-align: center;
    margin-top: 25px;
}

.user_username {
    color: #78859D;
    font-size: 15px;
    font-weight: 500;
    margin-top: 5px;
    text-align: center;
    margin-bottom: 15px;
}

.user_btn {
    border-radius: 5px;
    border: 1px solid #C5CEDF;
    background: #FDFDFD;
    width: 95%;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #78859D;
    font-size: 12px;
    font-weight: 600;
    margin: 10px auto;
    transition: all .2s ease-in-out;
    cursor: pointer;
}
    .user_btn:active{
        background: #ebecf0;
        transform: scale(0.99);
    }
    
.user_btn1{
    border-radius: 5px;
    background: #F45858;
    width: 95%;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;    
    color: #fff;
    font-size: 12px;
    font-weight: 600;
    margin: 10px auto;
    transition: all .2s ease-in-out;
    cursor: pointer;
}
    .user_btn1:active{
        background: #cd3a3a;
        transform: scale(0.99);
    }

    
    .user_btn img,.user_btn img {
        width: 18px;
        mix-blend-mode: plus-lighter;
    }

@keyframes blur {
	100% {	backdrop-filter: blur(5px) };
}
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }


    </style>
            <div onclick="unblur_onclick('user');" class="user">
            <div class="user_popup">
                <div onclick="close_user();user_edit('${email}','${name}','${username}');" class="edit">Edit</div>
                <div onclick="close_user()" class="close_btn"><span class="material-icons">cancel</span></div>
                <div class="user_img"><div id="profile_icon_color" class="user_icon">${name[0]}</div></div>
                <div class="user_name">${name}</div>
                <div class="user_username">@${username}</div>
                <div onclick="btn_loader(this,'Logout');user_logout_api();btn_loader(this,'Logout');" class="user_btn">Logout</div>
                <div onclick="btn_loader(this,'Delete your account');user_delete_api();btn_loader(this,'Delete your account');" class="user_btn1">Delete your account</div>
            </div>
        </div>
</div>
    `;
    $('body').append($(user));
}

function close_user(){
    $('#user').remove();
}


 

function user_logout(email,name,username){
    const user_logout = `
    <div id="user_logout">
    <style>
    .user_logout {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
    }
    
    .user_logout_popup {
        width: 350px;
        height: fit-content;
        border-radius: 20px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin-top: 20px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
        padding: 20px 10px;
        padding-top: 40px;
    }
    
    .close_btn {
        position: absolute;
        right: 10px;
        top: 10px;
        padding: 2px;
        color: #78859D;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    
        .close_btn:active{
            color: #636e81;
            transform: scale(0.99);
        }
        
        .close_btn span {
            font-size: 25px;
        }
    
    
    .user_logout_user_icon {
        margin: 10px auto;
        width: 50px;
        height: 50px;
        border-radius: 100px;
        background: #63BEFF;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #FFF;
        font-size: 20px;
        font-weight: 600;
    }
    
    .user_logout_user_name {
        color: #001930;
        font-size: 15px;
        font-weight: 600;
        text-align: center;
        margin-top: 25px;
    }
    
    .user_logout_user_username {
        color: #78859D;
        font-size: 15px;
        font-weight: 500;
        margin-top: 5px;
        text-align: center;
        margin-bottom: 15px;
    }
    
    .user_logout_user_btn {
        border-radius: 5px;
        background: #2698F0;
        width: 95%;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        margin: 10px auto;
        transition: all .2s ease-in-out;
        cursor: pointer;
    }
    .user_logout_user_btn img {
        width: 18px;
        mix-blend-mode: plus-lighter;
    }
        .user_logout_user_btn:active{
            background: #1c83d1;
            transform: scale(0.99);
        }
    
    @keyframes blur {
        100% {	backdrop-filter: blur(5px) };
    }
        @keyframes popup {
            100% {
                transform: scale(1,1) translate(0, 0);
                transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
            }
        }

    </style>
         
        <div onclick="unblur_onclick('user_logout');" class="user_logout">
            <div class="user_logout_popup">
                <div onclick="close_user_logout()" class="close_btn"><span class="material-icons">cancel</span></div>
                <div class="user_logout_user_img"><div id="profile_icon_color" class="user_logout_user_icon">${name[0]}</div></div>
                <div class="user_logout_user_name">${name}</div>
                <div class="user_logout_user_username">@${username}</div>
                <div onclick="btn_loader(this,'Logout');user_logout_api();btn_loader(this,'Logout');" class="user_logout_user_btn">Logout</div>
            </div>
        </div>
</div>
    `;
    $('body').append($(user_logout));
}

function close_user_logout(){
    $('#user_logout').remove();
}



function user_edit(email,name,username){
    const user_edit = `
    <div id="user_edit">
    <style>
    .user_edit {
        width: 100%;
        height: 100vh;
        background: rgba(0, 0, 0, 0.10);
        animation: blur .1s linear forwards;
        position: fixed;
        top: 0;
        left: 0;
        display: flex;
        justify-content: center;
    }
    
    .user_edit_popup {
        width: 350px;
        height: fit-content;
        border-radius: 20px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        margin-top: 20px;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
        padding: 20px 10px;
        padding-top: 40px;
    }
    
       .close_btn {
            position: absolute;
            right: 10px;
            top: 10px;
            padding: 2px;
            color: #78859D;
            cursor: pointer;
            transition: all .2s ease-in-out;
        }
        
            .close_btn:active{
                color: #636e81;
                transform: scale(0.99);
            }
            
            .close_btn span {
                font-size: 25px;
            }
            .user_edit_user_img {
        position: relative;
    }
    
    
    .user_edit_user_icon {
        margin: 10px auto;
        width: 50px;
        height: 50px;
        border-radius: 100px;
        background: #63BEFF;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #FFF;
        font-size: 20px;
        font-weight: 600;
        transition: all .2s ease-in-out;
        cursor: pointer;
    }
    .user_edit_user_icon:active{
        background: #3596dc;
                transform: scale(0.99);
    }
    .color_btn {
        width: 30px;
        height: 30px;
        border-radius: 6px;
        margin: 5px;
    }
    
    .user_edit_popup input {
        border-radius: 7px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        width: 95%;
        height: 30px;
        margin: 10px 2.5%;
        padding: 10px;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        outline-color:#1c83d1
    }
    
    .user_edit_popup input::placeholder {
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
    }
    
    .user_edit_user_btn {
        border-radius: 5px;
        background: #2698F0;
        width: 95%;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        margin: 10px auto;
        transition: all .2s ease-in-out;
        cursor: pointer;
    }
    .user_edit_user_btn:active{
        background: #1c83d1;
                transform: scale(0.99);
    }
    
    @keyframes blur {
        100% {	backdrop-filter: blur(5px) };
    }
        @keyframes popup {
            100% {
                transform: scale(1,1) translate(0, 0);
                transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
            }
        }

    </style>
         
    <div onclick="unblur_onclick('user_edit');" class="user_edit">
    <div class="user_edit_popup">

        <div onclick="close_user_edit()" class="close_btn"><span class="material-icons">cancel</span></div>
        <div class="user_edit_user_img">
            <div onclick="color_label()" id="profile_icon_color" class="user_edit_user_icon">${name[0]}</div>
        </div>
        <input type="text" id="update_user_name" placeholder="Full Name" value="${name}">
        <input type="text" id="update_user_username" placeholder="@Username" value="${username}">
        <div onclick="user_update()" class="user_edit_user_btn">Save</div>
    </div>
</div>

</div>
    `;
    $('body').append($(user_edit));
}

function close_user_edit(){
    $('#user_edit').remove();
}



function color_label(){
    const color_label = `
    <div id="color_label">
    <style>

    .label {
        position: absolute;
        left: 40%;
        padding: 5px 10px;
        background: #ffffff;
        border-radius: 10px;
        font-size: 10px;
        font-weight: 500;
        color: #78859D;
        display: flex;
        justify-content: center;
        box-shadow: 0px 0px 10px #bababa;
        border: 1px solid #C5CEDF;
    }
    .label_corner {
        width: 15px;
        height: 15px;
        background: #d5ddec;
        position: absolute;
        top: -4px;
        left: 29px;
        transform: rotate(45deg);
        z-index: -1;
    }
    .color_btn {
        width: 40px;
        height: 40px;
        border-radius: 6px;
        margin: 5px;
        border: 1px solid white;
    outline: 2px solid #fff;
    outline-offset: 1px;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .color_btn_active{
        outline: 2px solid #bbbbdf;
    }
    .color_btn:active {
        transform: scale(0.88);
    }
    
    </style>
         
    <div class="label">
    <div class="label_corner"></div> 
    <div style="background-color: #FF4A4A;" onclick="change_color(this,'#FF4A4A')" class="color_btn"></div> 
    <div style="background-color: #FF4A80;" onclick="change_color(this,'#FF4A80')" class="color_btn"></div> 
    <div style="background-color: #FFAC4A;" onclick="change_color(this,'#FFAC4A')" class="color_btn"></div> 
    <div style="background-color: #4AB3FF;" onclick="change_color(this,'#4AB3FF')" class="color_btn"></div> 
    <div style="background-color: #BA4AFF;" onclick="change_color(this,'#BA4AFF')" class="color_btn"></div> 
</div>


</div>
    `;


    if($('#color_label').length){
        close_color_label();
    }else{
        $('.user_edit_user_img').append($(color_label));
        $('.color_btn').each(function() {
            if ($(this).css('background-color') === $('#profile_icon_color').css('background-color')) {
              $(this).addClass('color_btn_active');
            }
          });
    }
    
}

function close_color_label(){
    $('#color_label').remove();
}

function change_color(div,color){
    $('.color_btn').removeClass('color_btn_active');
    $('.user_edit_user_icon').css('background',color);
    $('#profile_icon_color').css('background',color);
    $(div).addClass('color_btn_active');
}

function user_logout_api(){
    $.ajax({
		url: "/api/clapstart/account/logout.php",
		type: "GET",
		data: {
		},
		dataType: 'text',
		success: function(response) {
            console.log(response);
			if(response=="Logout"){
				window.location.href='/';
			}else{
				oops("Something went wrong");
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
            oops("Unable to connect the server");
		}
	});
}

function btn_loader(div,txt){
    if($('.check_btn_loader').length){
        $(div).html(txt);
    }else{
    $(div).html('<img class="check_btn_loader" src="https://i.stack.imgur.com/kOnzy.gif">');
    }
}

function user_delete_api(){
    $.ajax({
		url: "/api/clapstart/account/account-delete.php",
		type: "GET",
		data: {
		},
		dataType: 'text',
		success: function(response) {
            console.log(response);
			if(response=="Deleted"){
				window.location.href='/';
			}else if(response=="Not Deleted"){
				oops("Unable to delete the user");
			}else{
				oops("Something went wrong");
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
            oops("Unable to connect the server");
		}
	});
}

function user_update(){
    var backgroundColor = $('#profile_icon_color').css('background-color');
    var hexColor = rgbToHex(backgroundColor);

    function rgbToHex(rgb) {
        if (rgb.search("rgb") === -1) {
          return rgb;
        } else {
          rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
          return "#" +
            ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) +
            ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) +
            ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2);
        }
      }
      
    $.ajax({
		url: "/api/clapstart/account/account-update.php",
		type: "GET",
		data: {
            color:hexColor,
            name:$('#update_user_name').val(),
            username:$('#update_user_username').val()
		},
		dataType: 'text',
		success: function(response) {
            console.log(response);
			if(response=="User not loged in"){
				window.location.href='/';
			}else if(response=="Name not found"){
				oops("Name not found");
			}else if(response=="Username not found"){
				oops("Username not found");
			}else if(response=="color not found"){
				oops("color not found");
			}else if(response=="Updated"){
				location.reload();
			}else if(response=="Not Updated"){
				oops("Falied to update the profile");
			}else{
				oops("Something went wrong");
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
            oops("Unable to connect the server");
		}
	});
}

function unblur_onclick(divid){

    $("."+divid).click(function(event) {
        if (event.target === this) {
            $('#'+divid).remove();
        }
    });
    
}