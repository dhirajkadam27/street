<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
}

?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
    background-image: url('https://4kwallpapers.com/images/wallpapers/macos-big-sur-apple-layers-fluidic-colorful-wwdc-stock-3840x2160-1455.jpg');
    background-size: cover;
}

.store_nav_profile_box {
    position: relative;
    z-index: 0;
}

.profile_icon {
    width: 40px;
    height: 40px;
    margin-left: auto;
    border-radius: 100px;
    background: #63BEFF;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 600;
    color: white;
    margin-top: 15px;
    margin-right: 15px;
    border:none;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.profile_icon:active{
    background: #44a3e7;
    transform: scale(0.99);
}
.profile_context {
    top: 45px !important;
    right: 45px !important;
}

.workspaces_main{
    height: 100vh;
    position: fixed;
    left: 20px;
    top: 0;
    display: flex;
    align-items: center;
}

.workspaces {
    padding: 20px 0px;
    width: 70px;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    background: rgb(255 255 255 / 40%);
    backdrop-filter: blur(30px);
    border: 1px solid rgb(255 255 255 / 20%);
    box-shadow: 0 0px 15px 0 rgb(0 0 0 / 20%);
    border-radius: 19px;
}
.workspace {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 600;
    color: white;
    border:none;
    margin-bottom: 10px;
    cursor: pointer;
    position: relative;
    transition: width, height, margin-top, cubic-bezier(0.25, 1, 0.5, 1) 100ms;
}
.workspace:nth-last-child(1){
    margin-bottom: 0px;
    background: #34394e;
}

.workspace:hover{
    width: 45px;
    height: 45px;
}
.workspace:active{
transform: translateX(10px);
}
.workspace:hover .workspace_name {
    display: flex;
}

.workspace_dot {
    width: 5px;
    height: 5px;
    background: white;
    position: absolute;
    left: -12px;
    border-radius: 10px;
}
.workspace_active {
    outline: 3px solid #E1E6F0;
    outline-offset: 3px;
}

.workspace_name {
    position: absolute;
    top: 10px;
    left: 70px;
    z-index: 20;
    width: max-content;
    height: 20px;
    padding: 5px 10px;
    background: #0000003b;
    border: 1px solid #00000012;
    border-radius: 5px;
    font-size: 10px;
    font-weight: 400;
    color: #ffffff;
    display: none;
    justify-content: center;
    align-items: center;
}
.workspace span{
    font-size: 20px;
}


.street_home_main {
    margin-left: 150px;
}

.street_home_main_greeting {
    margin-bottom: 50px;
}

.street_home_main_greeting_time {
    color: #FFF;
    font-size: 30px;
    font-weight: 700;
}

.street_home_main_greeting_txt {
    color: #FFF;
    font-size: 20px;
    font-weight: 700;
}


.home_split {
    display: flex;
    justify-content: space-between;
}

.todays_title {
    color: #FFF;
    font-size: 15px;
    font-weight: 500;
    margin-bottom: 20px;
}

.no_task {
    width: 500px;
    height: 50px;
    background: white;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #78859D;
    font-size: 15px;
    font-weight: 500;
}


.shortcuts {
    margin-right: 40px;
    width: 340px;
    padding: 10px;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.46);
    backdrop-filter: blur(25px);
    display: flex;
    flex-wrap: wrap;
}

.create_shortcuts {
    width: 150px;
    height: 170px;
    margin: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    border-radius: 15px;
}


@keyframes popup {
            100% {
                transform: scale(1,1) translate(0, 0);
                transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
            }
        }

#profile_icon_color{
    background:<?php echo $color;?>;
}

</style>
    </head>
    <body>
        <div id="store_nav_profile_box" class="store_nav_profile_box">
            <button onclick="profile('<?php echo $email?>','<?php echo $name?>','<?php echo $username?>')" id="profile_icon_color" class="profile_icon"><?php echo $name[0]?></button>
           </div>

           <div class="workspaces_main">
            <div class="workspaces">

            <?php

$sql = "SELECT * FROM workspaces WHERE FIND_IN_SET('$id', admin) OR FIND_IN_SET('$id', members) OR FIND_IN_SET('$id', observers)";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<button onclick="open_workspace(this,'."'".$row['url']."'".')" style="background: '.$row['color'].'" class="workspace">
        <div class="workspace_initial">'.$row['name'][0].'</div>
        <div class="workspace_name">'.$row['name'].'</div>
    </button>
    ';
    }
} else {
    header("Location: /street/create-your-workspace.html");
    exit;
}

?>
             <button onclick="create_workspace()" class="workspace">
                    <div class="workspace_initial"><span class="material-icons-outlined">add</span></div>
                    <div class="workspace_name">Create Workspace</div>
                </div>
            </button>
           </div>

           <div class="street_home_main">
            <div class="street_home_main_greeting">
                <div id="time" class="street_home_main_greeting_time">08:00</div>
                <div id="greeting" class="street_home_main_greeting_txt">Good morning</div>
            </div>

            <div class="home_split">
                <div class="todays">
                    <div class="todays_title">Todays</div>
                    <div class="no_task">Hurray no tasks for today</div> 
                </div>
    
                <div class="shortcuts">
                    <div class="create_shortcuts">
                        <span class="material-icons-outlined">add</span>
                    </div>
                </div>
            </div>
           </div>


           <script>
        $(document).ready(function() {
            // Get the current time
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();

            hours = (hours < 10 ? "0" : "") + hours;
            minutes = (minutes < 10 ? "0" : "") + minutes;

            $("#time").text(hours + ":" + minutes);
            
            if (hours >= 0 && hours < 12) {
                $("#greeting").text("Good morning");
            } else if (hours >= 12 && hours < 18) {
                $("#greeting").text("Good afternoon");
            } else {
                $("#greeting").text("Good evening");
            }
        });
    </script>

        </body>
</html>