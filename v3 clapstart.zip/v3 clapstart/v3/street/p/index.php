<?php
include '../../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM projects WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $name = $row['name'];
      $type = $row['type'];
      $admin = $row['admin'];
      $members = $row['members'];
      $observers = $row['observers'];
      
      $isstarred = false;
      $isstarreddata = explode(",", $row['starred']);

      if (in_array($id, $isstarreddata)) {
          $isstarred = true;
      } 

    }

}
?>
<html>
    <head>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>

<style>
    body{
        margin: 0;
        padding: 0;
        font-family: 'Inter', sans-serif;
        background: #F5F5F6;
    }

    .nav {
    width: 96%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 20px 2%;
}

.nav1 {
    display: flex;
    align-items: center;
}

.back {
    padding: 10px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    background: white;
    box-shadow: 0px 0px 10px #d0d0d0;
    font-size: 15px;
    color: #001930;
    font-weight: 500;
}

.project_txt {padding: 10px;border-radius: 5px;display: flex;align-items: center;background: white;box-shadow: 0px 0px 10px #d0d0d0;margin-left: 20px;}

.nav2 {
    display: flex;
    align-items: center;
}

.show_tags {
    padding: 10px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    background: white;
    box-shadow: 0px 0px 10px #d0d0d0;
}

.share {
    padding: 5px 10px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    background: white;
    box-shadow: 0px 0px 10px #d0d0d0;
    margin-left: 20px;
}

.members {
    display: flex;
    align-items: center;
    margin-right: 10px;
    padding: 0px 5px;
    padding-left: 15px;
    border-radius: 30px;
    cursor: pointer;
    transition: all .2s ease-in-out;
}

.member {
    width: 25px;
    height: 25px;
    border-radius: 100px;
    background: #9A35FF;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 600;
    color: white;
    margin-left: -10px;
    border: 2px solid white;
}

.share_btn {
    padding: 5px 10px;
    background: #3555FF;
    border-radius: 3px;
    font-size: 13px;
    font-weight: 500;
    color: white;
    margin-right: 15px;
    cursor: pointer;
}

.back span {
    font-size: 15px;
    margin-right: 5px;
}

.project_name {
    font-size: 15px;
    color: #001930;
    font-weight: 500;
    margin-right: 10px;
}

.project_txt span {
    font-size: 15px;
    color: #001930;
    font-weight: 500;
}

.line_bwt {
    height: 20px;
    width: 1px;
    background: darkgrey;
    margin: 0px 10px;
}

.project_type {
    font-size: 15px;
    color: #001930;
    font-weight: 500;
    margin-left: 10px;
}

.show_tags span {
    font-size: 15px;
    color: #001930;
    font-weight: 500;
}

.members span {
    font-size: 15px;
    color: #001930;
    font-weight: 500;
}

div#myKanban {
    width: 100%;
    overflow: auto;
}


.kanban-container {
    display: flex;
    width: fit-content !important;
}

.kanban-board {
    width: 300px !important;
    background: #DEE3EC;
    border-radius: 10px;
    height: fit-content;
    padding-bottom: 15px;
    margin-left: 20px !important;
    margin-right: 20px !important;
}

.kanban-board-header {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10px 0px;
}

.kanban-title-board {
    color: #586B91;
    font-size: 15px;
    font-weight: 600;
}

.kanban-title-button {
    display: none;
}

.kanban-item {
    width: 88%;
    padding: 10px 10px;
    background: white;
    margin: 10px auto;
    border-radius: 5px;
    position: relative;
}

.item_handle.drag_handler {position: absolute;top: 0;left: 0;width: 100%;height: 100%;cursor: pointer;}


.kanban-item.is-moving.gu-mirror {
        transform: rotate(3deg);
        height: auto !important
}

.gu-mirror {
	position: fixed !important;
	margin: 0 !important;
	z-index: 9999 !important
}

.gu-hide {
	display: none !important
}

.gu-unselectable {
	-webkit-user-select: none !important;
	-moz-user-select: none !important;
	-ms-user-select: none !important;
	user-select: none !important
}

.gu-transit {
	opacity: .2 !important;
	transform: rotate(0) !important
}

footer.create_task {
    width: 88%;
    padding: 10px 10px;
    background: white;
    margin: 10px auto;
    border-radius: 5px;
    position: relative;
    color: #526A95;
    text-align: center;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
}
textarea.form-control {
    width: 92%;
    padding: 10px 10px;
    background: white;
    margin: 10px 4%;
    border-radius: 5px;
    position: relative;
    border: none;
    outline: none;
}

.form-group button {
    padding: 5px 10px;
    background: #366cd9;
    border: none;
    font-size: 15px;
    font-weight: 500;
    color: white;
    margin-left: 12px;
    border-radius: 5px;
}
.form-group button:nth-child(2){
    background: white;
    color: black;
}
</style>
    </head>
    <body>
        <div class="nav">
            <div class="nav1">
                <div class="back"><span class="material-icons-outlined">arrow_back_ios_new</span>Workspace</div>
                <div class="project_txt">
                    <div class="project_name"><?php echo $name;?></div>
                    <div onclick="starred(this,'<?php echo $url;?>','<?php echo $id;?>','project')" class="page_starred">
                    <?php 
                    if($isstarred){
                      echo '
                      <span class="material-icons-outlined span_starred">star</span>';
                  }else{
                      echo '
                      <span class="material-icons">star_border</span>';
                  }
                  ?>
                    </div>
                    <div class="line_bwt"></div>
                    
                    <select onchange="change_project_type(this,'<?php echo $url;?>')">
                        <option <?php echo ($type=="Public")?"selected":""?>>Public</option>
                        <option <?php echo ($type=="Private")?"selected":""?>>Private</option>
                        <option <?php echo ($type=="Workspace Visible")?"selected":""?>>Workspace Visible</option>
                </select>
                    
                </div>
            </div>
            <div class="nav2">
                <div class="show_tags"><span class="material-icons-outlined">visibility</span></div>
                <div class="share">
                    <div onclick="project_invite('<?php echo $url?>')" class="members">


                    <?php

  
$admin_counter = 0;
$members_counter = 0;
$observers_counter = 0;
$show_extra = false;
if(!empty($admin)){
    $admin_ids = explode(',', $admin);
    foreach ($admin_ids as $admin_id) {
        if ($admin_counter >= 2) {
            $show_extra = true;
            break;
        }

        $user_sql = "SELECT * FROM users WHERE id=$admin_id";
        $user_result = $conn->query($user_sql);

        if ($user_result->num_rows > 0) {
        // output data of each row
        while($user_row = $user_result->fetch_assoc()) {
            echo '<div style="background: '.$user_row['color'].'" class="member">'.$user_row['name'][0].'</div>';
        }
        } else {
        // echo "0 results";
        }
        $admin_counter++;
    }
}


if(!empty($members)){
    $members_ids = explode(',', $members);
    
    foreach ($members_ids as $members_id) {
        if ($members_counter >= 2) {
            $show_extra = true;
            break;
        }
        $user_sql = "SELECT * FROM users WHERE id=$members_id";
        $user_result = $conn->query($user_sql);

        if ($user_result->num_rows > 0) {
        // output data of each row
        while($user_row = $user_result->fetch_assoc()) {
            echo '<div style="background: '.$user_row['color'].'" class="member">'.$user_row['name'][0].'</div>';
        }
        } else {
        // echo "0 results";
        }

        $members_counter++;
    }
}


if(!empty($observers)){
    $observers_ids = explode(',', $observers);
    
    foreach ($observers_ids as $observers_id) {
        if ($observers_counter >= 2) {
            $show_extra = true;
            break;
        }
        $user_sql = "SELECT * FROM users WHERE id=$observers_id";
        $user_result = $conn->query($user_sql);

        if ($user_result->num_rows > 0) {
        // output data of each row
        while($user_row = $user_result->fetch_assoc()) {
            echo '<div style="background: '.$user_row['color'].'" class="member">'.$user_row['name'][0].'</div>';
        }
        } else {
        // echo "0 results";
        }

        $observers_counter++;
    }
}

if($show_extra){
    echo '<div class="member">'.$admin_counter+$members_counter+$observers_counter+$observers_counter.'</div>';
}

?>
                    </div>
                    <div onclick="project_invite('<?php echo $url?>')" class="share_btn">Share</div>
                    <span class="material-icons-outlined">more_vert</span>
                </div>
            </div>
        </div>

        <div id="myKanban"></div>

        </div>
            <script src="./kanban.js"></script>
            <script>
            

             // Step 1: Get all elements with class 'board'
  const boards = document.querySelectorAll('.kanban-board');

// Step 2: Create the new 'div' element
const newDiv = document.createElement('div');
newDiv.textContent = 'Create new task';
newDiv.className = 'create_task';
newDiv.onclick = function() {
  alert(1);
};

// Step 3: Append the new 'div' to each 'board' element
boards.forEach(board => {
  board.appendChild("Asas");
});



              var KanbanTest = new jKanban({
                element: "#myKanban",
                gutter: "10px",
                responsivePercentage: true,
                itemHandleOptions:{
                  enabled: true,
                },
                click: function(el) {
                  console.log("Trigger on all items click!");
                },
                dropEl: function(el, target, source, sibling){
                  console.log(target.parentElement.getAttribute('data-id'));
                  console.log(el, target, source, sibling)
                },
                buttonClick: function(el, boardId) {
                  console.log(el);
                  console.log(boardId);
                  // create a form to enter element
                  var formItem = document.createElement("form");
                  formItem.setAttribute("class", "itemform");
                  formItem.innerHTML =
                    '<div class="form-group"><textarea class="form-control" rows="2" autofocus></textarea></div><div class="form-group"><button type="submit" class="btn btn-primary btn-xs pull-right">Submit</button><button type="button" id="CancelBtn" class="btn btn-default btn-xs pull-right">Cancel</button></div>';
        
                  KanbanTest.addForm(boardId, formItem);
                  formItem.addEventListener("submit", function(e) {
                    e.preventDefault();
                    var text = e.target[0].value;
                    KanbanTest.addElement(boardId, {
                      title: text
                    });
                    formItem.parentNode.removeChild(formItem);
                  });
                  document.getElementById("CancelBtn").onclick = function() {
                    formItem.parentNode.removeChild(formItem);
                  };
                },
                addItemButton: true,
                boards: [
                {
                    id: "To do",
                    title: "To do",
                    item: [
                      {
                        title: "Ad Creation"
                      },
                      {
                        title: "Send mail to client"
                      },
                      {
                        title: "Website Creation"
                      }
                    ]
                  },
                  {
                    id: "Working",
                    title: "Working",
                    item: [
                      {
                        title: "Board meeting"
                      },
                      {
                        title: "Follow ups"
                      }
                    ]
                  },
                  {
                    id: "Done",
                    title: "Done",
                    item: [
                      {
                        title: "Api intergration"
                      }
                    ]
                  }
                ]
              });
        
        
           
        
           
            </script>
    </body>
</html>