<?php
include '../../config.php';

if(isset($_GET['query'])){
    $query = $_GET['query'];
    Search_query($conn,$query);

}else{
    echo 'Not found';
}

function Search_query($conn,$query){

    $sql = "SELECT * FROM pages WHERE Name LIKE '%$query%'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="search_result">
            <div class="search_result_img"><div style="background:'.$row['color'].'" class="search_result_icon">'.$row['Name'][0].'</div></div>
            <div class="search_result_txt">
                <div class="search_result_name">'.$row['Name'].'</div>
                <div class="search_result_type">'.$row['type'].'</div>
            </div>
        </div>';
        }
    } else {
        echo "Not found";
    }
    
}
?>