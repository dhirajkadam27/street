<?php
include '../../config.php';

$old_data = "";
if(isset($_GET['userids'])){
    if(isset($_GET['url'])){
        $url = $_GET['url'];
        $userids = $_GET['userids'];
        if(isset($_GET['type'])){
            if($_GET['type']=="Members"){
                checkMembers($url,$conn,$userids);
            }else{
                checkObserver($url,$conn,$userids);
            }
        }else{
            echo 'type Not found';
        }
    }else{
        echo 'Url Not found';
    }
}else{
    echo 'User id Not found';
}

function checkMembers($url,$conn,$userids){
    $sql = "SELECT * FROM projects WHERE url = '$url' AND members!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['members'];
        $userids = $old_data.",".$userids;
        addMembers($url,$userids,$conn);
    } else {
        addMembers($url,$userids,$conn);
    }
  }

  function addMembers($url,$userids,$conn){
    $sql = "UPDATE projects SET members='$userids' WHERE url='$url'";
    if ($conn->query($sql) === TRUE) {
    echo "Added";
    } else {
    echo "Failed to add";
    }
  }



  
function checkObserver($url,$conn,$userids){
    $sql = "SELECT * FROM projects WHERE url = '$url' AND observers!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['observers'];
        $userids = $old_data.",".$userids;
        addObserver($url,$userids,$conn);
    } else {
        addObserver($url,$userids,$conn);
    }
  }

  function addObserver($url,$userids,$conn){
    $sql = "UPDATE projects SET observers='$userids' WHERE url='$url'";
    if ($conn->query($sql) === TRUE) {
    echo "Added";
    } else {
    echo "Failed to add";
    }
  }

?>