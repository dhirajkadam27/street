<?php
include '../../config.php';

if(isset($_GET['name'])){
    if(isset($_GET['url'])){
        if(isset($_GET['type'])){
            if(isset($_SESSION['id'])){
                $name = $_GET['name'];
                $url = $_GET['url'];
                $type = $_GET['type'];
                $id = $_SESSION['id'];
                create_page($conn,$name,$url,$type,$id);
            }else{
                echo 'no login';
            }
        }else{
            echo 'no type found';
        }
    }else{
        echo 'no url found';
    }
}else{
    echo 'no name found';
}

function create_page($conn,$name,$workspace_url,$type,$id){

    $url = $name;

       function generateShortUrl($url) {
        $url = strtolower($url);
        
        $url = str_replace(' ', '-', $url);
        
        $url = preg_replace('/[^a-z0-9-]/', '', $url);
        
        $url = preg_replace('/-+/', '-', $url);
        $url = trim($url, '-');
        
        // Return the short URL
        return $url;
    }

    $url = generateShortUrl($url);

    $sql = "INSERT INTO projects (admin,name,url,type,workspace_url,creation_log) VALUES ('$id','$name','$url','$type','$workspace_url', NOW())";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo $url;
        } else {
            echo "Failed to create";
        }

}

?>