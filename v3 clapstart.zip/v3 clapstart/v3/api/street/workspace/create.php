<?php
include '../../config.php';

if(isset($_SESSION['id'])){
    if(isset($_GET['name'])){
        if(isset($_GET['type'])){
            $id = $_SESSION['id'];
            $name = $_GET['name'];
            $type = $_GET['type'];
            workspace_create($conn,$id,$name,$type);
        }else{
            echo "not type found";
        }
    }else{
        echo "not name found";
    }
}else{
    echo 'Not loged in';
}


function workspace_create($conn,$id,$name,$type){

        $color = array(
           "linear-gradient(137deg, #FF2AD0 0%, #8D00B1 100%);",
           "linear-gradient(137deg, #6590FF 0%, #05379A 100%);",
           "linear-gradient(137deg, #FED235 0%, #D68424 100%);",
           "linear-gradient(137deg, #2CD35A 0%, #00924C 100%);",
           "linear-gradient(137deg, #FF6565 0%, #950000 100%);",
           "linear-gradient(137deg, #5E5E5E 0%, #2D2D2D 100%);"
       );
       
       $colorIndex = array_rand($color);
       $colorCode = $color[$colorIndex];

       $url = $name;

       function generateShortUrl($url) {
        $url = strtolower($url);
        
        $url = str_replace(' ', '-', $url);
        
        $url = preg_replace('/[^a-z0-9-]/', '', $url);
        
        $url = preg_replace('/-+/', '-', $url);
        $url = trim($url, '-');
        
        // Return the short URL
        return $url;
    }

    $url = generateShortUrl($url);

    $sql = "INSERT INTO workspaces (admin,name,url,type,color,creation_log) VALUES ('$id','$name','$url','$type','$colorCode', NOW())";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo $colorCode."cutit".$url;
        } else {
            echo "Failed to create";
        }
   }

?>