const socket = new WebSocket('ws://localhost:80'); // WebSocket server address

const messageInput = document.getElementById('messageInput');
const sendMessageButton = document.getElementById('sendMessageButton');
const messagesDiv = document.getElementById('messages');

socket.onopen = () => {
    console.log('WebSocket connection established.');
};

socket.onmessage = (event) => {
    displayMessage('Peer: ' + event.data);
};

socket.onclose = () => {
    console.log('WebSocket connection closed.');
};

sendMessageButton.addEventListener('click', () => {
    const message = messageInput.value;
    socket.send(message);
    displayMessage('You: ' + message);
    messageInput.value = '';
});

function displayMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.textContent = message;
    messagesDiv.appendChild(messageDiv);
}
