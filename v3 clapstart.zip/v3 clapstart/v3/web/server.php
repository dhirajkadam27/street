<?php
$address = 'localhost';
$port = 80;

$server = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_bind($server, $address, $port);
socket_listen($server);

$clientSockets = [];
$messages = [];

echo "WebSocket server running on $address:$port\n";

while (true) {
    $read = $clientSockets;
    $read[] = $server;

    socket_select($read, $write, $except, null);

    if (in_array($server, $read)) {
        $newClient = socket_accept($server);
        $clientSockets[] = $newClient;

        $clientIndex = array_search($newClient, $clientSockets);
        $welcomeMessage = "Welcome, Client #$clientIndex!";
        socket_write($newClient, $welcomeMessage, strlen($welcomeMessage));

        echo "New client connected. Total clients: " . count($clientSockets) . "\n";

        $key = array_search($server, $read);
        unset($read[$key]);
    }

    foreach ($read as $clientSocket) {
        $clientIndex = array_search($clientSocket, $clientSockets);
        $data = socket_read($clientSocket, 1024, PHP_BINARY_READ);
        
        if ($data === false) {
            unset($clientSockets[$clientIndex]);
            echo "Client #$clientIndex disconnected. Total clients: " . count($clientSockets) . "\n";
            continue;
        }

        $messages[] = "Client #$clientIndex: $data";

        foreach ($clientSockets as $otherClient) {
            if ($otherClient !== $clientSocket) {
                socket_write($otherClient, $data, strlen($data));
            }
        }
    }
}

socket_close($server);
?>
