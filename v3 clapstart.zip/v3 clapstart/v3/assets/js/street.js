
function invite(url){
    const invite = '<div id="invite"></div>';

    $('body').append($(invite));

    $('#invite').load('./invite_members.php?url='+url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  
}

function close_invite(){
    $('#invite').remove();
}

function open_workspace(div,url){

    const workspace_popup = `
    <div id="workspace_popup">
    <style>

    .workspace_popup {
        position: fixed;
        top: 2.5%;
        left: -90%;
        width: calc(100% - 150px);
        height: 95vh;
        background: white;
        border-radius: 15px;
        animation: popup 1s;
        transform: scale(0,0) translate(2020px, 0);
        animation-fill-mode: forwards;
        overflow: hidden;
    }
    
    .workspace_popup #store_nav_profile_box{
        display: none;
    }
    .workspace_popup .close_btn{
        margin-right: 20px;
    }
    @keyframes popup {
            100% {
                transform: scale(1,1) translate(0, 0);
                transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
                left: 110px;
            }
        }
    </style>
 
    <div class="workspace_popup">
           
    </div>
</div>
    `;
    
    close_open_workspace();
    $('body').append($(workspace_popup));

    $('.workspace').removeClass('workspace_active');
    $(div).addClass('workspace_active');
    $('.workspace_popup').css('display','block');
    $('.workspace_popup').load('./workspace.php?url='+url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  
}

function close_open_workspace(){
    if($('#workspace_popup').length){
        $('.workspace').removeClass('workspace_active');
        $('#workspace_popup').remove();
    }
}

function create_workspace(){
    const create_workspace = `
    <div id="create_workspace">
    <style>
    

    .create_workspace {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: #0000004a;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .create_workspace_popup {
        width: 400px;
        background: white;
        border-radius: 10px;
        padding: 20px;
        position: relative;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
    }
    
    .close_btn {
            padding: 2px;
            margin-right:10px;
            color: #78859D;
            cursor: pointer;
            transition: all .2s ease-in-out;
        }
        .close_btn:active{
            color: #636e81;
            transform: scale(0.99);
        }
        
        .close_btn span {
            font-size: 25px;
        }
    
    .create_workspace_popup .close_btn {
        position: absolute;
        right: 0;
        top: 10px;
    }
    
    .create_workspace_title {
        color: #001930;
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 15px;
    }
    
    .create_workspace_popup input {
        width: 70%;
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-right: 10px;
        display: block;
    }
    
    .create_workspace_popup input::placeholder{
            color: #78859D;
            font-size: 13px;
            font-weight: 500;
            font-family: Inter;
        }
    
    .create_workspace_popup select {
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-top: 20px;
    }
    
    .create_workspace_btn {
        padding: 5px 10px;
        border: none;
        background: #2698F0;
        color: white;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        width: fit-content;
        margin-top: 27px;
    }
    
    @keyframes popup {
                100% {
                    transform: scale(1,1) translate(0, 0);
                    transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
                }
            }
    
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>

    <div class="create_workspace">
    <div class="create_workspace_popup">
        <div class="create_workspace_title">Create new workspace</div>
        <div onclick="close_create_workspace()" class="close_btn"><span class="material-icons">cancel</span></div>
        <input id="workspace_name" type="text" placeholder="Workspace name">
        <select id="workspace_type">
            <option>Public</option>
            <option>Private</option>
        </select>
        <div onclick="create_workspace_api('add')" class="create_workspace_btn">Create</div>
    </div>
</div>

</div>
    `;
    $('body').append($(create_workspace));
}

function close_create_workspace(){
    $('#create_workspace').remove();
}

function starred(div,urls,userid,page){
    var type = "add";
    if($(div).find('span').hasClass('span_starred')){
        $(div).html('<span class="material-icons">star_border</span>');
         type = "remove";
    }else{
        $(div).html('<span class="material-icons-outlined span_starred">star</span>');
        type = "add";
    }

    $.ajax({
        url: "/api/street/page/starred.php",
        type: "GET",
        data: {
            userid: userid,
            url: urls,
            type: type
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no type"){
                oops("no type");
            }else if(response=="no userid"){
                oops("no userid");
            }else if(response=="no url"){
                oops("no url");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                if(page=="page"){
                    $(".workspace_page_left .workspace_page_link:eq(0)").click()
                }else if(page=="project"){
                    location.reload();
                }else{
                    $(".workspace_page_left .workspace_page_link:eq(1)").click()
                }
            }else{
                oops("failed");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });

}

function workspace_links(div,title,urls){

    var url = './pages.php?url='+urls;
    if(title=="Pages"){
        url = './pages.php?url='+urls;
    }else if(title=="Starred"){
        url = './starred.php?url='+urls;
    }else if(title=="Members"){
        url = './members.php?url='+urls;
    }else if(title=="Settings"){
        url = './settings.php?url='+urls;
    }else{
        url = './pages.php?url='+urls;
    }

    $('.workspace_page_link').css('color','#727884');
    $(div).css('color','#2698F0');

    $('#workspace_page_content').load(url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  

}


function workspace_tabs(div,title,urls){

    var url = './workspace_members.php?url='+urls;
    if(title=="Workspace members"){
        var url = './workspace_members.php?url='+urls;
    }else if(title=="Guests"){
        var url = './guests.php?url='+urls;
    }else if(title=="Pending"){
        var url = './pending.php?url='+urls;
    }else{
        var url = './workspace_members.php?url='+urls;
    }

    $('.member_tab').removeClass('member_tab_active');
    $(div).addClass('member_tab_active');

    $('#members_content').load(url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  

}


function settings_tabs(div,title,urls){

    var url = './workspace_settings.php?url='+urls;
    if(title=="Workspace"){
        var url = './workspace_setting.php?url='+urls;
    }else if(title=="Premission"){
        var url = './workspace_premission.php?url='+urls;
    }else{
        var url = './workspace_settings.php?url='+urls;
    }

    $('.settings_tab').removeClass('settings_tab_active');
    $(div).addClass('settings_tab_active');

    $('#settings_content').load(url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  

}


function workspace_color_label(){
    const workspace_color_label = `
    <div id="workspace_color_label">
    <style>

    .label {
        position: absolute;
        left: 10px;
        padding: 5px 10px;
        background: #ffffff;
        border-radius: 10px;
        font-size: 10px;
        font-weight: 500;
        color: #78859D;
        display: flex;
        justify-content: center;
        box-shadow: 0px 0px 10px #bababa;
        border: 1px solid #C5CEDF;
    }
    .label_corner {
        width: 15px;
        height: 15px;
        background: #d5ddec;
        position: absolute;
        top: -4px;
        left: 29px;
        transform: rotate(45deg);
        z-index: -1;
    }
    .color_btn {
        width: 40px;
        height: 40px;
        border-radius: 6px;
        margin: 5px;
        border: 1px solid white;
    outline: 2px solid #fff;
    outline-offset: 1px;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .color_btn_active{
        outline: 2px solid #bbbbdf;
    }
    .color_btn:active {
        transform: scale(0.88);
    }
    
    </style>
         
    <div class="label">
    <div class="label_corner"></div> 
    <div style="background: linear-gradient(137deg, #FF2AD0 0%, #8D00B1 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #FF2AD0 0%, #8D00B1 100%)')" class="color_btn"></div> 
    <div style="background: linear-gradient(137deg, #6590FF 0%, #05379A 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #6590FF 0%, #05379A 100%)')" class="color_btn"></div> 
    <div style="background: linear-gradient(137deg, #FED235 0%, #D68424 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #FED235 0%, #D68424 100%)')" class="color_btn"></div> 
    <div style="background: linear-gradient(137deg, #2CD35A 0%, #00924C 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #2CD35A 0%, #00924C 100%)')" class="color_btn"></div> 
    <div style="background: linear-gradient(137deg, #FF6565 0%, #950000 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #FF6565 0%, #950000 100%)')" class="color_btn"></div> 
    <div style="background: linear-gradient(137deg, #5E5E5E 0%, #2D2D2D 100%);" onclick="workspace_change_color(this,'linear-gradient(137deg, #5E5E5E 0%, #2D2D2D 100%)')" class="color_btn"></div> 
</div>


</div>
    `;


    if($('#workspace_color_label').length){
        close_workspace_color_label();
    }else{
        $('.workspace_setting_edit_workspace_setting_img').append($(workspace_color_label));
        $('.color_btn').each(function() {
            if ($(this).css('background') === $('#workspace_icon_color').css('background')) {
              $(this).addClass('color_btn_active');
            }
          });
    }
    
}

function close_workspace_color_label(){
    $('#workspace_color_label').remove();
}

function workspace_change_color(div,color){
    $('.color_btn').removeClass('color_btn_active');
    $('#workspace_icon_color').css('background',color);
    $(div).addClass('color_btn_active');
}


function create_page_screen(urls){
    const create_page_screen = `
    <div id="create_page_screen">
    <style>
    

    .create_page_screen {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: #0000004a;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .create_page_screen_popup {
        width: 400px;
        background: white;
        border-radius: 10px;
        padding: 20px;
        position: relative;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
    }
    
    .close_btn {
            padding: 2px;
            margin-right:10px;
            color: #78859D;
            cursor: pointer;
            border: none;
            background: white;
            transition: all .2s ease-in-out;
        }
        .close_btn:active{
            color: #636e81;
            transform: scale(0.99);
        }
        
        .close_btn span {
            font-size: 25px;
        }
    
    .create_page_screen_popup .close_btn {
        position: absolute;
        right: 0;
        top: 10px;
    }
    
    .create_page_screen_title {
        color: #001930;
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 15px;
    }
    
    .create_page_screen_popup input {
        width: 70%;
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-right: 10px;
        display: block;
    }
    
    .create_page_screen_popup input::placeholder{
            color: #78859D;
            font-size: 13px;
            font-weight: 500;
            font-family: Inter;
        }
    
    .create_page_screen_popup select {
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-top: 20px;
    }
    
    .create_page_screen_btn {
        padding: 5px 10px;
        border: none;
        background: #2698F0;
        color: white;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        width: fit-content;
        margin-top: 27px;
        cursor: pointer;
        display:block
    }
    
    @keyframes popup {
                100% {
                    transform: scale(1,1) translate(0, 0);
                    transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
                }
            }
    
    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>

    <div class="create_page_screen">
    <div class="create_page_screen_popup">
        <div class="create_page_screen_title">Create new page</div>
        <button onclick="close_create_page_screen()" class="close_btn"><span class="material-icons">cancel</span></button>
        <input type="text" id="pageinput" placeholder="page name">
        <select id="pageselect">
            <option>Public</option>
            <option>Private</option>
            <option>Workspace visible</option>
        </select>
        <button onclick="create_page_api('${urls}')" class="create_page_screen_btn">Create</button>
    </div>
</div>

</div>
    `;
    $('body').append($(create_page_screen));
}

function close_create_page_screen(){
    $('#create_page_screen').remove();
}

function create_workspace_api(txt){
        $.ajax({
            url: "/api/street/workspace/create.php",
            type: "GET",
            data: {
                name: $('#workspace_name').val(),
                type: $('#workspace_type').val()
            },
            dataType: 'text',
            success: function(response) {
                console.log(response);
                if(response=="not type found"){
                    oops("not type found");
                }else if(response=="not name found"){
                    oops("not name found");
                }else if(response=="Not loged in"){
                    window.location.href='/';
                }else if(response=="Failed to create"){
                    oops("Failed to create");
                }else{
                if(txt=="redirect"){
                    window.location.href='/street/';
                }
                if(txt=="add"){
                    var responsetxt = response.split("cutit");

                    $('.workspaces').prepend('<div onclick="open_workspace(this,'+"'"+responsetxt[1].trim()+"'"+')" style="background: '+responsetxt[0].trim()+'" class="workspace"><div class="workspace_initial">'+$('#workspace_name').val()[0]+'</div><div class="workspace_name">'+$('#workspace_name').val()+'</div></div>');
                    close_create_workspace();
                }
                }
            },
            error: function(xhr, status, error) {
                console.log('Unable to connect the server');
                oops("Unable to connect the server");
            }
        });
}

function search_users(){

               var userInput = $("#inviteEmail").val();
                var values = userInput.split(",");
                var lastValue = values[values.length - 1].trim();

                console.log("Last value: " + lastValue);


                var query = lastValue.trim();
    
        if (query !== '') {
          $.ajax({
            url: '/api/street/workspace/user_invition_src.php',
            method: 'GET',
            data: { query: query },
            success: function(response) {
                if(response=="Not found"){
                    $('#email_src').html('<div class="no_src">Not search found</div>');
                }else{
                    $('#email_src').html(response);
                }
              $('#email_src').show();
            }
          });
        } else {
          $('#email_src').hide();
        }


        var inviteEmail = $("#inviteEmail").val();
        var inviteids = $("#inviteid").val().split(",");
        var newIds = [];
        
        if (inviteids.length > 0) {
            $(".email_box").each(function() {
                var inviteEmailInList = $(this).data("email").toString();
                var inviteidInList = $(this).data("id").toString();
                
                if (inviteEmail.includes(inviteEmailInList)) {
                    newIds.push(inviteidInList);
                }
            });
        }
        
        $("#inviteid").val(newIds.join(","));

        

}


function invite_profile(div) {
    var inviteEmail = $(div).data("email");
    var inviteid = $(div).data("id");
    
    var inputValues = $("#inviteEmail").val();
                var valuesArray = inputValues.split(",");
                var filteredValues = [];

                for (var i = 0; i < valuesArray.length; i++) {
                    if (valuesArray[i].includes('@')) {
                        filteredValues.push(valuesArray[i].trim());
                    }
                }

                var filteredOutput = filteredValues.join(", ");
                $("#inviteEmail").val(filteredOutput);


            


    addSelectedUser(inviteEmail, inviteid);
}

function addSelectedUser(inviteEmail, inviteid) {
    var currentNames = $("#inviteEmail").val();
    var currentIds = $("#inviteid").val();
    
    if (currentNames !== "") {
        currentNames += ",";
        currentIds += ",";
    }
    
    $("#inviteEmail").val(currentNames + inviteEmail+",");
    $("#inviteid").val(currentIds + inviteid);
}


function invite_workspace_api(url){
    $.ajax({
        url: "/api/street/workspace/workspace_invite.php",
        type: "GET",
        data: {
            userids: $('#inviteid').val(),
            url: url,
            type: $('#invitetype').val()
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="User id Not found"){
                oops("User id Not found");
            }else if(response=="Url Not found"){
                oops("Url Not found");
            }else if(response=="Added"){
                location.reload();
            }else if(response=="Failed to add"){
                oops("Failed to add");
            }else if(response=="type Not found"){
                oops("type Not found");
            }else{
                oops("Failed to add");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function invite_project_api(url){
    $.ajax({
        url: "/api/street/page/project_invite.php",
        type: "GET",
        data: {
            userids: $('#inviteid').val(),
            url: url,
            type: $('#invitetype').val()
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="User id Not found"){
                oops("User id Not found");
            }else if(response=="Url Not found"){
                oops("Url Not found");
            }else if(response=="Added"){
                location.reload();
            }else if(response=="Failed to add"){
                oops("Failed to add");
            }else if(response=="type Not found"){
                oops("type Not found");
            }else{
                oops("Failed to add");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function remove_workspace_invition(type,userid,url){
    $.ajax({
        url: "/api/street/workspace/remove_workspace_users.php",
        type: "GET",
        data: {
            userid: userid,
            url: url,
            type: type
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no type found"){
                oops("no type found");
            }else if(response=="no url found"){
                oops("no url found");
            }else if(response=="no userid found"){
                oops("no url found");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to add");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function remove_project_invition(type,userid,url){
    $.ajax({
        url: "/api/street/page/remove_project_users.php",
        type: "GET",
        data: {
            userid: userid,
            url: url,
            type: type
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no type found"){
                oops("no type found");
            }else if(response=="no url found"){
                oops("no url found");
            }else if(response=="no userid found"){
                oops("no url found");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to add");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function change_workspace_invition(div,old,userid,url){
    if(old=="Admin"){
        old="admin";
    }else if(old=="Member"){
        old="members";
    }else if(old=="Observer"){
        old="observers";
    }
    var type;
    if($(div).val()=="Admin"){
        type="admin";
    }else if($(div).val()=="Member"){
        type="members";
    }else if($(div).val()=="Observer"){
        type="observers";
    }
    $.ajax({
        url: "/api/street/workspace/change_workspace_users.php",
        type: "GET",
        data: {
            userid: userid,
            url: url,
            type: type,
            old :old
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no old found"){
                oops("no old found");
            }else if(response=="no type found"){
                oops("no type found");
            }else if(response=="no url found"){
                oops("no url found");
            }else if(response=="no userid found"){
                oops("no userid found");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to change");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function change_project_invition(div,old,userid,url){
    if(old=="Admin"){
        old="admin";
    }else if(old=="Member"){
        old="members";
    }else if(old=="Observer"){
        old="observers";
    }
    var type;
    if($(div).val()=="Admin"){
        type="admin";
    }else if($(div).val()=="Member"){
        type="members";
    }else if($(div).val()=="Observer"){
        type="observers";
    }
    $.ajax({
        url: "/api/street/page/change_project_users.php",
        type: "GET",
        data: {
            userid: userid,
            url: url,
            type: type,
            old :old
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no old found"){
                oops("no old found");
            }else if(response=="no type found"){
                oops("no type found");
            }else if(response=="no url found"){
                oops("no url found");
            }else if(response=="no userid found"){
                oops("no userid found");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to change");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}


function pending_workspace_invition(userid,url,type){

    $.ajax({
        url: "/api/street/workspace/workspace_pending.php",
        type: "GET",
        data: {
            userid: userid,
            url: url,
            type:type
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no type"){
                oops("no type");
            }else if(response=="no url"){
                oops("no url");
            }else if(response=="no userid"){
                oops("no userid");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="failed"){
                oops("failed");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to change");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function workspace_setting_update(urls){

    $.ajax({
        url: "/api/street/workspace/update_workspace.php",
        type: "GET",
        data: {
            name: $('#update_workspace_setting_name').val(),
            color: $('#workspace_icon_color').css('background'),
            new_url:$('#update_workspace_setting_workspace_settingname').val(),
            url:urls,
            type:$('#workspace_type').val(),
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no name"){
                oops("no name");
            }else if(response=="no color"){
                oops("no colo");
            }else if(response=="no url"){
                oops("no url");
            }else if(response=="no type"){
                oops("no type");
            }else if(response=="no new url"){
                oops("no new url");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("Failed to change");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
}

function create_page_api(urls){
       $.ajax({
    url: "/api/street/page/create.php",
    type: "GET",
    data: {
        name: $('#pageinput').val(),
        url: urls,
        type: $('#pageselect').val()
    },
    dataType: 'text',
    success: function(response) {
        console.log(response);
        if(response=="no login"){
            oops("no login");
        }else if(response=="no type found"){
            oops("no type found");
        }else if(response=="Failed to create"){
            oops("Failed to create");
        }else if(response=="no url found"){
            oops("no url found");
        }else if(response=="no name found"){
            oops("no name found");
        }else{
            location.reload();
        }
    },
    error: function(xhr, status, error) {
        console.log('Unable to connect the server');
        oops("Unable to connect the server");
    }
});
}


function project_invite(url){
    const invite = '<div id="project_invite"></div>';

    $('body').append($(invite));

    $('#project_invite').load('../invite_project.php?url='+url, function (response, status, xhr) {
        if (status == "error") {
            targetDiv.html("Error loading content from the page.");
        }
    });  
}

function close_project_invite(){
    $('#project_invite').remove();
}

function change_project_type(div,urls){

    $.ajax({
        url: "/api/street/page/change_type.php",
        type: "GET",
        data: {
            url: urls,
            type: $(div).val()
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no url"){
                oops("no url");
            }else if(response=="no type"){
                oops("no type");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("failed");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });

}


function add_to_workspace(urls,userid){

    $.ajax({
        url: "/api/street/workspace/add_to_workspace.php",
        type: "GET",
        data: {
            url: urls,
            userid: userid
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            if(response=="no url"){
                oops("no url");
            }else if(response=="no userd"){
                oops("no userd");
            }else if(response=="Not Updated"){
                oops("Not Updated");
            }else if(response=="Updated"){
                location.reload();
            }else{
                oops("failed");
            }
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });

}