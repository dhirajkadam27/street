<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
 

         .main {
    width: 100%;
    height: calc(100vh - 50px);
    display: flex;
}


.home {
    display: flex;
    width: calc(100% - 290px);
    justify-content: space-between;
    margin: 20px;
}

.todays_task_title {
    color: #212121;
    font-size: 15px;
    font-weight: 700;
}

.todays_task {
    color: #78859D;
    font-size: 15px;
    font-weight: 400;
    margin-top: 10px;
}

.recent_title {
    color: #212121;
    font-size: 12px;
    font-weight: 400;
    margin-top:30px
}

.recent button {
    width: 250px;
    display: flex;
    align-items: center;
    padding: 10px;
    background: none;
    margin: 10px 0px;
    color: #212121;
    font-size: 12px;
    font-weight: 500;
    border-top: 1px solid #ececec;
}

.recent button  .workspace_icon {
    width: 30px;
    height: 30px;
    background: #c2c215;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 3px;
    margin-right: 10px;
    color: #212121;
}

.recent button:hover{
    background: #f7f7f7;
    filter: none !important;
}
       
      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
 <div class="main">
 <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
    <div class="home">
        <div class="task">
        <div class="todays_task_title">Today's</div>
        <div class="todays_task">Hurray! No task for today</div>
        </div>
        <div class="recent">
            <div class="recent_title">Recent Workspaces</div>
        <button><div class="workspace_icon">P</div> Private</button>
            <div class="recent_title">Recent Pages</div>
        <button>Project team</button>
        </div>
    </div>
 </div>
    
   </body>
</html>