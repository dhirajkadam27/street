<?php
$id = $_GET['id'];
?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .main {
         width: 100%;
         height: calc(100vh - 50px);
         display: flex;
         }
         .home {
         width: calc(100% - 250px);
         }


         .pendings_main {
    width: 100%;
    display: flex;
}

         .pendings_titles {
         font-size: 20px;
         font-weight: 600;
         color: #001930;
         margin-left: 20px;
         margin-top: 20px;
         margin-bottom: 20px;
         }


         .pendings_main_right_member {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    cursor: pointer;
         transition: all .2s ease-in-out; 
}

.pendings_main_right_member:hover{
   background: whitesmoke;
}

.pendings_main_right {
    width: calc(100% - 250px);
}

.pendings_main_right_member_info {
    display: flex;
    align-items: center;
}

.pendings_main_right_member_info img {
    width: 40px;
    margin-right: 10px;
}

.pendings_main_right_member_name {
    color: #212121;
    font-size: 15px;
    font-weight: 500;
}

.pendings_main_right_member_username {
    color: #212121;
    font-family: Inter;
    font-size: 12px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}

.pendings_main_right_member_actions button {
    margin: 0px 10px;
    background: #2698F0;
    padding: 5px 15px;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    font-weight: 500;
}
.pendings_main_right_member_actions button:nth-child(1) {
    background: #ff3131;
}
         
     
      </style>
   </head>
   <body>
      <?php
         include '../../sections/nav.php';
         ?>
      <div class="main">
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
         <div class="home">
          
         <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_topbar.php';
         ?>
            
            
            <div class="pendings_main">
            <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_members_slider.php';
         ?>
                <div class="pendings_main_right">
                     <div class="pendings_titles">Pendings</div>

                     <div id="all_pendings">
                           <?php
                        include $_SERVER['DOCUMENT_ROOT'] .'/modules/workspace-pendings.php';
                        ?>
                     </div>
                     
                     
                </div>
            </div>
     
    
         </div>
      </div>
   </body>
</html>