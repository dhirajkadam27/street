<?php

$id = $_GET['id'];
?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .main {
         width: 100%;
         height: calc(100vh - 50px);
         display: flex;
         }
         .home {
         width: calc(100% - 250px);
         }
   

         .members_main {
    width: 100%;
    display: flex;
}


         .members_titles {
         font-size: 20px;
         font-weight: 600;
         color: #001930;
         margin-left: 20px;
         margin-top: 20px;
         margin-bottom: 20px;
         }


         .members_main_right_member {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    cursor: pointer;
         transition: all .2s ease-in-out; 
}

.members_main_right_member:hover{
   background: whitesmoke;
}

.members_main_right {
    width: calc(100% - 250px);
}

.members_main_right_member_info {
    display: flex;
    align-items: center;
}

.members_main_right_member_info img {
    width: 40px;
    margin-right: 10px;
}

.members_main_right_member_name {
    color: #212121;
    font-size: 15px;
    font-weight: 500;
}

.members_main_right_member_username {
    color: #212121;
    font-family: Inter;
    font-size: 12px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}

.members_main_right_member_actions select {
    color: #212121;
    font-family: Inter;
    font-size: 12px;
    font-weight: 500;
    padding: 5px;
    border-radius: 3px;
    border: 1px solid #D8D8D8;
}

.members_main_right_member_actions button {
    margin: 0px 10px;
    background: #2698F0;
    padding: 5px 15px;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    font-weight: 500;
}
         
     
      </style>
   </head>
   <body>
      <?php
         include '../../sections/nav.php';
         ?>
      <div class="main">
        
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
         
         <div class="home">
       
             
         <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_topbar.php';
         ?>
            
            
            <div class="members_main">
            <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_members_slider.php';
         ?>
                <div class="members_main_right">
                     <div class="members_titles">Members</div>

                                          
                     <div id="all_workspace_members">
                              <?php
                           include $_SERVER['DOCUMENT_ROOT'] .'/modules/workspace-members.php';
                           ?>
                     </div>

                </div>
            </div>
     
    
         </div>
      </div>

      <script>
         function workspace_member_remove(id,type){
            
            $.ajax({
               url: "/api/remove-workspace-member.php",
               type: "GET",
               data: {
                  memid: id,
                  type: type,
                  url:'<?php echo $id; ?>'
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="true"){

                     $.get("/modules/workspace-members.php?id=<?php echo $id; ?>", function(data) {
                // Insert the loaded content into the container
                $("#all_workspace_members").html(data);
            });

                  }else{
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
               errorModal.show(errorModal);
            }
            });

         }
</script>
   </body>
</html>