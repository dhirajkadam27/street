<?php
$id = $_GET['id'];
?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .main {
         width: 100%;
         height: calc(100vh - 50px);
         display: flex;
         }

         .home {
         width: calc(100% - 250px);
         }

         .workspace_profile {
    display: flex;
    align-items: center;
    margin-left: 40px;
    margin-top: 40px;
    margin-bottom: 40px;
    cursor: pointer;
}

.workspace_profile:hover .workspace_profile_name button{
   display:inline
}

.workspace_profile_icon {
    width: 50px;
    height: 50px;
    background: #c2c215;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 3px;
    margin-right: 10px;
    color: #212121;
}

.workspace_profile_name {
    font-size: 15px;
    font-weight: 600;
    color: #001930;
}

.workspace_profile_type {
    font-size: 12px;
    font-weight: 500;
    color: #001930;
}
.workspace_profile_name button {
    margin-left: 12px;
    background: lightgrey;
    padding: 5px;
    border-radius: 100px;
    display:none;
         transition: all .2s ease-in-out; 
}   
.workspace_profile_name button span {
    font-size: 12px;
    color: #6e6e6e;
}

.workspace_join_txt {
    display: block;
    text-align: center;
    margin-top: 80px;
    font-size: 15px;
    color: #212121;
}

.workspace_join_btn {
    display: block;
    margin: 0px auto;
    background: #2698F0;
    padding: 5px 15px;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    font-weight: 500;
    margin-top: 20px;
}

      </style>
   </head>
   <body>
      <?php
         include '../../sections/nav.php';
         ?>
      <div class="main">
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
      
         <div class="home">

            <div class="workspace_profile">
               <div style="background: #1e88e0;" class="workspace_profile_icon">H</div>
               <div class="workspace_profile_txt">
                  <div class="workspace_profile_name">Hello World</div>
                  <div class="workspace_profile_type">Private</div>
               </div>
            </div>


            <div class="workspace_join_txt">
                You are not a member of this workspace
            </div>

            <button class="workspace_join_btn">Request</button>

            
            
      
            
        
         </div>
      </div>
   </body>
</html>