<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';
$id = $_GET['id'];
$workspace_name = "";
$workspace_url = "";

$sql = "SELECT * FROM workspaces WHERE url='$id'";

$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
   $workspace_name = $row["name"];
   $workspace_url = $row["url"];
} else {

}


?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .main {
         width: 100%;
         height: calc(100vh - 50px);
         display: flex;
         }

         .home {
         width: calc(100% - 250px);
         }



         .profile_main {
    width: 100%;
    display: flex;
}

         .profile_titles {
         font-size: 20px;
         font-weight: 600;
         color: #001930;
         margin-left: 20px;
         margin-top: 20px;
         margin-bottom: 20px;
         }

         .profile_main_right label {
    display: block;
    color: #212121;
    font-size: 10px;
    font-weight: 600;
    margin-top: 15px;
    margin-left: 20px;
}

.profile_main_right input {
    width: 300px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
    background: #f2f2f2;
    border-radius: 3px;
    font-size: 15px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
    margin-left: 20px;
}

.profile_main_right button {
    margin: 0px 10px;
    background: #2698F0;
    padding: 5px 20px;
    border-radius: 3px;
    color: white;
    font-size: 12px;
    font-weight: 500;
    margin-left: 20px;
    margin-top: 20px;
}
         
     
      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
      <div class="main">
        
          
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
            

         <div class="home">
                
         <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_topbar.php';
         ?>
            
            
            <div class="profile_main">
            <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_settings_slider.php';
         ?>
                <div class="profile_main_right">
                     <div class="profile_titles">Profile</div>

                        <label>Workspace Name</label>
                        <input type="email" id="name" value="<?php echo $workspace_name; ?>">
                        <label>Workspace URL</label>
                        <input type="text" id="new_url" value="<?php echo $workspace_url; ?>">

                        <button onclick="save_changes()">Save</button>

                </div>
            </div>
     
    
         </div>
      </div>


      <script>
              function save_changes(){
                
                $.ajax({
                       url: "/api/workspace_profile.php",
                       type: "GET",
                       data: {
                        name: $('#name').val(),
                 new_url: $('#new_url').val(),
                 url: '<?php echo $workspace_url; ?>'
                       },
                       dataType: 'text',
                       success: function(response) {
                          if(response=="true"){
                                 window.location.href = '/street/w/profile.php?id='+$('#new_url').val();
                          }else{
                       errorModal.show(errorModal);
                          }
                       },
                       error: function(xhr, status, error) {
                       errorModal.show(errorModal);
                    }
                    });
                    }
</script>


   </body>
</html>