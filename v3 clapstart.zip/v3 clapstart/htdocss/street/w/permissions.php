<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';
$id = $_GET['id'];
$workspace_type = "";

$sql = "SELECT * FROM workspaces WHERE url='$id'";

$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
   $workspace_type = $row["type"];
} else {

}


?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .main {
         width: 100%;
         height: calc(100vh - 50px);
         display: flex;
         }
      
         .home {
         width: calc(100% - 250px);
         }
         

         .permissions_main {
    width: 100%;
    display: flex;
}

         .permissions_titles {
         font-size: 20px;
         font-weight: 600;
         color: #001930;
         margin-left: 20px;
         margin-top: 20px;
         margin-bottom: 20px;
         }

         .permissions_main_right label {
    display: block;
    color: #212121;
    font-size: 10px;
    font-weight: 600;
    margin-top: 25px;
    margin-left: 20px;
}

.permissions_main_right button {
    margin: 0px 10px;
    background: #2698F0;
    padding: 5px 20px;
    border-radius: 3px;
    color: white;
    font-size: 12px;
    font-weight: 500;
    margin-left: 20px;
    margin-top: 20px;
}
.permissions_main_right select {
   appearance: none; /* This is used to hide the default arrow in some browsers */
  -webkit-appearance: none;
  -moz-appearance: none;
    width: 300px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f2f2f2;
    border-radius: 3px;
         font-family: Inter;
    font-size: 13px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
    margin-left: 20px;
    margin-top: 10px;
}
         
     
      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
      <div class="main">
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspaces_slider.php';
         ?>
         <div class="home">
        
         <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_topbar.php';
         ?>
            
            <div class="permissions_main">
            <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/workspace_settings_slider.php';
         ?>
                <div class="permissions_main_right">
                     <div class="permissions_titles">permissions</div>

                        <label>Workspace Visibility</label>
                        <select>
                            <option <?php echo $workspace_type=="Public"?"selected":"" ?>>Public</option>
                            <option <?php echo $workspace_type=="Private"?"selected":"" ?>>Private</option>
                        </select>
                        
                        <label>Who can invite members to workspace</label>
                        <select>
                            <option>Admin</option>
                            <option>Members</option>
                            <option>Anyone</option>
                        </select>

                        <label>Who can invite edit members</label>
                        <select>
                            <option>Admin</option>
                            <option>Members</option>
                            <option>Anyone</option>
                        </select> 
                        
                        <label>Who can create pages</label>
                        <select>
                            <option>Admin</option>
                            <option>Members</option>
                            <option>Anyone</option>
                        </select>

                        
                        <label>Who can join the private workspace</label>
                        <select>
                            <option>Anyone</option>
                            <option>Members</option>
                        </select>

                        <button>Save</button>

                </div>
            </div>
     
    
         </div>
      </div>
   </body>
</html>