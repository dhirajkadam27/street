<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';


// Get the search query from the front-end
if (isset($_GET['query'])) {
    $query = $_GET['query'];

    // SQL query to search for usernames or emails
    $sql = "SELECT * FROM users WHERE username LIKE '%$query%' OR mail LIKE '%$query%' LIMIT 10";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            echo '<div onclick="add_tagify_email(' ."'". $row['mail'] ."'". ')" class="invite_result">
            <img src="' . $row['icon'] . '">
            <div class="invite_result_txt">
               <div class="invite_result_name">' . $row['name'] . '</div>
               <div class="invite_result_username">@' . $row['username'] . '</div>
            </div>
         </div>';
        }
    } else {
        echo "No suggestions found";
    }
} else {
    echo "Some fields are empty";
    exit;
}

$conn->close();
?>