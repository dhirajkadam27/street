<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["name"]) && empty($_GET["name"]) &&
    !isset($_GET["new_url"]) && empty($_GET["new_url"])&&
    !isset($_GET["url"]) && empty($_GET["url"])) {
    echo "Some fields are empty";
    exit;
}


if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}

$name = $_GET['name'];
$new_url = $_GET['new_url'];
$url = $_GET['url'];

$sql = "UPDATE workspaces SET name='$name', url='$new_url' WHERE url='$url'";
if ($conn->query($sql) === true) {
    echo "true";
} else {
    echo "failed";
}

?>