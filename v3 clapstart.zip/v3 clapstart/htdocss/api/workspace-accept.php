<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["userid"]) && empty($_GET["userid"]) && 
    !isset($_GET["url"]) && empty($_GET["url"])) {
    echo "Some fields are empty";
    exit;
}
if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}


$userid = $_GET['userid'];
$url = $_GET['url'];

addUser($conn, $userid, $url);
removeUser($conn, $userid, $url);



// Function to add a user ID to the column
function addUser($conn, $userid, $url) {
    $userid = $conn->real_escape_string($userid);
    
    // Retrieve the current starred column data
    $sql = "SELECT * FROM workspaces WHERE  url= '$url'"; // Assuming id = 1 is your target row
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $members = $row['members'];
        
        // Check if the user ID is not already present
        if (strpos($members, $userid) === false) {
            if (empty($members)) {
                $members = $userid;
            } else {
                $members .= "," . $userid;
            }
            
            // Update the column with the new value
            $updateSql = "UPDATE workspaces SET members = '$members' WHERE url='$url'";
            $conn->query($updateSql);
            // echo "true";
        } else {
            echo "false";
        }
    } else {
        echo "false";
    }
}

// Function to remove a user ID from the column
function removeUser($conn, $userid, $url) {
    $userid = $conn->real_escape_string($userid);
    
    // Retrieve the current starred column data
    $sql = "SELECT * FROM workspaces WHERE url='$url'"; // Assuming id = 1 is your target row
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $guests = $row['guests'];
        
        // Check if the user ID is present and remove it
        if (!empty($guests)) {
            $guestsArray = explode(",", $guests);
            $updatedArray = array_diff($guestsArray, [$userid]);
            $updatedColumn = implode(",", $updatedArray);
            
            // Update the column with the new value
            $updateSql = "UPDATE workspaces SET guests = '$updatedColumn' WHERE url='$url'";
            $conn->query($updateSql);
            echo "true";
        } else {
            echo "false";
        }
    } else {
        echo "false";
    }
}



?>