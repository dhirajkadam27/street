<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["name"]) && empty($_GET["name"]) &&
    !isset($_GET["username"]) && empty($_GET["username"])&&
    !isset($_GET["gender"]) && empty($_GET["gender"])) {
    echo "Some fields are empty";
    exit;
}


if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}

$name = $_GET['name'];
$username = $_GET['username'];
$mail = $_SESSION['mail'];
$gender = $_GET['gender'];

$sql = "UPDATE users SET username='$username', name='$name', gender='$gender' WHERE mail='$mail'";
if ($conn->query($sql) === true) {
    update_login_session($conn,$name,$username,$gender);
} else {
    echo "failed";
}


function update_login_session($conn,$name,$username,$gender){
    $_SESSION["name"] = $name;
    $_SESSION["username"] = $username;
    $_SESSION["gender"] = $gender;
    echo "true";
    $conn->close();
}
?>