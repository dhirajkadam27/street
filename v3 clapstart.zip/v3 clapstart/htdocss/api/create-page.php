<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["name"]) && empty($_GET["name"]) && 
    !isset($_GET["type"]) && empty($_GET["type"]) && 
    !isset($_GET["workspace_url"]) && empty($_GET["workspace_url"])) {
    echo "Some fields are empty";
    exit;
}
if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}


$name = $_GET['name'];
$type = $_GET['type'];
$workspace_url = $_GET['workspace_url'];
$user_id = $_SESSION["user_id"];
$url = generateURL($conn,$name);

$sql = "INSERT INTO pages (name,type,workspace_url,admin,url,creation_log) VALUES ('$name','$type','$workspace_url','$user_id','$url',NOW())";

if ($conn->query($sql) === true) {
    echo "true";
} else {
    echo "false";
}



function generateURL($conn,$name) {
    $hash = md5($name);
    $shortID = substr($hash, 0, 6);
    while(check_url($conn,$shortID)){
        $name .= "c";
        $hash = md5($name);
        $shortID = substr($hash, 0, 6);
    }
    return $shortID;
}

function check_url($conn,$shortID){
    $query = "SELECT * FROM workspaces WHERE url='$shortID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        return true;
    } else {
        return false;
    }
}



?>