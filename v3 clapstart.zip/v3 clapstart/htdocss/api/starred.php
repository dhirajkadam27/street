<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["id"]) && empty($_GET["id"]) && 
    !isset($_GET["type"]) && empty($_GET["type"])) {
    echo "Some fields are empty";
    exit;
}
if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}


$id = $_GET['id'];
$type = $_GET['type'];
$user_id = $_SESSION['user_id'];
if($type=="Add"){
    addUser($conn, $user_id, $id);
}else{
    removeUser($conn, $user_id, $id);
}


// Function to add a user ID to the column
function addUser($conn, $user_id, $id) {
    $user_id = $conn->real_escape_string($user_id);
    
    // Retrieve the current starred column data
    $sql = "SELECT starred FROM pages WHERE id = $id"; // Assuming id = 1 is your target row
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $starred = $row['starred'];
        
        // Check if the user ID is not already present
        if (strpos($starred, $user_id) === false) {
            if (empty($starred)) {
                $starred = $user_id;
            } else {
                $starred .= "," . $user_id;
            }
            
            // Update the column with the new value
            $updateSql = "UPDATE pages SET starred = '$starred' WHERE id = $id";
            $conn->query($updateSql);
            echo "true";
        } else {
            echo "false";
        }
    } else {
        echo "false";
    }
}

// Function to remove a user ID from the column
function removeUser($conn, $user_id, $id) {
    $user_id = $conn->real_escape_string($user_id);
    
    // Retrieve the current starred column data
    $sql = "SELECT starred FROM pages WHERE id=$id"; // Assuming id = 1 is your target row
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $starred = $row['starred'];
        
        // Check if the user ID is present and remove it
        if (!empty($starred)) {
            $starredArray = explode(",", $starred);
            $updatedArray = array_diff($starredArray, [$user_id]);
            $updatedColumn = implode(",", $updatedArray);
            
            // Update the column with the new value
            $updateSql = "UPDATE pages SET starred = '$updatedColumn' WHERE id = $id";
            $conn->query($updateSql);
            echo "true";
        } else {
            echo "false2";
        }
    } else {
        echo "false1";
    }
}



?>