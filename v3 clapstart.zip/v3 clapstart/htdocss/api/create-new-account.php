<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["name"]) && empty($_GET["name"]) &&
    !isset($_GET["username"]) && empty($_GET["username"])&&
    !isset($_GET["gender"]) && empty($_GET["gender"])) {
    echo "Some fields are empty";
    exit;
}


if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}

$name = $_GET['name'];
$username = $_GET['username'];
$mail = $_SESSION['mail'];
$gender = $_GET['gender'];

$icon = profile_icon($gender);


    $sql = "UPDATE users SET username='$username', name='$name', gender='$gender', icon='$icon' WHERE mail='$mail'";
    if ($conn->query($sql) === true) {
        create_login_session($conn,check_id($conn, $mail),$name,$username,$mail,$gender,$icon);
    } else {
        echo "failed";
    }


    
function profile_icon($gender)
{
    if($gender=="Male"){
        $profile_icon = ["m1", "m2", "m3", "m4", "m5"];
    }else{
        $profile_icon = ["f1", "f2", "f3", "f4", "f5"];
    }

    $profile_icon_index = array_rand($profile_icon);
    $icon = $profile_icon[$profile_icon_index];

    return $icon;
}


    function check_id($conn, $mail)
    {
        $query = "SELECT user_id FROM users WHERE mail = '$mail'";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);
    
        if (mysqli_num_rows($result) > 0) {
            return $row["user_id"];
        } else {
            echo "failed";
            exit;
        }
    }
    
    function create_login_session($conn,$user_id,$name,$username,$mail,$gender,$icon){
        $_SESSION["user_id"] = $user_id;
        $_SESSION["name"] = $name;
        $_SESSION["username"] = $username;
        $_SESSION["mail"] = $mail;
        $_SESSION["gender"] = $gender;
        $_SESSION["icon"] = $icon;
        echo "login";
        $conn->close();
    }
?>