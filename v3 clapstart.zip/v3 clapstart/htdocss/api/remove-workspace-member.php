<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["memid"]) && empty($_GET["memid"]) && 
    !isset($_GET["type"]) && empty($_GET["type"])) {
    echo "Some fields are empty";
    exit;
}
if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}

$url = $_GET['url'];
$memid = $_GET['memid'];
$type = $_GET['type'];

    $user_id = $conn->real_escape_string($memid);
    
    // Retrieve the current starred column data
    $sql = "SELECT * FROM workspaces WHERE url='$url'"; // Assuming id = 1 is your target row
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $remove_member = $row[$type];
        
        // Check if the user ID is present and remove it
        if (!empty($remove_member)) {
            $remove_memberArray = explode(",", $remove_member);
            $updatedArray = array_diff($remove_memberArray, [$memid]);
            $updatedColumn = implode(",", $updatedArray);
            
            // Update the column with the new value
            $updateSql = "UPDATE workspaces SET $type = '$updatedColumn' WHERE  url='$url'";
            $conn->query($updateSql);
            echo "true";
        } else {
            echo "false2";
        }
    } else {
        echo "false1";
    }



?>