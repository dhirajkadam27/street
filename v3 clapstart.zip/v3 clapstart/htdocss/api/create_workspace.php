<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

if (!isset($_GET["name"]) && empty($_GET["name"]) && 
    !isset($_GET["type"]) && empty($_GET["type"])) {
    echo "Some fields are empty";
    exit;
}
if (!isset($_SESSION["mail"])){
    echo "You are not logged in. Please log in to access this page";
    exit;
}


$name = $_GET['name'];
$type = $_GET['type'];
$user_id = $_SESSION["user_id"];
$color = workspace_bg();
$url = generateURL($conn,$name);

$sql = "INSERT INTO workspaces (name,type,color,admin,url,creation_log) VALUES ('$name','$type','$color','$user_id','$url',NOW())";

if ($conn->query($sql) === true) {
    echo "true";
} else {
    echo "false";
}


    
function workspace_bg()
{
        $workspace_bg = ["#c2c215", "#18ac77", "#9660ff", "#6082ff", "#ff652b", "#fbb12a", "#7cd45f"];

    $workspace_bg_index = array_rand($workspace_bg);
    $bg = $workspace_bg[$workspace_bg_index];

    return $bg;
}

function generateURL($conn,$name) {
    $hash = md5($name);
    $shortID = substr($hash, 0, 6);
    while(check_url($conn,$shortID)){
        $name .= "c";
        $hash = md5($name);
        $shortID = substr($hash, 0, 6);
    }
    return $shortID;
}

function check_url($conn,$shortID){
    $query = "SELECT * FROM workspaces WHERE url='$shortID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        return true;
    } else {
        return false;
    }
}



?>