<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: white;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .street_logo {
         display: flex;
         align-items: center;
         justify-content: center;
         margin-top: 100px;
         }
         .street_logo img {
         height: 60px;
         border: 2px solid #dedede;
         border-radius: 5px;
         }
         .street_txt {
         color: #212121;
         font-size: 30px;
         font-weight: 700;
         margin-left: 10px;
         }
         .tagline {
         color: #212121;
         font-size: 60px;
         font-weight: 700;
         text-align: center;
         margin-top: 30px;
         }
         .subtagline {
         color: #212121;
         font-size: 13px;
         font-weight: 500;
         text-align: center;
         }
         .create_account_btn {
         border-radius: 3px;
         border: 1px solid #2698F0;
         background: #2698F0;
         color: white;
         font-size: 18px;
         font-weight: 600;
         height: 40px;
         padding: 0px 20px;
         margin: 10px auto;
         display: block;
         margin-top: 20px;
         }
         .footer_links {
         display: flex;
         justify-content: center;
         align-items: center;
         margin-top:100px
         }
         .footer_links a {
         color: #212121;
         font-size: 12px;
         font-weight: 500;
         margin: 10px 20px;
         }
         .footer_links a:hover {
         color: #0d6efd
         }
         .footer_copyright {
         text-align: center;
         color: #212121;
         font-size: 12px;
         font-weight: 500;
         }
      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
      <div class="street_logo">
         <img src="/assets/img/street.svg">
         <div class="street_txt">Street</div>
      </div>
      <div class="tagline">Your Team, Our Solutions</div>
      <div class="subtagline">Project management tool</div>
      <button onclick="window.location.href='/auth/sign-up.html'" class="create_account_btn">Try for free</button>
      <div class="footer_links">
         <a href="#">About</a>
         <a href="#">Contact</a>
         <a href="#">Jobs</a>
         <a href="#">Terms</a>
         <a href="#">Privacy</a>
      </div>
      <div class="footer_copyright">© Copyright 2023, Clapstart, Inc. All rights reserved.</div>
   </body>
</html>