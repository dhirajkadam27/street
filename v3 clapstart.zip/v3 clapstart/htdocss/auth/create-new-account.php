<?php
   session_start();

    if(!isset($_SESSION['mail'])){
        header("Location: ./log-in.php");
        exit;
    }
    $mail = $_SESSION['mail']
?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background: #fafafa;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .box {
         width: 400px;
         background: white;
         margin: 20px auto;
         box-shadow: 0px 0px 10px 0px #e5e5e5;
         border-radius: 4px;
         padding: 20px;
         margin-top: 50px;
         }
         .logo {
         height: 30px;
         display: block;
         margin: 0px auto;
         }
         .title {
         color: #212121;
         font-size: 20px;
         font-weight: 700;
         margin-top: 30px;
         }
         .subtitle {
         color: #212121;
         font-size: 12px;
         font-weight: 400;
         margin-top: 3px;
         }
         .subtitle a{
         font-weight: 600;
         color: #2698F0;
         }

         .box label {
    display: block;
    color: #212121;
    font-size: 10px;
    font-weight: 600;
    margin-top: 15px;
}

    .box input {
    width: 100%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
    background: #f2f2f2;
    border-radius: 3px;
    font-size: 15px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}
.box input:disabled {
            cursor: not-allowed;
        }

.box select {
   appearance: none; /* This is used to hide the default arrow in some browsers */
  -webkit-appearance: none;
  -moz-appearance: none;
    width: 100%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
    background: #f2f2f2;
    border-radius: 3px;
         font-family: Inter;
    font-size: 15px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}


         .box button {
         width: 100%;
         height: 40px;
         display: flex;
         align-items: center;
         justify-content: center;
         margin: 20px 0px;
         background: #2698F0;
         border-radius: 3px;
         font-size: 15px;
         font-weight: 500;
         color: white;
         }

         .logout{
            background:#ababab !important;
         }
         .footer_copyright {
         text-align: center;
         color: #6B6B6B;
         font-size: 12px;
         font-weight: 500;
         margin-top: 50px;
         }

      </style>
   </head>
   <body>
      <div class="box">
         <img class="logo" src="/assets/img/logo.svg">
         <div class="title">Create an account</div>
         <div class="subtitle">Already have an account? <a href="/auth/log-in.php">Log In</a></div>
         <form id="myForm">
         <label>Mail Id</label>
         <input required type="email" disabled value="<?php echo $mail ?>">
         <label>Full Name</label>
         <input id="name" required type="text">
         <label>Username</label>
         <input id="username" required type="text">
         <label>Gender</label>
         <select id="gender" required>
            <option>Male</option>
            <option>Female</option>
         </select>
         <button>Create account</button>
      </form>
         <button class="logout" onclick="window.location.href='/auth/log-out.php'">Logout</button>
      </div>
      <div class="footer_copyright">© Copyright 2023, Clapstart, Inc. All rights reserved.</div>

      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/modules/error.php';
         ?>
      
      <script>



document.getElementById("myForm").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting and reloading the page
        
 
        $.ajax({
               url: "/api/create-new-account.php",
               type: "GET",
               data: {
			username: $('#username').val(),
			name: $('#name').val(),
			gender: $('#gender').val()
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="login"){
                         window.location.href = '/store.php';
                  }else{
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
               errorModal.show(errorModal);
            }
            });
        
        console.log("Form submitted, but page will not reload");
    });

      </script>



   </body>
</html>