<?php
   session_start();

if(isset($_SESSION['user_id'])){
    header("Location: /store.php");
    exit;
}else{
    if(isset($_SESSION['mail'])){
        header("Location: ./sign-up.php");
        exit;
    }
}
?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


      <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>

    <script type="module">
        var stream = null;
        // Import the functions you need from the SDKs you need
        import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
        import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-analytics.js";
        // TODO: Add SDKs for Firebase products that you want to use
        // https://firebase.google.com/docs/web/setup#available-libraries
        
        // Your web app's Firebase configuration
        // For Firebase JS SDK v7.20.0 and later, measurementId is optional
        const firebaseConfig = {
        apiKey: "AIzaSyABfZ1GZ9Eti6e50EgOGkQqJ1s5nzCoIRc",
        authDomain: "clapstart-1492e.firebaseapp.com",
        projectId: "clapstart-1492e",
        storageBucket: "clapstart-1492e.appspot.com",
        messagingSenderId: "953994364799",
        appId: "1:953994364799:web:5269e513f208af7fca3c4a",
        measurementId: "G-HLT4ZP6LHC"
        };
        
        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
        
        
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        </script>

      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background: #fafafa;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
         .box {
         width: 400px;
         background: white;
         margin: 20px auto;
         box-shadow: 0px 0px 10px 0px #e5e5e5;
         border-radius: 4px;
         padding: 20px;
         margin-top: 50px;
         }
         .logo {
         height: 30px;
         display: block;
         margin: 0px auto;
         }
         .title {
         color: #212121;
         font-size: 20px;
         font-weight: 700;
         margin-top: 30px;
         }
         .subtitle {
         color: #212121;
         font-size: 12px;
         font-weight: 400;
         margin-top: 3px;
         }
         .subtitle a{
         font-weight: 600;
         color: #2698F0;
         }
         .box button {
         width: 100%;
         height: 40px;
         display: flex;
         align-items: center;
         justify-content: center;
         margin: 20px 0px;
         background: #f2f2f2;
         border-radius: 3px;
         font-size: 15px;
         font-weight: 500;
         color: #212121;
         }
         .box button img{
         height: 15px;
         margin-right: 10px;
         }
         .footer_copyright {
         text-align: center;
         color: #6B6B6B;
         font-size: 12px;
         font-weight: 500;
         margin-top: 50px;
         }


      </style>
   </head>
   <body>
      <div class="box">
         <img class="logo" src="/assets/img/logo.svg">
         <div class="title">Log In</div>
         <div class="subtitle">New user? <a href="/auth/sign-up.php">Create an account</a></div>
         <button onclick="google()"><img src="/assets/img/google.webp">Sign In with Google</button>
         <button onclick="apple()"><img src="/assets/img/apple.svg">Sign In with Apple</button>
      </div>
      <div class="footer_copyright">© Copyright 2023, Clapstart, Inc. All rights reserved.</div>

      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/modules/error.php';
         ?>


      <script>

            function google() {
            const googleProvider = new firebase.auth.GoogleAuthProvider();
            firebase.auth().signInWithPopup(googleProvider).then((result) => {
                const user = result.user;
                login(user.email);
            }).catch((error) => {
               errorModal.show(errorModal);
            });
        }

    function apple() {
            const appleProvider = new firebase.auth.OAuthProvider('apple.com');
            firebase.auth().signInWithPopup(appleProvider).then((result) => {
                const user = result.user;
                login(user.email);

            }).catch((error) => {
               errorModal.show(errorModal);
            });
        }


        function login(mail){
            
            $.ajax({
               url: "/api/auth.php",
               type: "GET",
               data: {
                  mail: mail
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="login"){
                         window.location.href = '/store.php';
                  }else if(response=="account setup"){
                         window.location.href = '/auth/create-new-account.php';
                  }else{
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
               errorModal.show(errorModal);
               }
            });
                 }

      </script>

   </body>
</html>