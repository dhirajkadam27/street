<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

$user_id = $_SESSION["user_id"];

$sql = "SELECT * FROM workspaces WHERE FIND_IN_SET('$user_id', admin) OR FIND_IN_SET('$user_id', members) OR FIND_IN_SET('$user_id', observers)";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<button onclick="window.location.href='."'".'/street/w/?id='.$row['url'].''."'".'">
        <div style="background: '.$row['color'].';" class="workspace_icon">'.$row['name'][0].'</div>
        <div class="workspace_txt">'.$row['name'].'</div>
     </button>
    ';
    }
}

?>