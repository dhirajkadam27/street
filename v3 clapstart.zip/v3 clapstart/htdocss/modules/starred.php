<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';

$user_id = $_SESSION["user_id"];
?>
<style>


         .pages_box {
         display: flex;
         flex-wrap: wrap;
         padding: 20px;
         }
         .create_page {
         width: 150px;
         height: 200px;
         background: #4E85F0;
         display: flex;
         justify-content: center;
         align-items: center;
         flex-wrap: wrap;
         border-radius: 10px;
         margin: 10px;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .create_page span {width: 100%;text-align: center;font-size: 20px;color: white;height: 20px;}
         .create_page_txt {
         width: 100%;
         text-align: center;
         font-size: 15px;
         font-weight: 500;
         color: white;
         height: 20px;
         }
         .page_box {
         width: 150px;
         height: 200px;
         background: white;
         display: flex;
         justify-content: center;
         align-items: center;
         flex-wrap: wrap;
         border-radius: 10px;
         border: 1px solid #E1E6F0;
         margin: 10px;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .page_icon {
         width: 100%;
         height: 150px;
         display: flex;
         align-items: center;
         justify-content: center;
         }
         .page_icon img {
         width: 60px;
         height: 60px;
         }
         .page_box_bottom {
         display: flex;
         align-items: center;
         justify-content: space-between;
         width: 100%;
         }
         .page_name {
         width: 70%;
         white-space: nowrap;
         overflow: hidden;
         text-overflow: ellipsis;
         font-size: 12px;
         font-weight: 500;
         color: #001930;
         padding: 0px 5%;
         }
         .page_starred span {
         color: #001930;
         font-size: 17px;
         }
         .page_starred {
         width: 20%;
         display: flex;
         align-items: center;
         justify-content: center;
         }
         .span_starred{
         color: #4E85F0 !important;
         }

    </style>

<?php
               $sql = "SELECT * FROM pages WHERE FIND_IN_SET('$user_id', starred)";

               $result = $conn->query($sql);
               
               if ($result->num_rows > 0) {
                  echo '<div class="pages_titles">Starred Pages</div>
                  <div class="pages_box">';
                  while ($row = $result->fetch_assoc()) {
                      echo '<div class="page_box">
                      <button onclick="window.location.href='."'".'/street/p/?id='.$row['url'].''."'".'" class="page_icon">
                         <img src="/assets/img/street.svg">
                      </button>
                      <div class="page_box_bottom">
                         <div class="page_name">'.$row['name'].'</div>
                         <button onclick="starred('.$row['id'].',this)" class="page_starred">

                         ';
                         $isstarreddata = explode(",", $row['starred']);

                         if (in_array($user_id, $isstarreddata)) {
                          echo '<span class="material-icons-outlined">star</span>';
                         }else{
                          echo '<span class="material-icons">star_border</span>';
                         }
                         echo '
                         </button>
                      </div>
                   </div>';
                  }
                   echo '</div>';
               }
?>

<script>
 function starred(id,div){
                  console.log(div.innerText);
                  var type = "Add";
                  if(div.innerText=="star_border"){
                  var type = "Add";
                     $(div).html('<span class="material-icons-outlined">star</span>');
                  }else{
                  var type = "Remove";
                     $(div).html('<span class="material-icons">star_border</span>');
                  }

                  $.ajax({
               url: "/api/starred.php",
               type: "GET",
               data: {
                  id: id,
                  type: type
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="true"){

                     $.get("/modules/pages.php", function(data) {
                // Insert the loaded content into the container
                $("#all_pages").html(data);
            });
                    $.get("/modules/starred.php", function(data) {
                // Insert the loaded content into the container
                $("#all_starred").html(data);
            });

                  }else{
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
               errorModal.show(errorModal);
            }
            });


               }

</script>