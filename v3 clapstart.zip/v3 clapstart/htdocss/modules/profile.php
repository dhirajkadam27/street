<?php
$user_id = $_SESSION["user_id"];
$name = $_SESSION["name"];
$username = $_SESSION["username"];
$mail = $_SESSION["mail"];
$gender = $_SESSION["gender"];
$icon = $_SESSION["icon"];
?>
<style>
   .profile_dropdown {
   text-align: center;
   }
   .profile_dropdown img {
      width: 45px;
    margin-bottom: 10px;
    margin-top: 10px;
   }
   .profile_dropdown_name {
   color: #212121;
   font-size: 12px;
   font-weight: 600;
   }
   .profile_dropdown_username {
   color: #212121;
   font-size: 12px;
   font-weight: 400;
   }
   .profile_dropdown_btn {
   width: 85%;
   border-radius: 3px;
   border: 1px solid #b3b3b3;
   background: #FFF;
   color: #212121;
   font-size: 12px;
   font-weight: 500;
   padding: 2px 10px;
   margin: 10px 0px;
   }
   .dropdown_btn {
   width: 85%;
   border-radius: 3px;
   background: #FFF;
   color: #212121;
   font-size: 12px;
   font-weight:500;
   text-align: left;
   padding: 2px 10px;
   margin: 3px 0px;
   }
</style>
<div class="profile_dropdown">
   <img src="/assets/img/avatar/<?php echo $icon ?>.png">
   <div class="profile_dropdown_name"><?php echo $name ?></div>
   <div class="profile_dropdown_username">@<?php echo $username ?></div>
   <button onclick="window.location.href='/me/'" class="profile_dropdown_btn">View Profile</button>
   <button onclick="window.location.href='/store.php'" class="dropdown_btn">All Products</button>
   <button onclick="window.location.href='/auth/log-out.php'" class="dropdown_btn">Sign out</button>
</div>