<style>
   .search_inputs {
   display: flex;
   align-items: center;
   padding: 5px 10px;
   }
   .search_inputs select {
   color: #3b3b3b;
   font-family: Inter;
   font-size: 12px;
   font-weight: 500;
   width: 120px;
   height: 30px;
   background: #ededed;
   border: none;
   border-radius: 4px;
   }
   .search_inputs input {
   color: #212121;
   font-family: Inter;
   font-size: 12px;
   font-weight: 400;
   width: calc(100% - 160px);
   height: 40px;
   background: #ffffff;
   border: none;
   border-radius: 4px;
   margin-left: 10px;
   outline: none;
   }
   .search_inputs button {
   width: 25px;
   background: #e3e3e3;
   height: 25px;
   border-radius: 3px;
   }
   .search_inputs button span {
   font-size: 18px;
   color: #919191;
   }
   .add_inputs {
   display: flex;
   align-items: center;
   border-bottom: 1px solid #e8e8e8;
   padding-bottom: 12px;
   }
   .add_inputs button {
   margin: 0px 10px;
   padding: 2px 10px;
   border-radius: 5px;
   background: #e2e2e2;
   color: #212121;
   font-family: Inter;
   font-size: 12px;
   font-weight: 400;
   }
   .add_inputs_txt {
   font-size: 12px;
   color: #212121;
   margin-left: 13px;
   font-weight: 500;
   }
   .results {
   padding-top: 10px;
   }
   .result {
   display: flex;
   align-items: center;
   margin: 10px 15px;
   border-radius: 5px;
   transition: all .2s ease-in-out; 
   cursor: pointer;
   }
   .result:hover{
   background: #f0f0f0;
   }
   .result_icon {
   width: 45px;
   height: 45px;
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 4px;
   margin-right: 10px;
   font-size: 20px;
   font-weight: 500;
   color: #212121;
   }
   .result_icon span {
   font-size: 22px;
   color: #212121;
   }
   .result_icon img {
   width: 50px;
   }
   .result_name {
   font-size: 12px;
   font-weight: 600;
   color: #212121;
   }
   .result_type {
   font-size: 10px;
   font-weight: 400;
   color: #212121;
   }
</style>
<div class="search_popup">
   <div class="search_inputs">
      <select>
         <option>All of Clapstart</option>
         <option>Street</option>
         <input placeholder="Search your query">
         <button onclick="$('body').click();"><span class="material-icons-outlined">close</span></button>
      </select>
   </div>
   <div class="add_inputs">
      <div class="add_inputs_txt">Search for:</div>
      <button>All</button>
      <button>Users</button>
      <button>Workspaces</button>
      <button>Site Pages</button>
      <button>Pages</button>
   </div>
   <div class="results">
      <div class="result">
         <div class="result_icon"><span class="material-icons-outlined">link</span></div>
         <div class="result_txt">
            <div class="result_name">Street</div>
            <div class="result_type">Site Page</div>
         </div>
      </div>
      <div class="result">
         <div class="result_icon"><img src="/assets/img/avatar/m1.png"></div>
         <div class="result_txt">
            <div class="result_name">Dhiraj Kadam</div>
            <div class="result_type">@dhirajkadam</div>
         </div>
      </div>
      <div class="result">
         <div class="result_icon"><span class="material-icons-outlined">subject</span></div>
         <div class="result_txt">
            <div class="result_name">Page name</div>
            <div class="result_type">Private - Workspace name</div>
         </div>
      </div>
      <div class="result">
         <div class="result_icon">
            <div class="result_workspace_icon">D</div>
         </div>
         <div class="result_txt">
            <div class="result_name">Workspace name</div>
            <div class="result_type">Private</div>
         </div>
      </div>
   </div>
</div>