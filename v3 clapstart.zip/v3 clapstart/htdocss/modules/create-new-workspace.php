<style>
        .modal-content{
            border:none
         }

         .modal_close_btn{
            margin-left: auto;
    margin-right: 20px;
    margin-top: 20px;
    margin-bottom: -15px;
    position: relative;
    z-index: 10;
         }

         .modal_title {
    margin-left: 20px;
    margin-bottom: 10px;
    font-size: 15px;
    font-weight: 600;
    color: #212121;
}

.modal_label {
    margin-left: 20px;
    font-size: 12px;
    font-weight: 400;
    color: #212121;
    margin-bottom: 5px;
    margin-top: 10px;
}

input.modal_input {
    width: 300px;
    margin-left: 20px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 2px;
    background: #f2f2f2;
    border-radius: 3px;
    font-size: 13px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}

.modal_select {
    width: 300px;
    margin-left: 20px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 2px;
    background: #f2f2f2;
    border-radius: 3px;
    font-size: 13px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}

.modal-footer {
    border: none;
    margin-top: 15px;
}

.modal-footer button {
    padding: 0px 20px;
    height: 30px;
    background: #2698F0;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
    color: white;
}

.modal-footer button:nth-child(1){
    background: #e4e4e4;
    color: #212121;
}
</style>
<div class="modal fade" id="create_new_workspace" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <button class="modal_close_btn" data-bs-dismiss="modal"><span class="material-icons-outlined">clear</span></button>
     <div class="modal_title">Create new workspace</div>
<form id="create_new_workspace_form">
            <div class="modal_label">Workspace Name</div>
            <input required class="modal_input" id="workspace_name" type="text">
            
            <div class="modal_label">Workspace Visibility</div>
         <select id="workspace_type" required class="modal_select">
            <option>Public</option>
            <option>Private</option>
         </select>
      <div class="modal-footer">
        <button onclick="event.preventDefault();" data-bs-dismiss="modal">Close</button>
        <button>Create</button>
</form>
      </div>
    </div>
  </div>
</div>

<script>
    var newWorkspaceModal = new bootstrap.Modal(document.getElementById('create_new_workspace'));


document.getElementById("create_new_workspace_form").addEventListener("submit", function(event) {
        event.preventDefault();
        
        
        $.ajax({
               url: "/api/create_workspace.php",
               type: "GET",
               data: {
                name: $('#workspace_name').val(),
			type: $('#workspace_type').val()
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="true"){
                    newWorkspaceModal.hide();

                    $.get("/modules/workspaces.php", function(data) {
                // Insert the loaded content into the container
                $("#all_workspaces").html(data);
            });

                  }else{
                    newWorkspaceModal.hide();
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
                newWorkspaceModal.hide();
               errorModal.show(errorModal);
            }
            });
        

        console.log("Form submitted, but page will not reload");
    });
</script>