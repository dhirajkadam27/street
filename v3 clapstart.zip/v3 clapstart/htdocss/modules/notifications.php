<style>
   .notification_popup_nav {
   display: flex;
   align-items: center;
   justify-content: space-between;
   padding: 15px 0px;
   margin: 0px 15px;
   border-bottom: 1px solid #e8e8e8;
   }
   .notification_popup_nav_title {
   color: #212121;
   font-size: 20px;
   font-weight: 600;
   }
   .notification_popup_nav_options {
   display: flex;
   align-items: center;
   }
   .form-check.form-switch {
   margin-left: 10px;
   font-size: 20px;
   }
   .form-check-input:checked {
   background-color: #4CAF50;
   border-color: #4caf50;
   }
   .notification_popup_nav_options_txt {
   color: #6B6B6B;
   font-size: 10px;
   font-weight: 500;
   margin-top: 5px;
   }
   .notification_empty {
   width: 90%;
   height: 50px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: #f3f3f3;
   margin: 10px auto;
   border-radius: 5px;
   color: #212121;
   font-size: 12px;
   font-weight: 500;
   }
   .notification_msg {
   width: 90%;
   height: 50px;
   display: flex;
   align-items: center;
   padding: 15px;
   background: #f3f3f3;
   margin: 10px auto;
   border-radius: 5px;
   color: #212121;
   font-size: 12px;
   font-weight: 500;
   }
</style>
<div class="notification_popup_nav">
   <div class="notification_popup_nav_title">Notifications</div>
   <div class="notification_popup_nav_options">
      <div class="notification_popup_nav_options_txt">Show only unread</div>
      <div class="form-check form-switch">
         <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
      </div>
   </div>
</div>
<div class="notification_empty">
   No Notifications Yet.
</div>
<div class="notification_empty">
   No Unread Notifications.
</div>
<div class="notification_msg">
   You are added to facebook Workspace
</div>
<div class="notification_msg">
   New message from facebook Workspace
</div>
<div class="notification_msg">
   New message from Design team page
</div>