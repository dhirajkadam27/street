
<?php
include $_SERVER['DOCUMENT_ROOT'] .'/api/config.php';
$id=$_GET['id'];

               $sql = "SELECT * FROM workspaces WHERE url='$id'";

               $result = $conn->query($sql);
               
               if ($result->num_rows > 0) {
                   while ($row = $result->fetch_assoc()) {

                     $values = explode(',', $row['admin']);

                     foreach ($values as $value) {
                        if (!empty($value)) { 
                           $user_sql = "SELECT * FROM users WHERE user_id=$value";
                           $user_result = $conn->query($user_sql);
                           
                           if ($user_result->num_rows > 0) {
                              if($user_row = $user_result->fetch_assoc()) {
                                 echo '<div class="members_main_right_member">
                                 <div class="members_main_right_member_info">
                                    <img src="/assets/img/avatar/'.$user_row['icon'].'.png">
                                    <div class="members_main_right_member_txt">
                                    <div class="members_main_right_member_name">'.$user_row['name'].'</div>
                                    <div class="members_main_right_member_username">@'.$user_row['username'].'</div>
                                    </div>
                                 </div>
                                 <div class="members_main_right_member_actions">
                                    <select>
                                       <option selected>Admin</option>
                                       <option>Member</option>
                                       <option>Observer</option>
                                    </select>
                                    <button onclick="workspace_member_remove('.$value.','."'admin'".')">Remove</button>
                                 </div>
                              </div>';
                              }
                           }
                        }
                       
                     }

                     $values = explode(',', $row['members']);

                     foreach ($values as $value) {
                        
                        if (!empty($value)) { 
                           $user_sql = "SELECT * FROM users WHERE user_id=$value";
                           $user_result = $conn->query($user_sql);
                           
                           if ($user_result->num_rows > 0) {
                              if($user_row = $user_result->fetch_assoc()) {
                                 echo '<div class="members_main_right_member">
                                 <div class="members_main_right_member_info">
                                    <img src="/assets/img/avatar/'.$user_row['icon'].'.png">
                                    <div class="members_main_right_member_txt">
                                    <div class="members_main_right_member_name">'.$user_row['name'].'</div>
                                    <div class="members_main_right_member_username">@'.$user_row['username'].'</div>
                                    </div>
                                 </div>
                                 <div class="members_main_right_member_actions">
                                    <select>
                                       <option>Admin</option>
                                       <option selected>Member</option>
                                       <option>Observer</option>
                                    </select>
                                    <button onclick="workspace_member_remove('.$value.','."'members'".')">Remove</button>
                                 </div>
                              </div>';
                              }
                           }
                        }
                       
                     }

                     $values = explode(',', $row['observers']);

                     foreach ($values as $value) {
                        if (!empty($value)) {
                           $user_sql = "SELECT * FROM users WHERE user_id=$value";
                        $user_result = $conn->query($user_sql);
                        
                        if ($user_result->num_rows > 0) {
                            if($user_row = $user_result->fetch_assoc()) {
                              echo '<div class="members_main_right_member">
                              <div class="members_main_right_member_info">
                                 <img src="/assets/img/avatar/'.$user_row['icon'].'.png">
                                 <div class="members_main_right_member_txt">
                                 <div class="members_main_right_member_name">'.$user_row['name'].'</div>
                                 <div class="members_main_right_member_username">@'.$user_row['username'].'</div>
                                 </div>
                              </div>
                              <div class="members_main_right_member_actions">
                                 <select>
                                    <option>Admin</option>
                                    <option>Member</option>
                                    <option selected>Observer</option>
                                 </select>
                                 <button onclick="workspace_member_remove('.$value.','."'observers'".')">Remove</button>
                              </div>
                           </div>';
                           }
                        }
                        }
                     }

                   }
               }
?>