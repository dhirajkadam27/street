<style>

.modal-content{
            border:none
         }

         .modal_close_btn{
            margin-left: auto;
    margin-right: 20px;
    margin-top: 20px;
    margin-bottom: -15px;
    position: relative;
    z-index: 10;
         }

         .modal_title {
    margin-left: 20px;
    margin-bottom: 10px;
    font-size: 15px;
    font-weight: 600;
    color: #212121;
}

.modal_label {
    margin-left: 20px;
    font-size: 12px;
    font-weight: 400;
    color: #212121;
    margin-bottom: 5px;
    margin-top: 10px;
}


.modal-footer {
    border: none;
    margin-top: 15px;
}

.modal-footer button {
    padding: 0px 20px;
    height: 30px;
    background: #2698F0;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
    color: white;
}
.modal-footer .retry{
   background: #f33131
}

.modal-footer button:nth-child(1){
    background: #e4e4e4;
    color: #212121;
}
</style>
<div class="modal fade" id="error" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <button class="modal_close_btn" data-bs-dismiss="modal"><span class="material-icons-outlined">clear</span></button>
     <div class="modal_title">Error</div>

            <div class="modal_label">Your request Couldn't be Processed <br> There was a problem with this request. We're working on getting it fixed as soon as we can.
            </div>
            
      <div class="modal-footer">
        <button data-bs-dismiss="modal">Close</button>
        <button onclick="location.reload()" class="retry">Retry</button>
      </div>
    </div>
  </div>
</div>

<script>
    const errorModal = new bootstrap.Modal(document.getElementById('error'));
</script>