<?php
   if(isset($_SESSION["user_id"])){
      $user_id = $_SESSION["user_id"];
      $name = $_SESSION["name"];
      $username = $_SESSION["username"];
      $mail = $_SESSION["mail"];
      $gender = $_SESSION["gender"];
      $icon = $_SESSION["icon"];
   }

   ini_set('display_errors', 1);
error_reporting(E_ALL);

?>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: #fff;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
 

         .header_img {
    width: 70%;
    margin: 20px auto;
    display: block;
    margin-top: 50px;
}

.profile_data {
    display: flex;
    align-items: flex-start;
    width: 70%;
    margin-left: 20%;
    margin-bottom: 40px;
}

.profile_data img {
    width: 150px;
    margin-top: -75px;
}

.profile_data_txt {
    margin-left: 20px;
}

.profile_data_label {
    font-size: 12px;
    font-weight: 500;
    color: #212121;
}

.profile_data_name {
    font-size: 15px;
    font-weight: 400;
    color: #212121;
}

.label {
    display: flex;
    align-items: flex-start;
    width: 70%;
    margin-left: 20%;
    font-size: 10px;
    font-weight: 400;
    color: #212121;
}

.name,.username,.gender {
    width: 300px;
    margin-left: 20%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
    background: #f2f2f2;
    border-radius: 3px;
    font-size: 13px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
    margin-bottom:30px
}

.gender {
   appearance: none; /* This is used to hide the default arrow in some browsers */
  -webkit-appearance: none;
  -moz-appearance: none;
    width: 300px;
    margin-left: 20%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 5px;
    background: #f2f2f2;
    border-radius: 3px;
         font-family: Inter;
    font-size: 13px;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}

.save {
    width: 150px;
    margin-left: 20%;
         height: 40px;
         display: flex;
         align-items: center;
         justify-content: center;
         background: #2698F0;
         border-radius: 3px;
         font-size: 15px;
         font-weight: 500;
         color: white;
         }

      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
         <img class="header_img" src="https://res.cloudinary.com/postman/image/upload/t_user_hero/v1/user_hero/def-hero-image">
         <div class="profile_data">
            <img src="/assets/img/avatar/<?php echo $icon ?>.png">
            <div class="profile_data_txt">
                <div class="profile_data_label">Email</div>
                <div class="profile_data_name"><?php echo $mail ?></div>
            </div>
         </div>

         <div class="label">Full Name</div>
         <input class="name" id="name" value="<?php echo $name ?>" type="text">
            
            <div class="label">Username</div>
            <input class="username" id="username" value="<?php echo $username ?>" type="text">
            
            <div class="label">Gender</div>
         <select id="gender" class="gender">
            <option <?php echo $gender=="Male"?"selected":"" ?>>Male</option>
            <option <?php echo $gender=="Female"?"selected":"" ?>>Female</option>
         </select>

         
         <button class="save" onclick="save_changes()">Save the change</button>

         <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/modules/error.php';
         ?>


         <script>


            function save_changes(){
                
        $.ajax({
               url: "/api/profile_edit.php",
               type: "GET",
               data: {
			username: $('#username').val(),
			name: $('#name').val(),
			gender: $('#gender').val()
               },
               dataType: 'text',
               success: function(response) {
                  if(response=="true"){
                         location.reload();
                  }else{
               errorModal.show(errorModal);
                  }
               },
               error: function(xhr, status, error) {
               errorModal.show(errorModal);
            }
            });
            }
            </script>
   </body>
</html>