<style>
.workspace_members_main_left {
    width: 250px;
    height: calc(100vh - 100px);
    border-right: 1px solid #ededed;
}

.workspace_members_main_left button {
    width: 100%;
    color: #212121;
    font-size: 12px;
    font-weight: 500;
    text-align: left;
    padding: 10px;
}
.workspace_members_main_left button:nth-child(1){
    margin-top:10px
}

.workspace_members_main_left button.active{
    background: #f0f0f0;
    border-left: 2px solid #212121;
}
    </style>

<div class="workspace_members_main_left">
                    <button onclick="window.location.href='members.php?id=<?php echo $id;?>';">Workspaces Members</button>
                    <button onclick="window.location.href='guests.php?id=<?php echo $id;?>';">Guests</button>
                    <button onclick="window.location.href='pendings.php?id=<?php echo $id;?>';">Pendings</button>
                </div>

                <script>

if(workspace_url.startsWith('http://localhost/street/w/members.php')){
                  $('.workspace_members_main_left button').eq(0).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/guests.php')){
                  $('.workspace_members_main_left button').eq(1).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/pendings.php')){
                  $('.workspace_members_main_left button').eq(2).addClass('active');
               }

</script>
