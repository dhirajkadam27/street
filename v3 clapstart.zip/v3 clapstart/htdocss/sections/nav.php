<?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
   if(isset($_SESSION["user_id"])){
      $user_id = $_SESSION["user_id"];
      $name = $_SESSION["name"];
      $username = $_SESSION["username"];
      $mail = $_SESSION["mail"];
      $gender = $_SESSION["gender"];
      $icon = $_SESSION["icon"];
   }
?>

<style>
   .nav {
   display: flex;
   align-items: center;
   justify-content: space-between;
   padding: 10px;
   border-bottom: 1px solid #e8e8e8;
   background:white;
   }
   .logo_section {
   display: flex;
   justify-content: start;
   }
   .logo_section img {
   height: 30px;
   cursor: pointer;
   }
   .search_section {
   display: flex;
   justify-content: center;
   }
   .search_box {
   border: 1px solid #dcdcdc;
   background: #f5f5f5;
   display: flex;
   align-items: center;
   justify-content: center;
   width: 200px;
   height: 30px;
   color: #6b6b6b;
   font-size: 13px;
   font-weight: 400;
   border-radius: 5px;
   cursor: pointer;
   }
   .search_box_main .dropdown-menu{
   width: 800px !important;
   z-index: 10000;
   background: white;
   inset: unset !important;
   transform: none !important;
   }
   .search_box:hover{
   border: 1px solid #a9a9a9;
   }
   .search_box span {
   font-size: 18px;
   margin-right: 5px;
   }
   .account_section {
   display: flex;
   justify-content: end;
   align-items: center;
   }
   .notification{
   margin-right: 20px;
   }
   .notification span {
   font-size: 25px;
   color: #212121;
   }
   .avatar {
      width: 30px;
    height: 30px;
   }
   .avatar img {
   height: 100%;
   }
   .signin_btn {
   border-radius: 3px;
   border: 1px solid #b3b3b3;
   background: #FFF;
   color: #212121;
   font-size: 12px;
   font-weight: 600;
   height: 30px;
   padding: 0px 10px;
   }
   .signup_btn {
   border-radius: 3px;
   border: 1px solid #2698F0;
   background: #2698F0;
   color: white;
   font-size: 12px;
   font-weight: 600;
   height: 30px;
   padding: 0px 10px;
   margin-left: 10px;
   }
</style>
<div class="nav">
   <button class="logo_section">
      <?php
      if (strpos($_SERVER['REQUEST_URI'], '/street/') !== false) {
         echo '<img src="/assets/img/street_full_logo.svg">';
      }else{
         echo '<img src="/assets/img/logo.svg">';
      }
      ?>
   </button>
   <div class="dropdown search_box_main">
      <div data-bs-toggle="tooltip" data-bs-title="ctrl+k" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" class="search_section">
         <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" class="search_box">
            <span class="material-icons-round">search</span>
            <div class="search_txt">Search</div>
         </div>
         <ul class="dropdown-menu">
            <?php
               include $_SERVER['DOCUMENT_ROOT'] .'/modules/search.php';
               ?>
         </ul>
      </div>
   </div>
   <div class="account_section">
      <?php
         if(isset($_SESSION['user_id'])){
         if($_SERVER['REQUEST_URI']!="/street.php" AND $_SERVER['REQUEST_URI']!="/"){
          echo '<div class="dropdown">
          <button data-bs-toggle="dropdown" aria-expanded="false"  class="notification">
          <span data-bs-toggle="tooltip" data-bs-title="Notifications" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" class="material-icons-round">notifications</span>
          </button>
          <ul style="width: 400px;" class="dropdown-menu">';
          include $_SERVER['DOCUMENT_ROOT'] .'/modules/notifications.php';
         echo '    </ul>
         </div>';
         
         }
         
         echo '<div class="dropdown">
         <button data-bs-toggle="dropdown" aria-expanded="false" class="avatar">
         <img data-bs-toggle="tooltip" data-bs-title="'.$name.'" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" src="/assets/img/avatar/'.$icon.'.png">
         </button>
         <ul class="dropdown-menu">';
         include $_SERVER['DOCUMENT_ROOT'] .'/modules/profile.php';
         echo '</ul>
         </div>';
         }else{
          echo '<button onclick="window.location.href='."'/auth/log-in.html'".'" class="signin_btn">Sign In</button>
          <button onclick="window.location.href='."'/auth/sign-up.html'".'" class="signup_btn">Sign Up for Free</button>';
         }
         ?>
   </div>
</div>
<script>
   $(document).ready(function() {
   $('[data-bs-toggle="tooltip"]').tooltip();
   });
   
</script>