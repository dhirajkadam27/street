
<style>
   .workspaces_nav {
         width: 250px;
         height: 100%;
         border-right: 1px solid #ededed;
         }
         .workspaces_nav button {
            width: 250px;
    display: flex;
    align-items: center;
    padding: 10px;
    background: none;
    margin: 10px 0px;
    color: #212121;
    font-size: 12px;
    font-weight: 500;
         }
         .workspaces_nav button:hover{
         background: #efefef;
         filter: none !important; 
         }
         .workspaces_nav span {
         font-size: 20px;
         margin-right: 10px;
         }
         .workspaces_nav_title {
         font-size: 12px;
         margin-left: 10px;
         margin-top: 25px;
         }
         .workspaces_nav button .workspace_icon {
         width: 30px;
         height: 30px;
         background: #c2c215;
         display: flex;
         align-items: center;
         justify-content: center;
         border-radius: 3px;
         margin-right: 10px;
         color: #212121;
         }
         .workspace_txt {
    width: calc(100% - 50px);
    text-align: left;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

   
         
    </style>
<div class="workspaces_nav">
            <button onclick="window.location.href='/street/'"><span class="material-icons-round">home</span>Home</button>
            
            <div id="all_guests_workspaces">
            <?php
include $_SERVER['DOCUMENT_ROOT'] .'/modules/guest_workspaces.php';
?>
            </div>
            <div class="workspaces_nav_title">Your workspaces</div>
            <button data-bs-toggle="modal" data-bs-target="#create_new_workspace">
            <span class="material-icons-outlined">add</span>Create new workspace
            </button>

            <div id="all_workspaces">
            <?php
include $_SERVER['DOCUMENT_ROOT'] .'/modules/workspaces.php';
?>
            </div>

         </div>

         <script>
            if(window.location.href == 'http://localhost/street/'){
            $('[onclick="window.location.href=\'/street/\'"]').css('background','#efefef');
               }
               <?php 
if(!isset($_GET['id'])){
   $id="null";
}
?>
$('[onclick="window.location.href=\'/street/w/?id=<?php echo $id; ?>\'"]').css('background','#efefef');
</script>

         <?php
include $_SERVER['DOCUMENT_ROOT'] .'/modules/create-new-workspace.php';
?>         <?php
include $_SERVER['DOCUMENT_ROOT'] .'/modules/error.php';
?>
