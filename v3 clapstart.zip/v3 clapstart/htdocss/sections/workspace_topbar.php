<?php
$id = $_GET['id'];
?>
<style>
.workspace_topbar {
         display: flex;
         align-items: center;
         justify-content: space-between;
         width: 100%;
         height: 50px;
         border-bottom: 1px solid #e8e8e8;
         background: white;
         }
         .workspace_topbar_left {
         display: flex;
         }
         .workspace_topbar_left button {
            width: 100px;
    height: 50px;
    color: #212121;
    font-size: 12px;
    font-weight: 400;
    background: #ffffff;
    border-top: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
         }
         .workspace_topbar_left button.active{
            background: #f0f0f0;
    border-top: 2px solid #212121;
         }
         .workspace_topbar_right {
         display: flex;
         align-items: center;
         }
         .workspace_topbar_profiles {
         display: flex;
         align-items: center;
         }
         .workspace_topbar_profiles img {
         width: 30px;
         margin-left: -10px;
         border: 2px solid white;
         border-radius: 100px;
         cursor: pointer;
         }
         .workspace_topbar_more_profile {
         width: 25px;
         height: 25px;
         background: #d3e5f2;
         display: flex;
         align-items: center;
         justify-content: center;
         border-radius: 100px;
         color: #3f464b;
         font-size: 10px;
         font-weight: 700;
         margin-right: 12px;
         margin-left: 5px;
         }
         .invite_btn {
         margin: 0px 10px;
         background: #2698F0;
         padding: 5px 15px;
         border-radius: 5px;
         color: white;
         font-size: 12px;
         font-weight: 500;
         }
         .mail_btn {
         margin: 0px 10px;
         }
         .mail_btn span {
         font-size: 23px;
         color: #212121;
         }



         .invitation_inputs {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom:20px
}

.tagify {
    width: 250px;
}
.invitation_inputs input {
    width: 250px;
    padding: 3px;
    border: 1px solid #9d9d9d;
    border-radius: 3px;
    font-family: Inter;
    font-size: 15px;
    font-weight: 500;
    color: #212121;
}


#invite_results {
    /* display: none; */
   position: absolute;
    top: 105px;
    left: 34px;
    width: 300px;
    background: white;
    border: 1px solid #c8c8c8;
}

.invite_result {
    display: flex;
    align-items: center;
    padding: 10px 10px;
}
.invite_result:hover {
    background: #e7e7e7;
}

.invite_result img {
    width: 40px;
    margin-right: 10px;
}

.invite_result_name {
    font-size: 13px;
    font-weight: 600;
    color: #212121;
}

.invite_result_username {
    font-size: 12px;
    font-weight: 400;
    color: #212121;
}

.invitation_inputs select {
    padding: 3px;
    border: 1px solid #9d9d9d;
    border-radius: 3px;
    font-family: Inter;
    font-size: 15px;
    font-weight: 500;
    color: #212121;
    margin:0px 10px;
}

.invitation_inputs button {background: #2698F0;padding: 5px 15px;border-radius: 5px;color: white;font-size: 12px;font-weight: 500;}

#workspace_invitation .modal-content {
    padding-bottom: 10px;
}



.invited_member {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px 20px;
}

.invited_member_left img {
    width: 35px;
    margin-right: 10px;
}

.invited_member_left {
    display: flex;
    align-items: center;
}

.invited_member_left_name {
    font-size: 12px;
    font-weight: 600;
}

.invited_member_left_username {
    font-size: 10px;
    font-weight: 500;
}

.invited_member_right select {
    padding: 3px;
    border: 1px solid #9d9d9d;
    border-radius: 3px;
    font-family: Inter;
    font-size: 12px;
    font-weight: 500;
    color: #212121;
    margin: 0px 10px;
}

.invited_member_right button {
    background: #2698F0;
    padding: 3px 10px;
    border-radius: 5px;
    color: white;
    font-size: 12px;
    font-weight: 500;
}


#workspace_inbox {
    height: 100vh;
}





.inbox_main {
    display: flex;
    height: 95vh;
}

.inbox_left {width: 250px;height: 100%;border-right: 1px solid #ededed;}

.inbox_left button {
    width: 250px;
    display: flex;
    align-items: center;
    padding: 10px;
    background: none;
    margin: 10px 0px;
    color: #212121;
    font-size: 12px;
    font-weight: 500;
}

.inbox_left button:hover{
         background: #efefef;
         filter: none !important; 
         }

.inbox_left button span {
    font-size: 20px;
    margin-right: 10px;
}

.inbox_right {
    width: calc(100% - 250px);
    position: relative;
}

.inbox_right_msg {
    display: flex;
    padding: 10px;
}
.inbox_right_msg:hover {
    background: whitesmoke
}

.inbox_right_msg img {
    height: 40px;
    margin-left: 10px;
    margin-right: 20px;
}

.inbox_right_msg_creator {
    margin-top: 10px;
    font-size: 15px;
    font-weight: 600;
}

.inbox_right_msg_creator span {
    font-size: 12px;
    font-weight: 500;
    margin-left: 10px;
}

.inbox_right_msg_content {
    margin-top: 5px;
    font-size: 15px;
    font-weight: 400;
}

.inbox_right_bottom {
    position: fixed;
    bottom: 30px;
    margin-left:10px;
    border: 1px solid silver;
    width: calc(100% - 300px);
    padding: 10px;
    border-radius: 5px;
    display: flex;
    align-items: center;
}

.inbox_right_bottom input {
    width: calc(100% - 100px);
    height: 40px;
    background: white;
    font-weight: 500;
    color: #212121;
    border: none;
    outline: none;
    padding: 10px;
}

.inbox_right_bottom button {
    width: 80px;
    height: 40px;
    margin-left: 10px;
    background: #2698F0;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
    color: white;
}

</style>

<div class="workspace_topbar">
               <div class="workspace_topbar_left">
                  <button onclick="window.location.href='./?id=<?php echo $id;?>';">Pages</button>
                  <button onclick="window.location.href='members.php?id=<?php echo $id;?>';">Members</button>
                  <button onclick="window.location.href='profile.php?id=<?php echo $id;?>';">Settings</button>
               </div>
               <div class="workspace_topbar_right">
                  <div class="workspace_topbar_profiles">
                     <img data-bs-toggle="tooltip" data-bs-title="Dhiraj Kadam" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" src="https://cdn-icons-png.flaticon.com/512/6084/6084719.png">
                     <img data-bs-toggle="tooltip" data-bs-title="Ram Rao" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" src="https://cdn-icons-png.flaticon.com/512/6084/6084290.png">
                     <img data-bs-toggle="tooltip" data-bs-title="Vijay Singh" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" src="https://cdn-icons-png.flaticon.com/512/6084/6084386.png">
                     <img data-bs-toggle="tooltip" data-bs-title="Riya sharma" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom" src="https://cdn-icons-png.flaticon.com/512/6084/6084444.png">
                     <div  data-bs-toggle="tooltip" data-bs-title="View All Members" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom"><button data-bs-toggle="modal" data-bs-target="#workspace_invitation" class="workspace_topbar_more_profile">+3</button></div>
                  </div>
                  <div data-bs-toggle="tooltip" data-bs-title="Invite members to workspace" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom"><button data-bs-toggle="modal" data-bs-target="#workspace_invitation" class="invite_btn">Invite</button></div>
                  <div data-bs-toggle="tooltip" data-bs-title="Inbox" data-bs-custom-class="custom-tooltip" data-bs-placement="bottom"><button data-bs-toggle="offcanvas" data-bs-target="#workspace_inbox" aria-controls="offcanvasTop" class="mail_btn"><span class="material-icons-outlined">alternate_email</span></button></div>
               </div>
            </div>

            <script>
               var workspace_url = window.location.href;
               if(workspace_url.startsWith('http://localhost/street/w/index.php')){
                  $('.workspace_topbar_left button').eq(0).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/members.php')){
                  $('.workspace_topbar_left button').eq(1).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/guests.php')){
                  $('.workspace_topbar_left button').eq(1).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/pendings.php')){
                  $('.workspace_topbar_left button').eq(1).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/profile.php')){
                  $('.workspace_topbar_left button').eq(2).addClass('active');
               }else if(workspace_url.startsWith('http://localhost/street/w/permissions.php')){
                  $('.workspace_topbar_left button').eq(2).addClass('active');
               }else{
                $('.workspace_topbar_left button').eq(0).addClass('active');
               }
</script>



<div class="modal fade" id="create_new_discussion" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <button class="modal_close_btn" data-bs-dismiss="modal"><span class="material-icons-outlined">clear</span></button>
     <div class="modal_title">Create new Discussion</div>

            <div class="modal_label">Discussion Name</div>
            <input class="modal_input" value="" type="text">
            
      <div class="modal-footer">
        <button data-bs-dismiss="modal">Close</button>
        <button>Create</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
      
<div class="modal fade" id="workspace_invitation" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <button class="modal_close_btn" data-bs-dismiss="modal"><span class="material-icons-outlined">clear</span></button>
     <div class="modal_title">Invite members</div>
     <div class="invitation_inputs">
     <input name='mails' id="tag_mails" placeholder='Enter username or mail id' value=''>
     <div id="invite_results">
     
     </div>
     <select>
      <option>Members</option>
      <option>Observers</option>
            </select>
            <button>Invite</Button>
     </div>

     <div class="invited_member">
      <div class="invited_member_left">
         <img src="https://cdn-icons-png.flaticon.com/512/6084/6084290.png">
         <div class="invited_member_left_txt">
            <div class="invited_member_left_name">Dhiraj Kadam</div>
            <div class="invited_member_left_username">@dhirajkadam</div>
         </div>
      </div>
      <div class="invited_member_right">
      <select>
      <option>Admin</option>
      <option>Members</option>
      <option>Observers</option>
            </select>
            <button>Remove</Button>
      </div>
     </div>

     
     <div class="invited_member">
      <div class="invited_member_left">
         <img src="https://cdn-icons-png.flaticon.com/512/6084/6084290.png">
         <div class="invited_member_left_txt">
            <div class="invited_member_left_name">Dhiraj Kadam</div>
            <div class="invited_member_left_username">@dhirajkadam</div>
         </div>
      </div>
      <div class="invited_member_right">
      <select>
      <option>Admin</option>
      <option>Members</option>
      <option>Observers</option>
            </select>
            <button>Remove</Button>
      </div>
     </div>


    </div>
  </div>
</div>

<script>

    var lastest_search_query="";
var input = document.querySelector('input[name=mails]');

var tagify = new Tagify(input);


// tagify.addTags(["banana", "orange", "apple"])

const search_by_email = document.querySelector('.tagify__input');

// Add an input event listener
search_by_email.addEventListener('input', function() {

  console.log('Input text changed: ' + search_by_email.innerHTML);
  lastest_search_query = search_by_email.innerHTML;
  if(search_by_email.innerHTML.length>2){
  document.querySelector('#invite_results').style.display = "block";
  }else{
  document.querySelector('#invite_results').style.display = "none";
  }

  var query = search_by_email.innerHTML;

        $.ajax({
            url: '/api/search-users.php',
            method: 'GET',
            data: { query: query },
            success: function(data) {
                        $('#invite_results').html(data);
            }
        });

});

function add_tagify_email(mail){
    console.log(lastest_search_query);
    tagify.removeTags(lastest_search_query);
    tagify.addTags(mail);

}

</script>



<div class="offcanvas offcanvas-top" tabindex="-1" id="workspace_inbox" aria-labelledby="offcanvasTopLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasTopLabel">workspace (Inbox)</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="inbox_main">
      <div class="inbox_left">
         <button>Topic one</button>
         <button>Topic two</button>
            <button data-bs-toggle="modal" data-bs-target="#create_new_discussion">
            <span class="material-icons-outlined">add</span>Create new Discussion
            </button>
      </div>
      <div class="inbox_right">

      <div class="inbox_right_msg">
         <img src="https://cdn-icons-png.flaticon.com/512/6084/6084290.png">
         <div class="inbox_right_msg_txt">
            <div class="inbox_right_msg_creator">Dhiraj Kadam<span>6:30pm</span></div>
            <div class="inbox_right_msg_content">
            What could go wrong if I were to do a style guide with 5 color palettes without any planning? Narrator: A lot of things could go wrong.
            What could go wrong if I were to do a style guide with 5 color palettes without any planning? Narrator: A lot of things could go wrong.
            What could go wrong if I were to do a style guide with 5 color palettes without any planning? Narrator: A lot of things could go wrong.
            </div>
         </div>
      </div>
      <div class="inbox_right_bottom">
         <input placeholder="type here">
         <button>Send</button>
      </div>
      </div>
    </div>
  </div>
</div>