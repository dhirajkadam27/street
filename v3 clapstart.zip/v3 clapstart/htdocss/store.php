<html>
   <head>
      <meta charset="UTF-8">
      <title>Home | Clapstart</title>
      <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
      <title>Bootstrap Example</title>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <style>
         body {
         margin: 0;
         padding: 0;
         width: 100%;
         font-family: Inter;
         background-color: #fafafa;
         }
         button{
         font-family: Inter;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         overflow: hidden;
         margin: 0;
         padding: 0;
         border: none;
         background: none;
         }
         button:hover{
         filter: brightness(0.98);
         }
         button:active{
         transform: scale(0.95) !important;
         }
         .custom-tooltip {
         font-family: Inter;
         font-size: 12px;
         font-weight: 500;
         --bs-tooltip-bg: #dcdcdc;
         --bs-tooltip-color: #212121;
         }
 
         .prodcuts_title {
         color: #001930;
         font-size: 20px;
         font-weight: 700;
         margin-top: 50px;
         margin-bottom: 10px;
         margin-left: 30px;
         }
         .street_btn {
         background: white;
         padding: 10px 20px;
         border-radius: 5px;
         border: 1px solid #E8ECF2;
         background: #FFF;
         overflow: hidden;
         margin-left: 30px;
         }
         .street_btn_content{
         display: flex;
         align-items: center;
         }
         .street_btn_left img {
         height: 70px;
         }
         .street_btn_right {
         text-align: left;
         margin-left: 10px;
         }
         .product_name {
         color: #001930;
         font-size: 30px;
         font-weight: 700;
         margin-bottom: 5px;
         }
         .product_type {
         color: #78859D;
         font-size: 12px;
         font-weight: 700;
         }

      </style>
   </head>
   <body>
      <?php
         include $_SERVER['DOCUMENT_ROOT'] .'/sections/nav.php';
         ?>
    <div class="prodcuts_title">Products</div>
      <button onclick="window.location.href='/street'" class="street_btn">
         <div class="street_btn_content">
            <div class="street_btn_left">
               <img src="/assets/img/street.svg">
            </div>
            <div class="street_btn_right">
               <div class="product_name">Street</div>
               <div class="product_type">Project management tool</div>
            </div>
         </div>
      </button>
    
   </body>
</html>