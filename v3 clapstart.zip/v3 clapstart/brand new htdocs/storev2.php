
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | Clapstart</title>
    <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>


    <style>

            body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100vh;
    font-family: Inter;
    background-color: #E7EAEE;
}
button{
    font-family: Inter;
    border:none;
    padding:0;
    background: none;
    cursor: pointer;
    transition: all .2s ease-in-out; 
}
button .button_content{
    display: flex;
    align-items: center;
    justify-content: center;
}
button .button_loader{
    display: none;
}
button:active{
    transform: scale(0.88) !important;
}
button:hover{
    filter: opacity(0.85) !important;
}
button:disabled{
    filter: opacity(0.8) !important;
    cursor: not-allowed;
}
input{
    font-family: Inter;
}

img{
    height: 100px;
}

.nav {
    padding: 0px 20px;
    height: 50px;
    background: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.clapstart_logo img {
    height: 30px;
}

.search_btn {
    width: 400px;
    height: 30px;
    background: #E1E6F0;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0px 10px;
}

.search_btn_l {
    display: flex;
    align-items: center;
    color: #78859D;
    font-size: 13px;
}

.search_btn_l span {
    font-size: 20px;
    margin-right: 5px;
}

.search_btn_r {
    padding: 3px 10px;
    background: #78859D;
    border-radius: 100px;
    font-size: 10px;
    color: white;
    font-weight: 600;
}
.search_btn_loader img {
    height: 20px;
}
.profile_btn {
    width: 30px;
    height: 30px;
    background: #63BEFF;
    border-radius: 100px;
    font-size: 13px;
    font-weight: 600;
    color: white;
    position: relative;
}
.profile_btn_loader {
    display: flex;
    align-items: center;
    justify-content: center;
}
.profile_btn_loader img {
    height: 20px;
    mix-blend-mode: plus-lighter;
}


.prodcuts_title {
    color: #001930;
    font-size: 20px;
    font-weight: 700;
    margin-top: 30px;
    margin-bottom: 10px;
    margin-left: 40px;
}


.street_btn {
    background: white;
    padding: 10px 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px 0px #d5d6db;
    position: relative;
    overflow: hidden;
    margin-left: 40px;
}
.street_btn_content{
    display: flex;
    align-items: center;
}
.street_btn_left img {
    height: 70px;
}

.street_btn_right {
    text-align: left;
    margin-left: 10px;
}

.product_name {
    color: #001930;
    font-size: 30px;
    font-weight: 700;
    margin-bottom: 5px;
}

.product_type {
    color: #78859D;
    font-size: 12px;
    font-weight: 700;
}

.street_btn_loader {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #ffffff69;
}

.street_btn_loader img {
    height: 20px;
    margin: 10px 10px;
    margin-left: auto;
}





.black_bg {
    width: 100%;
    height: 100%;
    background: black;
    opacity: 0.5;
    position: fixed;
    display: none;
    z-index: 5;
    top: 0;
    left: 0;
}
.blur_bg {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.233);
    backdrop-filter: blur(10px);
    position: fixed;
    display: none;
    z-index: 5;
    top: 0;
    left: 0;
}

.error_popup {
    width: 300px;
    background: white;
    border-radius: 10px;
    text-align: center;
    display: none;
    position: fixed;
    z-index: 6;
    top: 30vh;
    left: calc(50% - 150px);
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
}


.error_popup_title {
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;
    color: #001930;
}

.error_popup_txt {
    font-size: 15px;
    font-weight: 400;
    margin-top: 10px;
    color: #78859D;
    padding: 10px 20px;
    margin-bottom: 10px;
}

.error_popup button {
    width: 100%;
    height: 50px;
    border-top: 1px solid #e0e0e0;
    color: #2698F0;
    font-size: 18px;
    font-weight: bold;
}


.search_input_box {
    width: 400px;
    height: 30px;
    border-radius: 10px;
    display: none;
    align-items: center;
    justify-content: space-between;
    position: fixed;
    z-index: 6;
    top:10vh;
    left: calc(55% - 200px);
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
}

.search_input_l {
    background: white;
    display: flex;
    align-items: center;
    width: 340px;
    height: 30px;
    border-radius: 5px;
    overflow: hidden;
}

.search_input_l span {
    font-size: 20px;
    color: #78859D;
    width: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.search_input_l input {
    width: 300px;
    height: 30px;
    border: none;
    outline: none;
    color: #78859D;
    font-size: 13px;
}

.search_input_l input::placeholder {
    color: #78859D;
    font-size: 13px;
}
.search_input_box button {
    width: 50px;
    height: 30px;
    background: #FFFFFF;
    border-radius: 5px;
    color: #2698F0;
    font-size: 12px;
    font-weight: 600;
}
.search_results{
    width: 400px;
    border-radius: 10px;
background: #E7EAEE;
    border-radius: 10px;
    position: fixed;
    z-index: 6;
    top:calc(10vh + 50px);
    left: calc(55% - 200px);
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
    display: none;
}

.search_result {
    position: relative;
    width: calc(100% - 20px);
    display: flex;
    align-items: center;
    margin: 10px;
    padding: 7px 10px;
    border-radius: 10px;
    transition: all .2s ease-in-out;
    background: #FFF;
    cursor: pointer;
    text-deocration:none;
    }
    
    .search_result_img {
        border-radius: 8px;
        background: #78859D;
        overflow: hidden;
        margin-right: 10px;
    }
    
    .search_result_img img {
        width: 40px;
    }
    
    .search_result_name {
        color: #001930;
        font-size: 15px;
        font-weight: bold;
        margin-bottom: 3px;
    }
    
    .search_result_type {
        color: #78859D;
        font-size: 10px;
        font-weight: 500;
    }
    
    .search_result_icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        font-weight: 600;
        color: #fff;
    }
    .no_src {
        width: calc(100% - 20px);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 10px;
    padding: 7px 10px;
    border-radius: 10px;
    transition: all .2s ease-in-out;
    background: #FFF;
    cursor: pointer;
    color: #78859D;
    font-size: 15px;
    font-weight: 500;
    }

    .search_result_loader {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #ffffff69;
}

.search_result_loader img {
    height: 20px;
    margin: 10px 10px;
    margin-left: auto;
}


.profile_menu {
    position: absolute;
    z-index: 6;
    right: 60px;
    top: 50px;
    background: white;
    width: 160px;
    border-radius: 7px;
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
    animation-fill-mode: forwards;
    display: none;
}

.profile_icon {
    display: flex;
    align-items: center;
    padding: 10px;
}

.profile_icon_txt {
    width: 30px;
    height: 30px;
    background: #63BEFF;
    border-radius: 100px;
    font-size: 13px;
    font-weight: 600;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
}

.profile_txt {
    margin-left: 5px;
}

.profile_name {
    color: #001930;
    font-size: 12px;
    font-weight: 600;
}

.profile_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
}

.profile_link {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 10px;
    border-top: 1px solid #C8D0DE;
    color: #78859D;
    font-size: 12px;
    font-weight: 500;
}

.profile_link span {
    font-size: 15px;
}
.profile_link_loader img {
    height: 20px;
}


@keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }



    </style>
</head>
<body>

    <div class="nav">
        <button class="clapstart_logo"><img src="/assets/img/logo.svg"></button>
        <button onclick="redirect_btn_loader(this);search_popup()" class="search_btn"><div class="search_btn_l"><span class="material-icons-outlined">search</span>Search</div><div class="search_btn_r button_content">ctrl+f</div><div class="search_btn_loader button_loader"><img src="/assets/img/loader.gif"></div></button>
        <button onclick="redirect_btn_loader(this);profile_menu_popup()" class="profile_btn"><div class="profile_btn_txt button_content">D</div> <div class="profile_btn_loader button_loader"><img src="/assets/img/loader.gif"></div></button>
        <div class="profile_menu">
            <div class="profile_icon">
                <div class="profile_icon_txt">D</div>
                <div class="profile_txt">
                    <div class="profile_name">Dhiraj Kadam</div>
                    <div class="profile_username">@dhirajkadam</div>
                </div>
                </div>
            <button onclick="redirect_btn_loader(this);" class="profile_link"><div class="profile_link_txt">Profile</div><span class="material-icons-outlined button_content">account_circle</span><div class="profile_link_loader button_loader"><img src="/assets/img/loader.gif"></div></button>
            <button onclick="redirect_btn_loader(this);" class="profile_link"><div class="profile_link_txt">Edit</div><span class="material-icons-outlined button_content">edit</span><div class="profile_link_loader button_loader"><img src="/assets/img/loader.gif"></div></button>
            <button onclick="redirect_btn_loader(this);" class="profile_link"><div class="profile_link_txt">Logout</div><span class="material-icons-outlined button_content">power_settings_new</span><div class="profile_link_loader button_loader"><img src="/assets/img/loader.gif"></div></button>
            </div> 
    </div>

    
    <div class="prodcuts">
        <div class="prodcuts_title">Products</div>
        <button onclick="redirect_btn_loader(this);redirect_street()" class="street_btn">
            <div class="street_btn_content">
                <div class="street_btn_left">
                    <img src="/assets/img/street.svg">
                </div>
                <div class="street_btn_right">
                    <div class="product_name">Street</div>
                    <div class="product_type">Project management tool</div>
                </div>
            </div>

            <div class="street_btn_loader button_loader"><img src="/assets/img/loader.gif"></div>
        </button>
    </div>


    <div class="black_bg"></div>
    <div class="blur_bg"></div>
    <div class="error_popup close_popup">
        <div class="error_popup_title">Error</div>
        <div class="error_popup_txt">An problem occurred during the user login</div>
        <button onclick="close_error_popup()">Ok</button>
    </div>

    <div class="search_input_box"><div class="search_input_l"><span class="material-icons-outlined">search</span><input type="text" placeholder="Search"></div><button onclick="close_search_popup()">cancel</button></div>
    <div class="search_results">
         <button onclick="redirect_btn_loader(this)" class="search_result">
             <div class="search_result_img"><div class="search_result_icon">D</div></div>
                 <div class="search_result_txt">
                    <div class="search_result_name">Street</div>
                     <div class="search_result_type">Site page</div>
             </div>
             <div class="search_result_loader button_loader"><img src="/assets/img/loader.gif"></div>
            </button>
            <button class="no_src">Not search found</button>
    </div>


    

    <script>
        function redirect_btn_loader(div){
            $(div).find('.button_content').css('display','none');
            $(div).prop("disabled", true);
            $(div).find('.button_loader').css('display','flex');
        }

        function empty(){

        }
        function error_popup(){
            $('.black_bg').css('display','block');
            $('.error_popup').css('display','block');
        }
        function close_error_popup(){
            $('.black_bg').css('display','none');
            $('.error_popup').css('display','none');

        }
        function redirect_street(){
            window.location.href = '/street';
        }
        
        function search_popup(){
            $('.blur_bg').css('display','block');
            $('.search_input_box').css('display','flex');
            $('.search_results').css('display','block');
        }
        function close_search_popup(){
            
            $('button').find('.button_content').css('display','flex');
            $('button').prop("disabled", false);
            $('button').find('.button_loader').css('display','none');

            $('.blur_bg').css('display','none');
            $('.search_input_box').css('display','none');
            $('.search_results').css('display','none');

        }

        
        function profile_menu_popup(){
            setTimeout(() => {
            $('button').find('.button_content').css('display','flex');
            $('button').prop("disabled", false);
            $('button').find('.button_loader').css('display','none');
            }, 500);
            $('.blur_bg').css('display','block');
            $('.profile_menu').css('display','block');
            $('.profile_btn').css('zIndex','6');
        }
        function close_profile_menu_popup(){
            $('.blur_bg').css('display','none');
            $('.profile_menu').css('display','none');
            $('.profile_btn').css('zIndex','none');

        }
    </script>

</body>
</html>