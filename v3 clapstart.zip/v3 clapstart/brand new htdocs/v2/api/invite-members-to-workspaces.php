<?php
include "./config.php";


if (isset($_GET["user_mails"]) && !empty($_GET["user_mails"]) &&
    isset($_GET["workspace_id"]) && !empty($_GET["workspace_id"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    convert_email_to_user_id($conn, $_GET["user_mails"], $_GET["workspace_id"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}


function convert_email_to_user_id($conn,$users_mail,$workspace_id){
    $mail_arrray = explode(",", $users_mail);
    foreach ($mail_arrray as $mail) {
        $query = "SELECT * FROM users WHERE mail = '$mail'";
        
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            $user_ids[] = $row['user_id'];
            }
        } else {
            // echo "user not found";
        }
    }
    check_empty($conn, implode(",", $user_ids), $workspace_id);
}


function check_empty($conn, $user_ids, $workspace_id){
    $query = "SELECT * FROM workspaces WHERE workspace_id ='$workspace_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        if ($row["members"] == "") {
            add_to_members($conn, $user_ids, false,$workspace_id);
        } else {
            add_to_members($conn, $user_ids, true,$workspace_id);
        }
    } else {
        echo "Workspace not found. Please try again later";
    }
}


function add_to_members($conn, $user_ids, $empty,$workspace_id)
{
    if($empty){
        $sql = "UPDATE workspaces SET members = CONCAT(members, ',$user_ids') WHERE workspace_id=$workspace_id";
    }else{
        $sql = "UPDATE workspaces SET members = CONCAT(members, '$user_ids') WHERE workspace_id=$workspace_id";
    }
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            echo "Failed to add members to workspace. Please try again later";
        }else{
            get_all_members($conn,$workspace_id);
        }
    } else {
        echo "Failed to add members to workspace. Please try again later";
    }
}

function get_all_members($conn,$workspace_id){
    $query = "SELECT * FROM workspaces WHERE workspace_id ='$workspace_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        remove_duplicate($conn,$workspace_id,$row["members"]);
    } else {
        echo "Workspace not found. Please try again later";
    }
}

function remove_duplicate($conn,$workspace_id,$members){
    $members_array = explode(',', $members);

$uniquemembers_array = array_values(array_unique($members_array));

$uniquemembers = implode(',', $uniquemembers_array);

if($members==$uniquemembers){
    echo "added";
}else{
    $sql = "UPDATE workspaces SET members = '$uniquemembers' WHERE workspace_id=$workspace_id";
if ($conn->query($sql) === true) {
    if($conn->affected_rows==0){
        echo "Failed to add members to workspace. Please try again later";
    }else{
        echo "added";
    }
} else {
    echo "Failed to add members to workspace. Please try again later";
}
}

}


?>
