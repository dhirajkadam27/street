<?php
include "./config.php";


if (isset($_GET["user_mails"]) && !empty($_GET["user_mails"]) &&
    isset($_GET["page_id"]) && !empty($_GET["page_id"])&&
    isset($_GET["workspace_id"]) && !empty($_GET["workspace_id"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    convert_email_to_user_id($conn, $_GET["user_mails"], $_GET["page_id"], $_GET["workspace_id"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}


function convert_email_to_user_id($conn,$users_mail,$page_id,$workspace_id){
    $mail_arrray = explode(",", $users_mail);
    foreach ($mail_arrray as $mail) {
        $query = "SELECT * FROM users WHERE mail = '$mail'";
        
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            $user_ids[] = $row['user_id'];
            check_guests_empty($conn,$row['user_id'],$workspace_id);
            }
        } else {
            // echo "user not found";
        }
    }
    check_empty($conn, implode(",", $user_ids), $page_id,$workspace_id);
}



function check_guests_empty($conn,$user_id,$workspace_id){
    $query = "SELECT * FROM workspaces WHERE workspace_id ='$workspace_id' AND NOT(FIND_IN_SET('$user_id', admin) OR FIND_IN_SET('$user_id', members) OR FIND_IN_SET('$user_id', observers))";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        if ($row["guests"] == "") {
            add_to_guests($conn, $user_id, false,$workspace_id);
        } else {
            add_to_guests($conn, $user_id, true,$workspace_id);
        }
    } else {
        // echo "Workspace not found. Please try again later";
    }
}

function add_to_guests($conn, $user_id, $empty,$workspace_id){
    if($empty){
        $sql = "UPDATE workspaces SET guests = CONCAT(guests, ',$user_id') WHERE workspace_id=$workspace_id";
    }else{
        $sql = "UPDATE workspaces SET guests = CONCAT(guests, '$user_id') WHERE workspace_id=$workspace_id";
    }
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            // echo "Failed to add members to workspace. Please try again later";
        }else{
            // echo "added";
        }
    } else {
        // echo "Failed to add members to workspace. Please try again later";
    }
}


function check_empty($conn, $user_ids, $page_id,$workspace_id){
    $query = "SELECT * FROM pages WHERE page_id ='$page_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        if ($row["observers"] == "") {
            add_to_observers($conn, $user_ids, false,$page_id,$workspace_id);
            get_all_guests($conn,$workspace_id);
        } else {
            add_to_observers($conn, $user_ids, true,$page_id,$workspace_id);
            get_all_guests($conn,$workspace_id);
        }
    } else {
        echo "Page not found. Please try again later";
    }
}


function add_to_observers($conn, $user_ids, $empty,$page_id,$workspace_id)
{
    if($empty){
        $sql = "UPDATE pages SET observers = CONCAT(observers, ',$user_ids') WHERE page_id=$page_id";
    }else{
        $sql = "UPDATE pages SET observers = CONCAT(observers, '$user_ids') WHERE page_id=$page_id";
    }
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            echo "Failed to add observers to Page. Please try again later";
        }else{
            get_all_observers($conn,$page_id,$workspace_id);
        }
    } else {
        echo "Failed to add observers to Page. Please try again later";
    }
}

function get_all_observers($conn,$page_id,$workspace_id){
    $query = "SELECT * FROM pages WHERE page_id='$page_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        remove_duplicate($conn,$page_id,$row["observers"],$workspace_id);
    } else {
        echo "Page not found. Please try again later";
    }
}

function remove_duplicate($conn,$page_id,$observers,$workspace_id){
    $observers_array = explode(',', $observers);

$uniqueobservers_array = array_values(array_unique($observers_array));

$uniqueobservers = implode(',', $uniqueobservers_array);

if($observers==$uniqueobservers){
    get_all_guests($conn,$workspace_id);
    echo "added";
}else{
    $sql = "UPDATE pages SET observers = '$uniqueobservers' WHERE page_id=$page_id";
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            echo "Failed to add observers to Page. Please try again later1";
        }else{
            get_all_guests($conn,$workspace_id);
            echo "added";
        }
    } else {
        echo "Failed to add observers to Page. Please try again later";
    }
}
   

}



function get_all_guests($conn,$workspace_id){
    $query = "SELECT * FROM workspaces WHERE workspace_id='$workspace_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        remove_duplicate_guests($conn,$workspace_id,$row["guests"]);
    } else {
        // echo "Page not found. Please try again later";
    }
}

function remove_duplicate_guests($conn,$workspace_id,$guests){
    $guests_array = explode(',', $guests);

$uniqueguests_array = array_values(array_unique($guests_array));

$uniqueguests = implode(',', $uniqueguests_array);

if($guests==$uniqueguests){
    // echo "added";
}else{
    $sql = "UPDATE workspaces SET guests = '$uniqueguests' WHERE workspace_id=$workspace_id";
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            // echo "Failed to add observers to Page. Please try again later1";
        }else{
            // echo "added";
        }
    } else {
        // echo "Failed to add observers to Page. Please try again later";
    }
}
   

}

?>
