<?php
include './config.php';

if(isset($_GET['query'])){
    search($conn,$_GET['query']);

}else{
    echo "Some fields are empty";
}

function search($conn,$query){

$searchQuery = "SELECT * FROM search WHERE name LIKE '%$query%';";
$searchResult = $conn->query($searchQuery);

// Query to fetch name from the 'users' table
$usersQuery = "SELECT * FROM users WHERE name LIKE '%$query%';";
$usersResult = $conn->query($usersQuery);

// Query to fetch name from the 'workspaces' table
$workspacesQuery = "SELECT * FROM workspaces WHERE name LIKE '%$query%';";
$workspacesResult = $conn->query($workspacesQuery);
$count = 0;
if ($searchResult->num_rows > 0) {
    while ($row = $searchResult->fetch_assoc()) {
        echo $row["name"];
        // Process $searchName
    }
}else{
    $count++;
}

// Fetch and process data from the 'users' table
if ($usersResult->num_rows > 0) {
    while ($row = $usersResult->fetch_assoc()) {
        echo $row["name"];
        // Process $userName
    }
}else{
    $count++;
}

// Fetch and process data from the 'workspaces' table
if ($workspacesResult->num_rows > 0) {
    while ($row = $workspacesResult->fetch_assoc()) {
        echo $row["name"];
        // Process $workspaceName
    }
}else{
    $count++;
}

if($count==3){
    echo "No result found";
}
}
?>