<?php
include "./config.php";

if (isset($_GET["user_id"]) && !empty($_GET["user_id"]) && 
    isset($_GET["from"]) && !empty($_GET["from"]) && 
    isset($_GET["to"]) && !empty($_GET["to"]) && 
    isset($_GET["workspace_id"]) && !empty($_GET["workspace_id"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    change($conn, $_GET["user_id"], $_GET["from"], $_GET["to"],$_GET["workspace_id"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}

function change($conn, $user_id, $from, $to,$workspace_id){
    $sql = "SELECT * FROM workspaces WHERE workspace_id='$workspace_id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $from_data = $row[$from]; 
        $from_data = explode(",", $from_data);
        $index_from_data = array_search("$user_id", $from_data);
        if ($index_from_data !== false) {
            unset($from_data[$index_from_data]);
        }
        $from_data = implode(",", $from_data);

        if($row[$to]==''){
            $to_data = $user_id;
        }else{
            $to_data = $row[$to].",".$user_id;
        }

        
    $update_sql = "UPDATE workspaces SET $from='$from_data', $to='$to_data' WHERE workspace_id='$workspace_id'";
    if ($conn->query($update_sql) === TRUE) {
      if($conn->affected_rows==0){
          echo "Failed to proccess your request. Please try again later";
      }else{
        echo "Updated";
      }
    } else {
      echo "Not Updated";
    }

    } else {
        echo "Workspace not found. Please try again later";
    }
}


?>