<?php
include "./config.php";



if (isset($_GET["mail"]) && !empty($_GET["mail"]) && 
    isset($_GET["name"]) && !empty($_GET["name"]) && 
    isset($_GET["username"]) && !empty($_GET["username"])) {
        check_username($conn, $_GET["mail"], $_GET["name"], $_GET["username"]);
} else {
    echo "Some fields are empty";
}


function check_username($conn, $mail,$name,$username)
{
    $query = "SELECT * FROM users WHERE mail ='$mail' AND username!=''";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        create_login_session($conn,$row["user_id"],$row["name"],$row["username"],$row["mail"],$row["profile_color"]);
    } else {
        setup_account($conn,$mail,$name,$username);
    }
}

function setup_account($conn,$mail,$name,$username){
    $color = profile_color();
    $sql = "UPDATE users SET username='$username', name='$name', profile_color='$color' WHERE mail='$mail'";
    if ($conn->query($sql) === true) {
        create_login_session($conn,check_id($conn, $mail),$name,$username,$mail,$color);
    } else {
        echo "Failed to create account. Please try again later";
    }

}


function profile_icon($gender)
{
    $profile_icon = ["m1", "m2", "m3", "m4", "m5"];

    $profile_icon_index = array_rand($profile_icon);
    $icon = $color[$profile_icon_index];

    return $icon;
}

function check_id($conn, $mail)
{
    $query = "SELECT user_id FROM users WHERE mail = '$mail'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        return $row["user_id"];
    } else {
        echo "Failed to get user ID for login";
        exit;
    }
}

function create_login_session($conn,$user_id,$name,$username,$mail,$profile_color){
    $_SESSION["user_id"] = $user_id;
    $_SESSION["name"] = $name;
    $_SESSION["username"] = $username;
    $_SESSION["mail"] = $mail;
    $_SESSION["profile_color"] = $profile_color;
    echo "login";
    $conn->close();
}

?>
