<?php
include "./config.php";


if (isset($_GET["page_id"]) && !empty($_GET["page_id"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["mail"])){
    check_empty($conn, $_GET["page_id"], $_SESSION["mail"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}


function check_empty($conn, $page_id, $mail){
    $query = "SELECT * FROM users WHERE mail ='$mail'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        if ($row["shortcuts"] == "") {
            add_to_shortcut($conn, $page_id, false, $mail);
        } else {
            $shortcutArray = explode(",", $row["shortcuts"]);

            $shortcutCount = count($shortcutArray);
            if ($shortcutCount >=4) {
                echo "Sorry, you can only add up to 4 pages to the shortcut";
            } else {
                add_to_shortcut($conn, $page_id, true, $mail);
            }
        }
    } else {
        echo "User not found. Please log in again";
    }
}


function add_to_shortcut($conn, $page_id, $empty, $mail)
{
    if($empty){
        $sql = "UPDATE users SET shortcuts = CONCAT(shortcuts, ',$page_id') WHERE NOT FIND_IN_SET('$page_id', shortcuts)";
    }else{
        $sql = "UPDATE users SET shortcuts = CONCAT(shortcuts, '$page_id') WHERE NOT FIND_IN_SET('$page_id', shortcuts)";
    }
    if ($conn->query($sql) === true) {
        if($conn->affected_rows==0){
            echo "Can't add the same page to shortcuts";
        }else{
            echo "added";
        }
    } else {
        echo "Failed to add page to shortcut. Please try again later";
    }
}


?>
