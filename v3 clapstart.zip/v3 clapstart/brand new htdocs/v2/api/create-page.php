<?php
include "./config.php";

if (isset($_GET["name"]) && !empty($_GET["name"]) && 
    isset($_GET["type"]) && !empty($_GET["type"]) && 
    isset($_GET["workspace_id"]) && !empty($_GET["workspace_id"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    create_page($conn, $_SESSION["user_id"], $_GET["workspace_id"], $_GET["name"], $_GET["type"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}

function generateURL($conn,$name) {
    $hash = md5($name);
    $shortID = substr($hash, 0, 6);
    while(check_url($conn,$shortID)){
        $name .= "c";
        $hash = md5($name);
        $shortID = substr($hash, 0, 6);
    }
    return $shortID;
}

function check_url($conn,$shortID){
    $query = "SELECT * FROM pages WHERE url='$shortID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        return true;
    } else {
        return false;
    }
}

function create_page($conn, $id, $workspace_id, $name, $type)
{
    $url = generateURL($conn,$name);
    echo $url;
    $sql = "INSERT INTO pages (admin, workspace_id, name,type,url,creation_log) VALUES ('$id','$workspace_id','$name','$type','$url',NOW())";

    if ($conn->query($sql) === true) {
        echo "created";
    } else {
        echo "Unable to create workspace page. Please try again later";
    }
}
?>