<?php
include "./config.php";

if (isset($_GET["mail"]) && !empty($_GET["mail"])) {
    check_mail($conn, $_GET["mail"]);
} else {
    echo "Some fields are empty";
}

function check_mail($conn, $mail)
{
    $query = "SELECT * FROM users WHERE mail = '$mail'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        check_username($conn, $mail);
    } else {
        create_account_by_mail($conn, $mail);
    }
}

function check_username($conn, $mail)
{
    $query = "SELECT * FROM users WHERE mail ='$mail' AND username!=''";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        create_login_session($conn,$row["user_id"],$row["name"],$row["username"],$row["mail"],$row["profile_color"]);
    } else {
        create_account_setup_session($conn,$mail);
    }
}

function create_account_by_mail($conn, $mail)
{
    $sql = "INSERT INTO users (mail,creation_log) VALUES ('$mail',NOW())";

    if ($conn->query($sql) === true) {
        create_account_setup_session($conn,$mail);
    } else {
        echo "Failed to create account. Please try again later";
    }
}

function create_login_session($conn,$user_id,$name,$username,$mail,$profile_color){
    $_SESSION["user_id"] = $user_id;
    $_SESSION["name"] = $name;
    $_SESSION["username"] = $username;
    $_SESSION["mail"] = $mail;
    $_SESSION["profile_color"] = $profile_color;
    echo "login";
    $conn->close();
}


function create_account_setup_session($conn,$mail){
    $_SESSION["mail"] = $mail;
    echo "account setup";
    $conn->close();
}

?>
