<?php
include './config.php';


if (isset($_GET["query"]) && !empty($_GET["query"]) && 
    isset($_GET["mails"]) && !empty($_GET["mails"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    search($conn, $_GET["query"], $_GET["mails"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}

function search($conn,$query,$mails){


$mails = explode(',', $mails);

$mails = array_map(function ($mail) {
    return "'" . trim($mail) . "'";
}, $mails);

$mails = implode(', ', $mails);


// Query to fetch name from the 'users' table
$usersQuery = "SELECT * FROM users WHERE name LIKE '%$query%' AND mail NOT IN ($mails)";
$usersResult = $conn->query($usersQuery);


// Fetch and process data from the 'users' table
if ($usersResult->num_rows > 0) {
    while ($row = $usersResult->fetch_assoc()) {
        echo $row["mail"];
        // Process $userName
    }
}else{
    echo "No result found";
}

}
?>