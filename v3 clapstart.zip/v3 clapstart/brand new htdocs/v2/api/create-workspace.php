<?php
include "./config.php";



if (isset($_GET["name"]) && !empty($_GET["name"]) &&
    isset($_GET["type"]) && !empty($_GET["type"])) {

} else {
    echo "Some fields are empty";
    exit;
}

if (isset($_SESSION["user_id"])){
    create_workspace($conn, $_SESSION["user_id"], $_GET["name"], $_GET["type"]);
} else {
    echo "You are not logged in. Please log in to access this page";
}


function create_workspace($conn, $id, $name, $type)
{
    $color = icon_color();
    $url = generateURL($conn,$name);
    $sql = "INSERT INTO workspaces (admin,name,type,icon_color,url,creation_log) VALUES ('$id','$name','$type','$color','$url',NOW())";

    if ($conn->query($sql) === true) {
        echo "created";
    } else {
        echo "Unable to create workspace. Please try again later";
    }
}

function icon_color(){
    $color = array(
        "linear-gradient(137deg, #FF2AD0 0%, #8D00B1 100%);",
        "linear-gradient(137deg, #6590FF 0%, #05379A 100%);",
        "linear-gradient(137deg, #FED235 0%, #D68424 100%);",
        "linear-gradient(137deg, #2CD35A 0%, #00924C 100%);",
        "linear-gradient(137deg, #FF6565 0%, #950000 100%);",
        "linear-gradient(137deg, #5E5E5E 0%, #2D2D2D 100%);"
    );
    
    $colorIndex = array_rand($color);
    $colorCode = $color[$colorIndex];
    return $colorCode;
}


function generateURL($conn,$name) {
    $hash = md5($name);
    $shortID = substr($hash, 0, 6);
    while(check_url($conn,$shortID)){
        $name .= "c";
        $hash = md5($name);
        $shortID = substr($hash, 0, 6);
    }
    return $shortID;
}

function check_url($conn,$shortID){
    $query = "SELECT * FROM workspaces WHERE url='$shortID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        return true;
    } else {
        return false;
    }
}


?>