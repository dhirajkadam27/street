<?php
   include '../../config.php';

   if(isset($_GET['email'])){
      if(isset($_GET['username'])){
         if(isset($_GET['name'])){
            $email = $_GET['email'];
            $name = $_GET['name'];
            $username = $_GET['username'];
            account_setup($conn, $email,$name, $username);
         }else{
           echo "Name not found";
         }
      }else{
         echo "Username not found";
      }
   }else{
      echo "Email not found";
   }
  
   function account_setup($conn, $email,$name, $username){
      $color = array(
         "#FF4A4A",
         "#FF4A80",
         "#FFAC4A",
         "#4AB3FF",
         "#BA4AFF"
     );
     
     $colorIndex = array_rand($color);
     $colorCode = $color[$colorIndex];

     
     $sql = "SELECT * FROM users WHERE email = '$email'";
     $result = mysqli_query($conn, $sql);
     $row = mysqli_fetch_assoc($result);
     if (mysqli_num_rows($result) > 0) {
      

      $sql1 = "UPDATE users SET username='$username', name='$name', color='$colorCode' WHERE email='$email'";
         if ($conn->query($sql1) === TRUE) {
         echo "Login";
         $_SESSION['email'] = $email;
         $_SESSION['username'] = $username;
         $_SESSION['name'] = $name;
         $_SESSION['color'] = $colorCode;
         $_SESSION['id'] = $row['id'];
         } else {
         echo "Failed to Login";
         }
     } else {
      echo "Failed to Login";
     }

      
   }
   ?>