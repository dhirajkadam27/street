<?php
include '../../config.php';

if(isset($_GET['color'])){
    if(isset($_GET['username'])){
       if(isset($_GET['name'])){
        if(isset($_SESSION['email'])){
            $email = $_SESSION['email'];
            $color = $_GET['color'];
            $name = $_GET['name'];
            $username = $_GET['username'];
            update_user($conn, $email, $color,$name, $username);
        }else{
            echo "User not loged in";
        }
       }else{
         echo "Name not found";
       }
    }else{
       echo "Username not found";
    }
 }else{
    echo "color not found";
 }

function update_user($conn,$email,$color,$name,$username){
    $sql = "UPDATE users SET username='$username', name='$name', color='$color' WHERE email='$email'";

    if ($conn->query($sql) === TRUE) {
        
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $name;
        $_SESSION['color'] = $color;
      echo "Updated";
    } else {
      echo "Not Updated";
    }
}
?>