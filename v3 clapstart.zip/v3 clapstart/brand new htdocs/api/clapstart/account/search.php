<?php
include '../../config.php';

if(isset($_GET['query'])){
    $searchQuery = $_GET['query'];
    Search_query($conn,$searchQuery);

}else{
    echo 'Not found';
}

function Search_query($conn,$searchQuery){

$results = array();

// Search in the users database
$sql = "SELECT * FROM users WHERE name LIKE '%$searchQuery%'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $results[] =  '<div class="search_result">
    <div class="search_result_img"><div style="background:'.$row['color'].'" class="search_result_icon">'.$row['name'][0].'</div></div>
    <div class="search_result_txt">
        <div class="search_result_name">'.$row['name'].'</div>
        <div class="search_result_type">@'.$row['username'].' | User</div>
    </div>
</div>';
}

// Search in the workspaces database
$sql = "SELECT * FROM workspaces WHERE name LIKE '%$searchQuery%'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $results[] =  '<a href="/street/workspace.php?url='.$row['name'].'" class="search_result">
    <div class="search_result_img"><div style="background:'.$row['color'].'" class="search_result_icon">'.$row['name'][0].'</div></div>
    <div class="search_result_txt">
        <div class="search_result_name">'.$row['name'].'</div>
        <div class="search_result_type">'.$row['type'].' | Workspace</div>
    </div>
</a>';
}

// Search in the projects database
$sql = "SELECT * FROM projects WHERE name LIKE '%$searchQuery%'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $results[] =  '<div class="search_result">
    <div class="search_result_img"><div style="background:linear-gradient(137deg, #2CD35A 0%, #00924C 100%)" class="search_result_icon">'.$row['name'][0].'</div></div>
    <div class="search_result_txt">
        <div class="search_result_name">'.$row['name'].'</div>
        <div class="search_result_type">'.$row['type'].' | Project</div>
    </div>
</div>';
}

// Search in the pages database
$sql = "SELECT * FROM pages WHERE name LIKE '%$searchQuery%'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $results[] =  '<div class="search_result">
    <div class="search_result_img"><div style="background:'.$row['color'].'" class="search_result_icon">'.$row['Name'][0].'</div></div>
    <div class="search_result_txt">
        <div class="search_result_name">'.$row['Name'].'</div>
        <div class="search_result_type">'.$row['type'].' | Page</div>
    </div>
</div>';
}

// Close the database connection
$conn->close();

// Return the results as HTML
foreach ($results as $result) {
    echo $result;
}
}



?>