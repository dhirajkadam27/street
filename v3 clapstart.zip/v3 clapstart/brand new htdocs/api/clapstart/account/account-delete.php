<?php
include '../../config.php';

if(isset($_SESSION['email'])){
    $email = $_SESSION['email'];
    delete_user($conn,$email);

}else{
    echo 'User not logged in';
}

function delete_user($conn,$email){
    $sql = "DELETE FROM users WHERE email='$email'";

    if ($conn->query($sql) === TRUE) {
        
    session_destroy();
      echo "Deleted";
    } else {
      echo "Not Deleted";
    }
}
?>