<?php
   include '../../config.php';
   
   if(isset($_GET['email'])){
    $email = $_GET['email'];
    if(checkEmail($email,$conn)){
        checkusername($email,$conn);
    }else{
        account_create($email,$conn);
    }
   }else{
    echo "Email not found";
   }

   function checkEmail($email,$conn){
     $sql = "SELECT * FROM users WHERE email = '$email'";
     $result = mysqli_query($conn, $sql);
     if (mysqli_num_rows($result) > 0) {
         return true;
     } else {
         return false;
     }
   }

   function checkusername($email,$conn){
    $sql = "SELECT * FROM users WHERE email = '$email' AND username!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        echo "Login";
        $_SESSION['email'] = $email;
        $_SESSION['username'] = $row['username'];
        $_SESSION['name'] = $row['name'];
        $_SESSION['color'] = $row['color'];
        $_SESSION['id'] = $row['id'];
    } else {
        echo "Account setup";
    }
   }

   
   function account_create($email,$conn){
    $sql = "INSERT INTO users (email,creation_log) VALUES ('$email', NOW())";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo "Account setup";
        } else {
            echo "Failed to create account";
        }
   }
   
   ?>