<?php
include '../../config.php';
include '../../../smtp/PHPMailerAutoload.php';

$old_data = "";
if(isset($_GET['userids'])){
    if(isset($_GET['url'])){
        $url = $_GET['url'];
        $userids = $_GET['userids'];
        if(isset($_GET['type'])){
            if($_GET['type']=="Members"){
                checkMembers($url,$conn,$userids);
            }else{
                checkObserver($url,$conn,$userids);
            }
        }else{
            echo 'type Not found';
        }
    }else{
        echo 'Url Not found';
    }
}else{
    echo 'User id Not found';
}

function check_guest_by_userids($conn,$userids){
    $userids_array = explode(',', $userids);
    foreach ($userids_array as $id) {
        $sql = "SELECT * FROM workspaces WHERE FIND_IN_SET('$id', admin) OR FIND_IN_SET('$id', members) OR FIND_IN_SET('$id', observers)";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) > 0) {
            return true;
        } else {
            return false;
        }
    }
    
}


function checkGuests($url,$conn,$guestid){
    $sql = "SELECT * FROM workspaces WHERE url = '$url' AND guests!='$guestid'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['guests'];
        $guestid = $old_data.",".$guestid;
        addMembers($url,$guestid,$conn);
    } else {
        addMembers($url,$guestid,$conn);
    }
  }




function checkMembers($url,$conn,$userids){
    $sql = "SELECT * FROM projects WHERE url = '$url' AND members!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['members'];
        $userids = $old_data.",".$userids;
        addMembers($url,$userids,$conn);
    } else {
        addMembers($url,$userids,$conn);
    }
  }

  function addMembers($url,$userids,$conn){
    $sql = "UPDATE projects SET members='$userids' WHERE url='$url'";
    if ($conn->query($sql) === TRUE) {
    echo "Added";
    } else {
    echo "Failed to add";
    }
  }



  
function checkObserver($url,$conn,$userids){
    $sql = "SELECT * FROM projects WHERE url = '$url' AND observers!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['observers'];
        $userids = $old_data.",".$userids;
        addObserver($url,$userids,$conn);
    } else {
        addObserver($url,$userids,$conn);
    }
  }

  function addObserver($url,$userids,$conn){
    $sql = "UPDATE projects SET observers='$userids' WHERE url='$url'";
    if ($conn->query($sql) === TRUE) {
    echo "Added";
    } else {
    echo "Failed to add";
    }
  }


  if(isset($_GET['find_found'])){
if($_GET['find_found']=="false"){
    $mail = $_GET['mail'];
    $html = "Dear User,
  
    You don't have Clapstart account. Create your account
    http://clapstart.com/signup.php
    
    Thank you for using our services.
    
    Sincerely,
    Clapstart";
    
    smtp_mailer($mail,'Create Your Account',$html);
}
  }

  function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "clapstart.solutions@gmail.com";
	$mail->Password = "lyjctyvdmtwncvps";
	$mail->SetFrom("clapstart.solutions@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
		// return 'Sent';
	}
}

?>