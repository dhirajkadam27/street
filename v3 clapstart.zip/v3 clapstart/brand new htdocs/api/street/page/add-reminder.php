<?php
include '../../config.php';

    if(isset($_GET['name'])){

        if(isset($_GET['reminder'])){
            $name = $_GET['name'];
            $reminder = $_GET['reminder'];
            add_assignee($conn,$name,$reminder);
        }else{
            echo 'no username found';
        }

    }else{
        echo 'no name found';
    }



function add_assignee($conn,$name,$reminder){
    date_default_timezone_set('Asia/Kolkata');
$todayDate = date('Y-m-d');
    $sql = "UPDATE `task` SET `reminder`='$reminder',`updated_on`='$todayDate' WHERE name='$name'";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo 'created';
        } else {
            echo "Failed to create";
        }

}

?>