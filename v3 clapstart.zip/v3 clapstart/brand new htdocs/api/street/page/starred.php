<?php
include '../../config.php';

if(isset($_GET['url'])){
    if(isset($_GET['userid'])){
        if(isset($_GET['type'])){
            $userid = $_GET['userid'];
            $url = $_GET['url'];
            $type = $_GET['type'];
            if($type=="add"){
                add_starred($conn,$url,$userid);
            }else{
                remove_starred($conn,$url,$userid);
            }
        }else{
            echo "no type";
        }
    }else{
        echo "no userid";
    }
}else{
    echo "no url";
}

function add_starred($conn,$url,$userid){

    $sql = "SELECT * FROM projects WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        if($row['starred']==''){
            $starreddata = $userid;
        }else{
            $starreddata = $row['starred'].",".$userid;
        }

        
    $update_sql = "UPDATE projects SET starred='$starreddata' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }

}

function remove_starred($conn,$url,$userid){

    $sql = "SELECT * FROM projects WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_data1 = $row['starred']; 
        $old_array1 = explode(",", $old_data1);
        $indexToRemove1 = array_search("$userid", $old_array1);
        if ($indexToRemove1 !== false) {
            unset($old_array1[$indexToRemove1]);
        }
        $new_data1 = implode(",", $old_array1);

        
    $update_sql = "UPDATE projects SET starred='$new_data1' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }

}
?>