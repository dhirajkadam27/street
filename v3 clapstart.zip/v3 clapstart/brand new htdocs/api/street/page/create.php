<?php
include '../../config.php';
include '../../../smtp/PHPMailerAutoload.php';

if(isset($_GET['name'])){
    if(isset($_GET['url'])){
        if(isset($_GET['type'])){
            if(isset($_SESSION['id'])){
                $name = $_GET['name'];
                $url = $_GET['url'];
                $type = $_GET['type'];
                $id = $_SESSION['id'];
                $mail = $_SESSION['email'];
                create_page($conn,$name,$url,$type,$id,$mail);
            }else{
                echo 'no login';
            }
        }else{
            echo 'no type found';
        }
    }else{
        echo 'no url found';
    }
}else{
    echo 'no name found';
}

function create_page($conn,$name,$workspace_url,$type,$id,$mail){

    $url = $name;

       function generateShortUrl($url) {
        $url = strtolower($url);
        
        $url = str_replace(' ', '-', $url);
        
        $url = preg_replace('/[^a-z0-9-]/', '', $url);
        
        $url = preg_replace('/-+/', '-', $url);
        $url = trim($url, '-');
        
        // Return the short URL
        return $url;
    }

    $url = generateShortUrl($url);

    $sql = "INSERT INTO projects (admin,name,url,type,workspace_url,creation_log) VALUES ('$id','$name','$url','$type','$workspace_url', NOW())";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo $url;
            
            $html = "Dear User,

Your Project is created.
http://clapstart.com/street/p/?url=".$url."

Thank you for using our services.

Sincerely,
Clapstart";

smtp_mailer($mail,'Project Created Successfully',$html);

        } else {
            echo "Failed to create";
        }

}



function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "clapstart.solutions@gmail.com";
	$mail->Password = "lyjctyvdmtwncvps";
	$mail->SetFrom("clapstart.solutions@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
		// return 'Sent';
	}
}

?>