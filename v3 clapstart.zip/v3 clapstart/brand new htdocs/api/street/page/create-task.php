<?php
include '../../config.php';

if(isset($_GET['url'])){

    if(isset($_GET['name'])){

        if(isset($_GET['type'])){
            $name = $_GET['name'];
            $url = $_GET['url'];
            $type = $_GET['type'];
            $username = $_SESSION['username'];
            create_task($conn,$name,$type,$url,$username);
        }else{
            echo 'no type found';
        }

    }else{
        echo 'no name found';
    }

}else{
    echo 'no url found';
}

function create_task($conn,$name,$type,$url,$username){
    date_default_timezone_set('Asia/Kolkata');
$todayDate = date('Y-m-d');
    $sql = "INSERT INTO `task`(`project_url`, `name`, `type`,`created_by`,`created_on`,`updated_on`) VALUES ('$url','$name','$type','$username','$todayDate','$todayDate')";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo 'created';
        } else {
            echo "Failed to create";
        }

}

?>