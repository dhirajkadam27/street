<?php
include '../../config.php';

if(isset($_GET['query'])){
            $query = $_GET['query'];
            assignee($conn,$query);
}else{
    echo 'no name found';
}

function assignee($conn,$query){
    $sql = "SELECT * From `users` WHERE username LIKE '%$query%'";

// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result) {
    // Fetch and echo the data
    while ($row = $result->fetch_assoc()) {
        echo '<div onclick="add_assignee('."'".$row['username']."'".')" class="username_src">'.$row['username'].'</div>';
    }
} else {
    echo "Error: " . $conn->error;
}

// Close the database connection
$conn->close();
}

?>