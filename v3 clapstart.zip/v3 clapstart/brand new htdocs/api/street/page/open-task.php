<?php
include '../../config.php';

if(isset($_GET['name'])){
            $name = $_GET['name'];
            drag_task($conn,$name);
}else{
    echo 'no name found';
}

function drag_task($conn,$name){
    $sql = "SELECT * From `task` WHERE name='$name'";

// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result) {
    // Fetch and echo the data
    while ($row = $result->fetch_assoc()) {
        echo '<button onclick="document.getElementById('."'".'popup'."'".').style.display='."'".'none'."'".'" class="cross_close">X</button>
        <label>Task</label>
            <input id="task_name" value="'.$row['name'].'">
        <label>Type</label>
            <input value="'.$row['type'].'" disabled>
            <label>Created By</label>
                <input value="'.$row['created_by'].'" disabled>
                <label>Created On</label>
                    <input value="'.$row['created_on'].'" disabled>
        <label>Assignee</label>
            <input oninput="assignee(this)" id="assignee_input" value="'.$row['assignee'].'">
            <div id="auto_suggest">
            </div>
            <label>Updated On</label>
                <input value="'.$row['updated_on'].'" disabled>
                <label>Reminder</label>
                    <input type="date" onchange="reminder_input(this)" value="'.$row['reminder'].'">
                    <label>Completed</label>
                    <input type="checkbox" onchange="done_input(this)" id="yourCheckBoxId" '; if ($row['done'] == 1) echo 'checked'; echo '>';
    }
} else {
    echo "Error: " . $conn->error;
}

// Close the database connection
$conn->close();
}

?>