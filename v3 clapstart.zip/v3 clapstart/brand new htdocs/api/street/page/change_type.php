<?php
include '../../config.php';

if(isset($_GET['type'])){
    if(isset($_GET['url'])){
        $url = $_GET['url'];
        $type = $_GET['type'];
        change_type($conn,$url,$type);
    }else{
        echo 'no url';
    }
}else{
    echo 'no type';
}

function change_type($conn,$url,$type){
    $sql = "UPDATE projects SET type='$type' WHERE url='$url'";

    if ($conn->query($sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }
}

?>