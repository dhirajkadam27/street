<?php
include '../../config.php';

if(isset($_GET['url'])){

    if(isset($_GET['name'])){

        if(isset($_GET['type'])){
            $name = $_GET['name'];
            $url = $_GET['url'];
            $type = $_GET['type'];
            drag_task($conn,$name,$type,$url);
        }else{
            echo 'no type found';
        }

    }else{
        echo 'no name found';
    }

}else{
    echo 'no url found';
}

function drag_task($conn,$name,$type,$url){
    date_default_timezone_set('Asia/Kolkata');
$todayDate = date('Y-m-d');
    $sql = "UPDATE `task` SET `project_url`='$url',`type`='$type',`updated_on`='$todayDate' WHERE name='$name'";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo 'created';
        } else {
            echo "Failed to create";
        }

}

?>