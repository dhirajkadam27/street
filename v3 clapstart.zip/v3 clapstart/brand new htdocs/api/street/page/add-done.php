<?php
include '../../config.php';

    if(isset($_GET['name'])){

        if(isset($_GET['done'])){
            $name = $_GET['name'];
            $done = $_GET['done'];
            add_done($conn,$name,$done);
        }else{
            echo 'no username found';
        }

    }else{
        echo 'no name found';
    }



function add_done($conn,$name,$done){
    date_default_timezone_set('Asia/Kolkata');
$todayDate = date('Y-m-d');
    $sql = "UPDATE `task` SET `done`=$done,`updated_on`='$todayDate' WHERE name='$name'";
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            echo 'created';
        } else {
            echo "Failed to create";
        }

}

?>