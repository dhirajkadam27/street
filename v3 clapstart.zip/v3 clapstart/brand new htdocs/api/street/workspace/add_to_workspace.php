<?php
include '../../config.php';

if(isset($_GET['url'])){
    if(isset($_GET['userid'])){
        $url = $_GET['url'];
        $userid = $_GET['userid'];
        add_to_workspace($conn,$url,$userid);
    }else{
        echo 'no userd';
    }
}else{
    echo 'no url';
}

function add_to_workspace($conn,$url,$userid){


    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        if($row['members']==''){
            $typedata = $userid;
        }else{
            $typedata = $row['members'].",".$userid;
        }

        
    $update_sql = "UPDATE workspaces SET members='$typedata' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";

    }

        

}
?>