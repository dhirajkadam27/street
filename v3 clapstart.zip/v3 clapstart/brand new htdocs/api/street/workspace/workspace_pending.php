<?php
include '../../config.php';

if(isset($_GET['userid'])){
    if(isset($_GET['url'])){
        if(isset($_GET['type'])){
            $userid = $_GET['userid'];
            $url = $_GET['url'];
            $type = $_GET['type'];
            if($_GET['type']=="a"){
                confirm_pending($conn,$userid,$url,$type);
            }else{
                reject_pending($conn,$userid,$url,$type);
            }
        }else{
            echo "no type";
        }
    }else{
        echo "no url";
    }
}else{
    echo "no userid";
}

function confirm_pending($conn,$userid,$url,$type){

    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_data1 = $row['pendings']; 
        $old_array1 = explode(",", $old_data1);
        $indexToRemove1 = array_search("$userid", $old_array1);
        if ($indexToRemove1 !== false) {
            unset($old_array1[$indexToRemove1]);
        }
        $new_data1 = implode(",", $old_array1);

        if($row['members']==''){
            $typedata = $userid;
        }else{
            $typedata = $row['members'].",".$userid;
        }

        
    $update_sql = "UPDATE workspaces SET pendings='$new_data1', members='$typedata' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }

}

function reject_pending($conn,$userid,$url,$type){

    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_data1 = $row['pendings']; 
        $old_array1 = explode(",", $old_data1);
        $indexToRemove1 = array_search("$userid", $old_array1);
        if ($indexToRemove1 !== false) {
            unset($old_array1[$indexToRemove1]);
        }
        $new_data1 = implode(",", $old_array1);

        
    $update_sql = "UPDATE workspaces SET pendings='$new_data1' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }

}
?>