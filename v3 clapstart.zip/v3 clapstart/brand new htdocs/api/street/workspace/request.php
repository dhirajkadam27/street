<?php
include '../../config.php';

$old_data = "";
if(isset($_GET['userid'])){
    if(isset($_GET['url'])){
        $url = $_GET['url'];
        $userid = $_GET['userid'];
        checkPending($url,$conn,$userid);
    }else{
        echo 'Url Not found';
    }
}else{
    echo 'User id Not found';
}
  
function checkPending($url,$conn,$userid){
    $sql = "SELECT * FROM workspaces WHERE url = '$url' AND pendings!=''";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        $old_data = $row['pendings'];
        $userid = $old_data.",".$userid;
        addPending($url,$userid,$conn);
    } else {
        addPending($url,$userid,$conn);
    }
  }

  function addPending($url,$userid,$conn){
    $sql = "UPDATE workspaces SET pendings='$userid' WHERE url='$url'";
    if ($conn->query($sql) === TRUE) {
    echo "Added";
    } else {
    echo "Failed to add";
    }
  }

?>