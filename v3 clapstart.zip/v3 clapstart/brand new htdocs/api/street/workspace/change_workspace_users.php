<?php
include '../../config.php';

if(isset($_GET['userid'])){
    if(isset($_GET['url'])){
        if(isset($_GET['type'])){
            if(isset($_GET['old'])){
                $url = $_GET['url'];
                $userid = $_GET['userid'];
                $type = $_GET['type'];
                $old = $_GET['old'];
                change_invitation($conn,$url,$userid,$type,$old);
            }else{
                echo 'no old found';
            }

        }else{
            echo 'no type found';
        }
    }else{
        echo 'no url found';
    }
}else{
    echo 'no userid found';
}


function change_invitation($conn,$url,$userid,$type,$old){
    

    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_data1 = $row[$old]; 
        $old_array1 = explode(",", $old_data1);
        $indexToRemove1 = array_search("$userid", $old_array1);
        if ($indexToRemove1 !== false) {
            unset($old_array1[$indexToRemove1]);
        }
        $new_data1 = implode(",", $old_array1);

        if($row[$type]==''){
            $typedata = $userid;
        }else{
            $typedata = $row[$type].",".$userid;
        }

        
    $update_sql = "UPDATE workspaces SET $old='$new_data1', $type='$typedata' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }



   }


?>