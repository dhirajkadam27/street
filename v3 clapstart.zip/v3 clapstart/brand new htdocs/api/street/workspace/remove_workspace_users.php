<?php
include '../../config.php';

if(isset($_GET['userid'])){
    if(isset($_GET['url'])){
        if(isset($_GET['type'])){
            $url = $_GET['url'];
            $userid = $_GET['userid'];
            if($_GET['type']=="Member"){
                check_members($conn,$url,$userid);
            }else if($_GET['type']=="Admin"){
                check_admin($conn,$url,$userid);
            }else{
                check_observers($conn,$url,$userid);
            }

        }else{
            echo 'no type found';
        }
    }else{
        echo 'no url found';
    }
}else{
    echo 'no userid found';
}


function check_members($conn,$url,$userid){
    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_members = $row['members']; 
        $members_array = explode(",", $old_members);
        $indexToRemove = array_search("$userid", $members_array);
        if ($indexToRemove !== false) {
            unset($members_array[$indexToRemove]);
        }
        $new_members = implode(",", $members_array);
        
    $update_sql = "UPDATE workspaces SET members='$new_members' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }
   }


   function check_admin($conn,$url,$userid){
    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_admins = $row['admin']; 
        $admins_array = explode(",", $old_admins);
        $indexToRemove = array_search("$userid", $admins_array);
        if ($indexToRemove !== false) {
            unset($admins_array[$indexToRemove]);
        }
        $new_admins = implode(",", $admins_array);
        
    $update_sql = "UPDATE workspaces SET admin='$new_admins' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }
   }



   function check_observers($conn,$url,$userid){
    $sql = "SELECT * FROM workspaces WHERE url='$url'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

        $old_observers = $row['observers']; 
        $observers_array = explode(",", $old_observers);
        $indexToRemove = array_search("$userid", $observers_array);
        if ($indexToRemove !== false) {
            unset($observers_array[$indexToRemove]);
        }
        $new_observers = implode(",", $observers_array);

        
    $update_sql = "UPDATE workspaces SET observers='$new_observers' WHERE url='$url'";
    if ($conn->query($update_sql) === TRUE) {
      echo "Updated";
    } else {
      echo "Not Updated";
    }

    } else {
        echo "failed";
    }
   }

?>