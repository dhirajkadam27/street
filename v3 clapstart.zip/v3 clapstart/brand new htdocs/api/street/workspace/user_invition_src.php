<?php
include '../../config.php';

if(isset($_GET['query'])){
    $query = $_GET['query'];
    Search_query($conn,$query);

}else{
    echo 'Not found';
}

function Search_query($conn,$query){

    $sql = "SELECT * FROM users WHERE name LIKE '%$query%' or username LIKE '%$query%' or email LIKE '%$query%'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div data-id="'.$row['id'].'" data-email="'.$row['email'].'" onclick="invite_profile(this)" class="email_box">
            <div class="email_icon">'.$row['name'][0].'</div>
            <div class="email txt">
                <div class="email_name">'.$row['name'].'</div>
                <div class="email_username">@'.$row['username'].'</div>
            </div>
        </div>';
        }
    } else {
        echo "Not found";
    }
    
}
?>