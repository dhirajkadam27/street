<?php
include '../../config.php';

if(isset($_GET['name'])){
    if(isset($_GET['color'])){
        if(isset($_GET['url'])){
            if(isset($_GET['type'])){
                
              if(isset($_GET['new_url'])){
                $name = $_GET['name'];
                $color = $_GET['color'];
                $type = $_GET['type'];
                $new_url = $_GET['new_url'];
                $url = $_GET['url'];
                
                   $update_sql = "UPDATE workspaces SET name='$name', color='$color', type='$type', url='$new_url' WHERE url='$url'";
                    if ($conn->query($update_sql) === TRUE) {
                    echo "Updated";
                    } else {
                    echo "Not Updated";
                    }
                }else{
                    echo 'no new url';
                }
            }else{
                echo 'no type';
            }
        }else{
            echo 'no url';
        }
    }else{
        echo 'no color';
    }
}else{
    echo 'no name';
}
?>