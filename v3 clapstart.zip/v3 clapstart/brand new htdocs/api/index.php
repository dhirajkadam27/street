<?php
include './config.php';
include './php.php';

$name = "name";
$username = "username";
$email = "email";
$colorCode = "#FF4A80";
check_username($conn, $username);
?>