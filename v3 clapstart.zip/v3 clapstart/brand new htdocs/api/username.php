<?php
include './config.php';
include './php.php';

$username = $_GET['username'];
check_username($conn, $username);
?>