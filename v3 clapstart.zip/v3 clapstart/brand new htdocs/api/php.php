<?php

function check_user($conn, $email)
{
    $query = "SELECT id FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        return true;
    } else {
        return false;
    }
    mysqli_close($conn);
}
function user_login($conn, $email)
{
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION["id"] = $row["id"];
        $_SESSION["name"] = $row["name"];
        $_SESSION["username"] = $row["username"];
        $_SESSION["email"] = $row["email"];
        $_SESSION["color"] = $row["color"];
        echo "true";
    } else {
        echo "false";
    }
    mysqli_close($conn);
}
function user_signup($conn, $email)
{
    $sql = "INSERT INTO users (email,creation_log)
VALUES ('$email',NOW())";

    if ($conn->query($sql) === true) {
        $_SESSION["email"] = $email;
        return true;
    } else {
        return false;
    }

    $conn->close();
}

function profile_color()
{
    $color = ["#FF4A4A", "#FF4A80", "#FFAC4A", "#4AB3FF", "#BA4AFF"];

    $colorIndex = array_rand($color);
    $colorCode = $color[$colorIndex];

    return $colorCode;
}

function check_id($conn, $email)
{
    $query = "SELECT id FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) {
        return $row["id"];
    } else {
        echo false;
    }
}

function create_account($conn,$username,$name,$email){
    $color = profile_color();
    $sql = "UPDATE users SET username='$username', name='$name', color='$color' WHERE email='$email'";
    if ($conn->query($sql) === true) {
        $_SESSION["id"] = check_id($conn, $email);
        $_SESSION["name"] = $name;
        $_SESSION["username"] = $username;
        $_SESSION["email"] = $email;
        $_SESSION["color"] = $color;
        echo 'true';
    } else {
        echo 'false';
    }

    $conn->close();
}



function check_username($conn, $username)
{
    $query = "SELECT username FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo 'true';
    } else {
        echo 'false';
    }
    mysqli_close($conn);
}


?>
