<?php
include './config.php';
include './php.php';

$username = $_GET['username'];
$name = $_GET['name'];
$email = $_GET['email'];
create_account($conn,$username,$name,$email);
?>