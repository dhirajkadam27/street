<?php
include './config.php';
include './php.php';

$email = $_GET['email'];
if(check_user($conn, $email)){
    user_login($conn, $email);
}else{
    if(user_signup($conn, $email)){
        echo 'account created';
    }else{
        echo 'false';
    }  
}
?>