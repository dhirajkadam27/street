<?php
   session_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    exit;
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
}
?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="./assets/js/clapstart.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}
.store_nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 40px;
    padding: 0px 2%;
    border-bottom: 1px solid #E1E6F0;
}

.store_nav_logo img {
    height: 25px;
    cursor: pointer;
}

.store_nav_search_box {
    display: flex;
    align-items: center;
    border-radius: 6px;
    background: #E1E6F0;
    width: 30%;
    height: 25px;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.store_nav_search_box:active{
    background: #d0d6e0;
    transform: scale(0.99);
}

.store_nav_search_box span {
    font-size: 17px;
    margin-left: 10px;
    margin-right: 6px;
}


.store_nav_profile_box {
    position: relative;
    z-index: 0;
}

.profile_icon {
    width: 30px;
    height: 30px;
    border-radius: 100px;
    background: #63BEFF;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 600;
    color: white;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.profile_icon:active{
    background: #44a3e7;
    transform: scale(0.99);
}
.store_main {
    width: 96%;
    margin: 2%;
}

.store_title {
    color: #001930;
    font-size: 20px;
    font-weight: 700;
}
.product {
    margin-top: 20px;
    display: flex;
    align-items: center;
    width: fit-content;
    border-radius: 10px;
    border: 2px solid #EDF0F7;
    padding: 10px;
    transition: all .2s ease-in-out;
    cursor: pointer;
}

.product:hover {
    background: #f5f7fc;
}

.product_icon img {
    width: 50px;
}

.product_txt {
    text-align: left;
    margin-left: 10px;
}

.product_name {
    color: #001930;
    font-size: 30px;
    font-weight: 700;
}

.product_type {
    color: #78859D;
    font-size: 12px;
    font-weight: 700;
}

#profile_icon_color{
    background:<?php echo $color;?>;
}


</style>
    </head>
    <body>
  
        <div class="store_nav">
            <div class="store_nav_logo"><img src="./assets/img/logo.svg"></div>
            <div onclick="search()" class="store_nav_search_box"><span class="material-icons">search</span>Search</div>
            <div id="store_nav_profile_box" class="store_nav_profile_box">
                 <div onclick="profile('<?php echo $email;?>','<?php echo $name;?>','<?php echo $username;?>')" id="profile_icon_color" class="profile_icon"><?php echo $name[0];?></div>
                </div>
        </div>

        <div class="store_main">
            <div class="store_title">Product</div>
            
            <div onclick="window.location.href='/street'" class="product">
                <div class="product_icon"><img src="./assets/img/street.svg"></div>
                <div class="product_txt">
                    <div class="product_name">Street</div>
                    <div class="product_type">Project management tool</div>
                </div>
            </div>

        </div>




<script>
    // user();
</script>
    </body>
</html>