<?php
   session_start();

if(isset($_SESSION['id'])){
    header("Location: /store.php");
    exit;
}else{
    if(isset($_SESSION['email'])){
        header("Location: /create-account.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | Clapstart</title>
    <link rel="icon" type="image/x-icon" href="/assets/img/clapstart_favicon.png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>



    
        
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>

    <script type="module">
        var stream = null;
        // Import the functions you need from the SDKs you need
        import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
        import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-analytics.js";
        // TODO: Add SDKs for Firebase products that you want to use
        // https://firebase.google.com/docs/web/setup#available-libraries
        
        // Your web app's Firebase configuration
        // For Firebase JS SDK v7.20.0 and later, measurementId is optional
        const firebaseConfig = {
        apiKey: "AIzaSyABfZ1GZ9Eti6e50EgOGkQqJ1s5nzCoIRc",
        authDomain: "clapstart-1492e.firebaseapp.com",
        projectId: "clapstart-1492e",
        storageBucket: "clapstart-1492e.appspot.com",
        messagingSenderId: "953994364799",
        appId: "1:953994364799:web:5269e513f208af7fca3c4a",
        measurementId: "G-HLT4ZP6LHC"
        };
        
        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
        
        
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        </script>


    <style>

            body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100vh;
    font-family: Inter;
    background-color: white;
    background-image: url('/assets/img/account_bg.png');
    background-size: cover;
}
button{
    font-family: Inter;
    border:none;
    padding:0;
    background: none;
    cursor: pointer;
    transition: all .2s ease-in-out; 
}
button .button_content{
    display: flex;
    align-items: center;
    justify-content: center;
}
button .button_loader{
    display: none;
}
button:active{
    transform: scale(0.88) !important;
}
button:hover{
    filter: opacity(0.85) !important;
}
button:disabled{
    filter: opacity(0.8) !important;
    cursor: not-allowed;
}
input{
    font-family: Inter;
}

img{
    height: 100px;
}
.main {
    width: 100%;
    height: 100vh;
    font-family: Inter;
    background-color: #00000082;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: space-evenly;
}
.clapstart_logo img {
    height: 50px;
}

.clapstart_tagline {
    color: #FFF;
    font-size: 20px;
    font-weight: 600;
    margin-top: 10px;
}
.box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    width: 350px;
}

.title {
    color: #001930;
    font-size: 25px;
    font-weight: 800;
    margin-bottom: 10px;
}

.subtitle {
    color: #78859D;
    font-size: 12px;
    font-weight: 600;
    margin-bottom:30px;
}
.subtitle a{
    text-decoration: none;
    color: #2698F0;
}
.subtitle a:hover{
    text-decoration:underline
}
.login_btn {
    border-radius: 5px;
    border: 1px solid #C5E1FF;
    background: #EAF4FF;
    width: 100%;
    height: 40px;
    margin-bottom: 20px;
}
.login_btn_loader {
    display: flex;
    align-items: center;
    justify-content: center;
}

.login_btn_loader img {
    height: 20px;
}
.login_btn_content img {
    height: 20px;
    margin-right: 10px;
}

.login_btn_content {
    color: #526587;
    font-size: 15px;
    font-weight: 600;
    
}

.black_bg {
    width: 100%;
    height: 100%;
    background: black;
    opacity: 0.5;
    position: fixed;
    display: none;
    z-index: 5;
    top: 0;
    left: 0;
}

.error_popup {
    width: 300px;
    background: white;
    border-radius: 10px;
    text-align: center;
    display: none;
    position: fixed;
    z-index: 6;
    top: 30vh;
    left: calc(50% - 150px);
    animation: popup .5s;
    transform: scale(0,0) translate(0, -200px);
            transform: scale(1,1) translate(0, 0);
    animation-fill-mode: forwards;
}


.error_popup_title {
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;
    color: #001930;
}

.error_popup_txt {
    font-size: 15px;
    font-weight: 400;
    margin-top: 10px;
    color: #78859D;
    padding: 10px 20px;
    margin-bottom: 10px;
}

.error_popup button {
    width: 100%;
    height: 50px;
    border-top: 1px solid #e0e0e0;
    color: #2698F0;
    font-size: 18px;
    font-weight: bold;
}

@keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }

    </style>
</head>
<body>


    <div class="main">
        <div class="clapstart_logo">
            <button onclick="window.location.href='/'"><img src="/assets/img/logo.svg"></button>
            <div class="clapstart_tagline">Your Vision, Our Solutions</div>
        </div>
        <div class="box">
            <div class="title">Log In</div>
            <div class="subtitle">New user? <a href="/signup.php">Create an account</a></div>
            <button onclick="redirect_btn_loader(this,google())" class="login_btn">
                <div class="login_btn_content button_content"><img src="/assets/img/google.webp">Sign in with Google</div>
                <div class="login_btn_loader button_loader"><img src="/assets/img/loader.gif"></div>
            </button>
            <button onclick="redirect_btn_loader(this,apple())" class="login_btn">
                <div class="login_btn_content button_content"><img src="/assets/img/apple.svg">Sign in with Apple</div>
                <div class="login_btn_loader button_loader"><img src="/assets/img/loader.gif"></div>
            </button>
        </div>
    </div>

    <div class="black_bg"></div>
    <div class="error_popup close_popup">
        <div class="error_popup_title">Error</div>
        <div class="error_popup_txt">An problem occurred during the user login</div>
        <button onclick="close_error_popup()">Ok</button>
    </div>

    <script>
        function redirect_btn_loader(div,func){
            $(div).find('.button_content').css('display','none');
            $(div).prop("disabled", true);
            $(div).find('.button_loader').css('display','flex');
            func;
        }
       
        
        function google() {
            const googleProvider = new firebase.auth.GoogleAuthProvider();
            firebase.auth().signInWithPopup(googleProvider).then((result) => {
                const user = result.user;
                login(user.email);
            }).catch((error) => {
            error_popup();
            });
        }

    function apple() {
            const appleProvider = new firebase.auth.OAuthProvider('apple.com');
            firebase.auth().signInWithPopup(appleProvider).then((result) => {
                const user = result.user;
                login(user.email);

            }).catch((error) => {
            error_popup();
            });
        }

        function login(email){
            
	$.ajax({
		url: "/api/auth.php",
		type: "GET",
		data: {
			email: email
		},
		dataType: 'text',
		success: function(response) {
			if(response=="true"){
                window.location.href = '/store.php';
			}else if(response=="account created"){
                window.location.href = '/create-account.php';
			}else{
            error_popup();
			}
		},
		error: function(xhr, status, error) {
            error_popup();
		}
	});
        }

        function error_popup(){
            $('.black_bg').css('display','block');
            $('.error_popup').css('display','block');
        }
        function close_error_popup(){
            $('.black_bg').css('display','none');
            $('.error_popup').css('display','none');
            
            $('button').find('.button_content').css('display','flex');
            $('button').prop("disabled", false);
            $('button').find('.button_loader').css('display','none');

        }

    </script>
</body>
</html>