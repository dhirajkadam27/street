<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isadmin = false;
        $ismember = false;
        $isobserver = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 
    }

}
?>
<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}

.workspace_guests {
    margin-top: 20px;
}

.workspace_guests_subtitle {
    font-size: 15px;
    font-weight: 400;
    color: #78859D;
    margin-bottom: 20px;
}

.workspace_guests_list {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}

.workspace_guests_list_left {
    display: flex;
    align-items: center;
}

.workspace_guests_icon {
    width: 40px;
    height: 40px;
    background: #FF6E05;
    border-radius: 100px;
    color: #FFF;
    font-size: 15px;
    font-weight: 400;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}

.workspace_guests_name {
    color: #001930;
    font-size: 13px;
    font-weight: 500;
}

.workspace_guests_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
    margin-top: 2px;
}

.workspace_guests_list_right {
    display: flex;
    align-items: center;
}

.workspace_guests_list_right select {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
}

.workspace_guests_btn {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
    display: flex;
    align-items: center;
    margin-left: 15px;
    cursor: pointer;
}

.workspace_guests_btn span {
    font-size: 15px;
    margin-right: 5px;
}




</style>
    <body>

        <div class="workspace_guests">
            <div class="workspace_guests_subtitle">Workspace guests can view and join all Workspace visible boards and create new boards in the Workspace.</div>
            <div class="workspace_guests_lists">
                
            <?php

$workspace_users = "";
                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        
        $workspace_users = $row['admin'];

        if($row['members']==""){

        }else{
            $workspace_users .= ",".$row['members'];
        }

        if($row['observers']==""){

        }else{
            $workspace_users .= ",".$row['observers'];
        }

    }
}



$project_users = "";

$sql = "SELECT * FROM projects WHERE workspace_url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        if($row['admin']==""){

        }else{
            if($project_users==""){
                $project_users .= $row['admin'];
            }else{
            $project_users .= ",".$row['admin'];
            }
        }

        if($row['members']==""){

        }else{
            $project_users .= ",".$row['members'];
        }

        if($row['observers']==""){

        }else{
            $project_users .= ",".$row['observers'];
        }

    }
}

$project_users_data = explode(",", $project_users);
$unique_project_users = array_unique($project_users_data);
$unique_project_users_data = implode(",", $unique_project_users);


$array1 = explode(",", $workspace_users);
$array2 = explode(",", $unique_project_users_data);

$missingusers = array_diff($array2, $array1);




if(!empty($missingusers)){
    
    foreach ($missingusers as $missingusers_id) {
        $user_sql = "SELECT * FROM users WHERE id='$missingusers_id'";
        $user_result = $conn->query($user_sql);

        if ($user_result->num_rows > 0) {
        // output data of each row
        while($user_row = $user_result->fetch_assoc()) {
            echo '<div class="workspace_guests_list">
            <div class="workspace_guests_list_left">
                <div class="workspace_guests_icon">'.$user_row['name'][0].'</div>
                <div class="workspace_guests_txt">
                    <div class="workspace_guests_name">'.$user_row['name'].'</div>
                    <div class="workspace_guests_username">@'.$user_row['username'].'</div>
                </div>
            </div>
            <div class="workspace_guests_list_right">
                <button onclick="add_to_workspace('."'".$url."'".','."'".$missingusers_id."'".')" class="workspace_guests_btn"><span class="material-icons-outlined">add</span>Add to workspace</button>
            </div>
        </div>';
        }
        } else {
        // echo "0 results";
        }

    }
}


                    ?>

            </div>
        </div>
        
    </body>
</html>