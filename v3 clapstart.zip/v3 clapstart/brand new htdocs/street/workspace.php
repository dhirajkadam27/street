<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.workspace_page {
    width: 100%;
    height: 100vh;
    background: #E1E6F0;
    display: flex;
}

.workspace_page_left {
    width: 250px;
    overflow: hidden;
}

.workspace_page_right {
    width: calc(100% - 250px);
    background: white;
}

.workspace_page_profile {
    cursor: pointer;
    margin: 10px 15px;
    padding: 10px;
    background: white;
    border-radius: 10px;
    display: flex;
    align-items: center;
}

.workspace_page_profile_icon {
    width: 40px;
    height: 40px;
    border-radius: 5px;
    background: linear-gradient(137deg, #FF2AD0 0%, #8D00B1 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 600;
    color: white;
    margin-right: 10px;
}

.workspace_page_profile_txt {width: calc(100% - 70px);}

.workspace_page_profile_name {
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #001930;
    font-size: 13px;
    font-weight: 600;
}

.workspace_page_profile_type {
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #808080;
    font-size: 10px;
    font-weight: 500;
    margin-top: 2px;
}

.workspace_page_link {
    width: 100%;
    border: none;
    margin: 10px 15px;
    padding: 5px 10px;
    background: transparent;
    display: flex;
    align-items: center;
    color: #727884;
    font-size: 15px;
    font-weight: 400;
    border-radius: 9px;
    cursor:pointer
}
.workspace_page_link:hover{
    background: #dae0ea;
}

.workspace_page_link span {
    font-size: 15px;
    margin-right: 10px;
}

.workspace_page_navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 10px;
}

.workspace_page_navbar_left {
    display: flex;
    align-items: center;
}

.store_nav_search_box {
    border: none;
    cursor: pointer;
    width: 250px;
    height: 32px;
    display: flex;
    align-items: center;
    border-radius: 10px;
    background: #E1E6F0;
    padding: 0px 10px;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    margin-left: 20px;
}

.store_nav_search_box span {
    font-size: 17px;
    margin-right: 7px;
}

.create_new {
    border: none;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    background: #E1E6F0;
    color: #78859D;
    margin-left: 10px;
}

.create_new span {
    font-size: 20px;
}

.workspace_page_navbar_right {
    display: flex;
    align-items: center;
}

.members {
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    background: #fff;
    padding: 5px 10px;
    padding-left: 20px;
    border-radius: 100px;
    margin-right: 10px;
}
.members:hover{
    background: #E1E6F0;
}

.member {
    width: 30px;
    height: 30px;
    border-radius: 100px;
    border: 2px solid #FFF;
    background: #FF6E05;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #FFF;
    font-size: 15px;
    font-weight: 400;
    margin-left: -10px;
}

.invite_btn {
    border: none;
    cursor: pointer;
    width: 70px;
    height: 32px;
    border-radius: 4px;
    background: #2698F0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #FFF;
    font-size: 15px;
    font-weight: 500;
    margin-right: 10px;
}

.mail span {
    font-size: 25px;
    color: #78859D;
    margin-right: 10px;
}

    .close_btn {
        padding: 2px;
        margin-right:10px;
        color: #78859D;
        cursor: pointer;
        transition: all .2s ease-in-out;
    }
    .close_btn:active{
        color: #636e81;
        transform: scale(0.99);
    }
    
    .close_btn span {
        font-size: 25px;
    }

    
.store_nav_profile_box {
    position: relative;
    z-index: 0;
}

.profile_icon {
    width: 30px;
    height: 30px;
    border-radius: 100px;
    margin-right: 10px;
    background: #63BEFF;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    font-weight: 600;
    color: white;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.profile_icon:active{
    background: #44a3e7;
    transform: scale(0.99);
}


.request {
    display: block;
    text-align: center;
    margin-top: 30vh;
}

.request_txt {
    font-size: 15px;
    margin-bottom: 20px;
}

.request button {
    border: none;
    padding: 10px 15px;
    background: #1565C0;
    color: white;
}

.request .workspace_page_profile{
    display: block;
    margin-bottom: 15px;
}
.request .workspace_page_profile_txt {
    display: block;
    text-align: center;
    width: 100%;
}

.request .workspace_page_profile_icon {
    margin:10px auto
}




</style>
    <body>

    
    <?php


$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        $isadmin = false;
        $ismember = false;
        $isobserver = false;
        $request = false;
        $request_waiting = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 

        $request_waiting_data  = explode(",", $row['pendings']);

        if (in_array($id, $request_waiting_data)) {
            $request_waiting = true;
        } 


        if($isadmin==false&&$ismember==false&&$isobserver==false){
            $request = true;

            echo '<div class="request">
            
            
            <div class="workspace_page_profile">
                <div style="background:'.$row['color'].'" class="workspace_page_profile_icon">'.$row['name'][0].'</div>
                <div class="workspace_page_profile_txt">
                    <div class="workspace_page_profile_name">'.$row['name'].'</div>
                    <div class="workspace_page_profile_type">'.$row['type'].'</div>
                </div>
            </div>

            <div class="request_txt">Request access to '.$row['name'].'</div>';
            if($request_waiting==true){
                echo '<button>Wait for confirmation</button>';
            }else{
                echo '<button onclick="workspace_request()">Request access</button>';
            }

            echo '</div>';
        }
        if($request==false){
        echo '<div class="workspace_page">
        <div class="workspace_page_left">
            <div class="workspace_page_profile">
                <div style="background:'.$row['color'].'" class="workspace_page_profile_icon">'.$row['name'][0].'</div>
                <div class="workspace_page_profile_txt">
                    <div class="workspace_page_profile_name">'.$row['name'].'</div>
                    <div class="workspace_page_profile_type">'.$row['type'].'</div>
                </div>
            </div>
            <button onclick="workspace_links(this,'."'".'Pages'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">article</span>Pages</button>
            <button onclick="workspace_links(this,'."'".'Starred'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">grade</span>Starred</button>
            <button onclick="workspace_links(this,'."'".'Chat'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">grade</span>Chat</button>
            <button onclick="workspace_links(this,'."'".'Files'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">grade</span>Files</button>
            ';

            if(!$isobserver){
                echo '
                <button onclick="workspace_links(this,'."'".'Members'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">groups</span>Members</button>
                <button onclick="workspace_links(this,'."'".'Settings'."'".','."'".$url."'".')" class="workspace_page_link"><span class="material-icons-outlined">settings</span>Settings</button>
                ';
            }

            echo '
        </div>
        <div class="workspace_page_right">
            <div class="workspace_page_navbar">
                <div class="workspace_page_navbar_left">
                    <button onclick="search()" class="store_nav_search_box"><span class="material-icons">search</span>Search</button>
                    <button class="create_new"><span class="material-icons">add</span></button>
                </div>
                <div class="workspace_page_navbar_right">
                    <button onclick="invite('."'".$row['url']."'".')" class="members">
                    ';
                    
                    
                    $admin = $row['admin'];
                    $admin_counter = 0;
                    $members_counter = 0;
                    $observers_counter = 0;
                    $show_extra = false;
                    if(!empty($admin)){
                        $admin_ids = explode(',', $admin);
                        foreach ($admin_ids as $admin_id) {
                            if ($admin_counter >= 2) {
                                $show_extra = true;
                                break;
                            }

                            $user_sql = "SELECT * FROM users WHERE id=$admin_id";
                            $user_result = $conn->query($user_sql);

                            if ($user_result->num_rows > 0) {
                            // output data of each row
                            while($user_row = $user_result->fetch_assoc()) {
                                echo '<div class="member">'.$user_row['name'][0].'</div>';
                            }
                            } else {
                            // echo "0 results";
                            }
                            $admin_counter++;
                        }
                    }

                    
                    $members = $row['members'];
                    if(!empty($members)){
                        $members_ids = explode(',', $members);
                        
                        foreach ($members_ids as $members_id) {
                            if ($members_counter >= 2) {
                                $show_extra = true;
                                break;
                            }
                            $user_sql = "SELECT * FROM users WHERE id=$members_id";
                            $user_result = $conn->query($user_sql);

                            if ($user_result->num_rows > 0) {
                            // output data of each row
                            while($user_row = $user_result->fetch_assoc()) {
                                echo '<div class="member">'.$user_row['name'][0].'</div>';
                            }
                            } else {
                            // echo "0 results";
                            }

                            $members_counter++;
                        }
                    }


                    $observers = $row['observers'];
                    if(!empty($observers)){
                        $observers_ids = explode(',', $observers);
                        
                        foreach ($observers_ids as $observers_id) {
                            if ($observers_counter >= 2) {
                                $show_extra = true;
                                break;
                            }
                            $user_sql = "SELECT * FROM users WHERE id=$observers_id";
                            $user_result = $conn->query($user_sql);

                            if ($user_result->num_rows > 0) {
                            // output data of each row
                            while($user_row = $user_result->fetch_assoc()) {
                                echo '<div class="member">'.$user_row['name'][0].'</div>';
                            }
                            } else {
                            // echo "0 results";
                            }

                            $observers_counter++;
                        }
                    }


                    if($show_extra){
                        echo '<div class="member">'.$admin_counter+$members_counter+$observers_counter.'</div>';
                    }

                        echo '
                    </button>
                    ';

                    
            if(!$isobserver){
                echo '
                <button onclick="invite('."'".$row['url']."'".')" class="invite_btn">Invite</button>
                ';
            }
                    echo '
                    <div class="mail"><span class="material-icons">alternate_email</span></div>
                   <div onclick="close_open_workspace()" class="close_btn"><span class="material-icons">cancel</span></div>

                   <div id="store_nav_profile_box" class="store_nav_profile_box">
                    <div onclick="profile('."'".'dhirajkadam@gmail.com'."'".','."'".'Dhiraj Kadam'."'".','."'".'dhirajkadam27'."'".')" id="profile_icon_color" class="profile_icon">D</div>
                   </div>

                </div>
            </div>
            <div id="workspace_page_content"></div>
        </div>
    </div>';
        }
    }
} else {
    // header("Location: /street/create-your-workspace.html");
    // exit;
}


?>
       

        <script>
            $('.workspace_page_link')[0].click();

            function workspace_request(){
                $.ajax({
        url: "/api/street/workspace/request.php",
        type: "GET",
        data: {
            userid: <?php echo $id;?>,
            url: "<?php echo $url;?>"
        },
        dataType: 'text',
        success: function(response) {
            console.log(response);
            location.reload();
        },
        error: function(xhr, status, error) {
            console.log('Unable to connect the server');
            oops("Unable to connect the server");
        }
    });
            }
        </script>
    </body>
</html>