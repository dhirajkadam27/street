<?php
$url = $_GET['url'];
// Connect to the database (you should replace with your credentials)
$conn = mysqli_connect("localhost", "root", "", "clapstart");

$query = "SELECT * FROM chats WHERE workspace_id='$url' ORDER BY date DESC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo $row['username'] . ": " . $row['content'] . "<br>";
}

mysqli_close($conn);
?>