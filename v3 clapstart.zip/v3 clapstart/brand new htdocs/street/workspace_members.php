<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isadmin = false;
        $ismember = false;
        $isobserver = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 
    }

}
?>
<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}

.workspace_members {
    margin-top: 20px;
}

.workspace_members_subtitle {
    font-size: 15px;
    font-weight: 400;
    color: #78859D;
    margin-bottom: 20px;
}

.workspace_members_list {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}

.workspace_members_list_left {
    display: flex;
    align-items: center;
}

.workspace_members_icon {
    width: 40px;
    height: 40px;
    background: #FF6E05;
    border-radius: 100px;
    color: #FFF;
    font-size: 15px;
    font-weight: 400;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}

.workspace_members_name {
    color: #001930;
    font-size: 13px;
    font-weight: 500;
}

.workspace_members_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
    margin-top: 2px;
}

.workspace_members_list_right {
    display: flex;
    align-items: center;
}

.workspace_members_list_right select {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
}

.workspace_members_btn {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
    display: flex;
    align-items: center;
    margin-left: 15px;
    width: 100px;
    cursor: pointer;
}

.workspace_members_btn span {
    font-size: 15px;
    margin-right: 5px;
}




</style>
    <body>

        <div class="workspace_members">
            <div class="workspace_members_subtitle">Workspace members can view and join all Workspace visible boards and create new boards in the Workspace.</div>
            <div class="workspace_members_lists">


            <?php

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        
        $admin = $row['admin'];
        if(!empty($admin)){

            $admin_ids = explode(',', $admin);
            $admin_count = count($admin_ids);
            foreach ($admin_ids as $admin_id) {

                $user_sql = "SELECT * FROM users WHERE id=$admin_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="workspace_members_list">
                    <div class="workspace_members_list_left">
                        <div class="workspace_members_icon">'.$user_row['name'][0].'</div>
                        <div class="workspace_members_txt">
                            <div class="workspace_members_name">'.$user_row['name'].'</div>
                            <div class="workspace_members_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="workspace_members_list_right">
                    ';

              

                        if($admin_count<=1){
                            echo '
                                <select disabled>';
                        }else{
                            echo '
                            <select onchange="change_workspace_invition(this,'."'Admin'".','."'".$admin_id."'".','."'".$url."'".')">';
                        }
                

                        echo '
                            <option selected value="Admin">Admin</option>
                            <option value="Member">Member</option>
                            <option value="Observer">Observer</option>
                        </select>
                        ';

                            

                            if($admin_count<=1){
                                echo '
                                <button disabled class="workspace_members_btn"><span class="material-icons-outlined">close</span>Leave</button>
                                ';
                            }else{
                                echo '
                                <button onclick="remove_workspace_invition('."'".'Admin'."'".','."'".$admin_id."'".','."'".$url."'".')" class="workspace_members_btn"><span class="material-icons-outlined">close</span>Leave</button>
                                ';
                            }

    
                            echo ' </div>
                            </div>';
                }
                } else {
                // echo "0 results";
                }
            }

        }
         

        
        $members = $row['members'];
        if(!empty($members)){
            $members_ids = explode(',', $members);
            
            foreach ($members_ids as $members_id) {
                $user_sql = "SELECT * FROM users WHERE id=$members_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="workspace_members_list">
                    <div class="workspace_members_list_left">
                        <div class="workspace_members_icon">'.$user_row['name'][0].'</div>
                        <div class="workspace_members_txt">
                            <div class="workspace_members_name">'.$user_row['name'].'</div>
                            <div class="workspace_members_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="workspace_members_list_right">
                    <select onchange="change_workspace_invition(this,'."'Member'".','."'".$members_id."'".','."'".$url."'".')">
                            <option value="Admin">Admin</option>
                            <option selected value="Member">Member</option>
                            <option value="Observer">Observer</option>
                        </select>
                        <button onclick="remove_workspace_invition('."'".'Member'."'".','."'".$members_id."'".','."'".$url."'".')" class="workspace_members_btn"><span class="material-icons-outlined">close</span>Remove</button>
                    </div>
                </div>';
                }
                } else {
                // echo "0 results";
                }

            }
        }


        $observers = $row['observers'];
        if(!empty($observers)){
            $observers_ids = explode(',', $observers);
            
            foreach ($observers_ids as $observers_id) {
                $user_sql = "SELECT * FROM users WHERE id=$observers_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="workspace_members_list">
                    <div class="workspace_members_list_left">
                        <div class="workspace_members_icon">'.$user_row['name'][0].'</div>
                        <div class="workspace_members_txt">
                            <div class="workspace_members_name">'.$user_row['name'].'</div>
                            <div class="workspace_members_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="workspace_members_list_right">
                    <select onchange="change_workspace_invition(this,'."'Observer'".','."'".$observers_id."'".','."'".$url."'".')">
                            <option value="Admin">Admin</option>
                            <option value="Member">Member</option>
                            <option selected value="Observer">Observer</option>
                        </select>
                       <button onclick="remove_workspace_invition('."'".'Observer'."'".','."'".$observers_id."'".','."'".$url."'".')" class="workspace_members_btn"><span class="material-icons-outlined">close</span>Remove</button>
                    </div>
                </div>';
                }
                } else {
                // echo "0 results";
                }

            }
        }

    }
}


                    ?>


            </div>
        </div>
        
    </body>
</html>