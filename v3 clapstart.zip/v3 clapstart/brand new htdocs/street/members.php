<?php
$url = $_GET['url'];
?>
<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.members_screen {
    padding: 15px;
    display: block;
}

.members_title {
    font-size: 20px;
    font-weight: 600;
    color: #001930;
    margin-bottom: 20px;
}

.members_tabs {
    display: flex;
    align-items: center;
}

.member_tab {
    padding: 10px 10px;
    border-radius: 5px;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    margin: 0px 5px;
    cursor: pointer;
    font-family: Inter;
    border:none
}
.member_tab_active{
    background: #2698F0;
    color: white;
}



</style>
    <body>

        <div class="members_screen">
            <div class="members_title">Members</div>
            <div class="members_tabs">
                <button onclick="workspace_tabs(this,'Workspace members','<?php echo $url?>')" class="member_tab">Workspace members</button>
                <button onclick="workspace_tabs(this,'Guests','<?php echo $url?>')" class="member_tab">Guests</button>
                <button onclick="workspace_tabs(this,'Pending','<?php echo $url?>')" class="member_tab">Pending</button>
            </div>
            <div id="members_content"></div>
        </div>

        <script>
            $('.member_tab')[0].click();
        </script>
        
    </body>
</html>