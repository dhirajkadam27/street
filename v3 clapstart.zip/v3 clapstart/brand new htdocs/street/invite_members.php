<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isadmin = false;
        $ismember = false;
        $isobserver = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 
    }

}
?>

<style>
    

    .invite_members {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: #0000004a;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .invite_members_popup {
        width: 570px;
        background: white;
        border-radius: 10px;
        padding: 20px;
        position: relative;
        animation: popup .5s;
        transform: scale(0,0) translate(0, -200px);
        animation-fill-mode: forwards;
    }
    .invite_members_popup .close_btn {
        position: absolute;
        right: 5px;
        top: 10px;
    }
    
    
    
    .invite_members_title {
        color: #001930;
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 10px;
    }
    
    .invite_members_line {
        display: flex;
        align-items: center;
        margin-bottom: 25px;
    }
    
    .inputsrc{
        width:60%;
        position:relative;
        margin-right: 10px;
    }
    .inputsrc input:nth-child(2){
        display: none;
    }
    
    .invite_members_popup input {
        width: 100%;
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
    }
    .invite_members_popup input::placeholder{
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
    }
    
    .invite_members_popup select {
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
    }
    
    .invite_members_btn {
        padding: 10px 10px;
        border: none;
        background: #2698F0;
        color: white;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-left: 10px;
    }
    
    .link_icon {
        padding: 10px 10px;
        border: none;
        background: #E1E6F0;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        border-radius: 5px;
        margin-right: 10px;
    }
    
    .link_icon span {
        font-size: 17px;
    }
    .invite_members_list {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    
    .invite_members_list_left {
        display: flex;
        align-items: center;
    }
    
    .invite_members_list_icon {
        width: 35px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 100px;
        border: 1px solid #FFF;
        background: #FF6E05;
        color: #FFF;
        font-size: 15px;
        font-weight: 400;
        margin-right: 10px;
    }
    
    .invite_members_list_name {
        color: #001930;
        font-size: 13px;
        font-weight: 600;
    }
    
    .invite_members_list_username {
        color: #78859D;
        font-size: 10px;
        font-weight: 500;
        margin-top: 3px;
    }
    
    .invite_members_list select {
        padding: 5px 10px;
    }
    .invite_members_list select:disabled {
        cursor: not-allowed;
    }
    .invite_members_list button:disabled {
        cursor: not-allowed;
    }

    .invite_members_list_right {
    display: flex;
}

.invite_members_list_btn {
    padding: 10px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-left: 15px;
}
    


#email_src {
    position: absolute;
    top: 40px;
    background: white;
    width: 100%;
    box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.20);
    border: 1px solid #E1E6F0;
    border-radius: 10px;
}

.email_box {
    display: flex;
    align-items: center;
    margin: 5px;
    padding: 5px;
    background: #fff;
    border-radius: 10px;
}
.email_box:hover{
    background: #E1E6F0;
}

.email_icon {width: 35px;height: 35px;display: flex;align-items: center;justify-content: center;border-radius: 100px;border: 1px solid #FFF;background: #FF6E05;color: #FFF;font-size: 15px;font-weight: 400;margin-right: 10px;}

.email_name {
    color: #001930;
    font-size: 13px;
    font-weight: 600;
}

.email_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
    margin-top: 3px;
}

    @keyframes popup {
        100% {
            transform: scale(1,1) translate(0, 0);
            transition: all 300ms cubic-bezier(0.645, 0.045, 0.355, 1.000); 
        }
    }
    </style>
    <div class="invite_members">
            <div class="invite_members_popup">
                <div onclick="close_invite()" class="close_btn"><span class="material-icons">cancel</span></div>
                <div class="invite_members_title">Invite Members</div>

                <?php
                if(!$isobserver){
                    echo '<div class="invite_members_line">
                    <div class="inputsrc">
                    <input type="text" onkeyup="search_users()" name="sdsd" id="inviteEmail" placeholder="Email address or username" autocomplete="off">
                    <input type="text" id="inviteid" placeholder="Email address or username">
                    <div id="email_src">
                        
                    </div>
                    </div>
                    <input type="hidden" id="find_found" name="find_found" value="false"> 
                    <select id="invitetype">
                        <option>Members</option>
                        <option>Observer</option>
                    </select>
                    <div onclick="invite_workspace_api('."'".$url."'".')" class="invite_members_btn">Invite</div>
                </div>
                
            ';
                }
                ?>
                
                
                <div class="invite_members_lists">
                <?php

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        
        $admin = $row['admin'];
        if(!empty($admin)){

            $admin_ids = explode(',', $admin);
            $admin_count = count($admin_ids);
            foreach ($admin_ids as $admin_id) {

                $user_sql = "SELECT * FROM users WHERE id=$admin_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="invite_members_list">
                    <div class="invite_members_list_left">
                        <div class="invite_members_list_icon">'.$user_row['name'][0].'</div>
                        <div class="invite_members_list_txt">
                            <div class="invite_members_list_name">'.$user_row['name'].'</div>
                            <div class="invite_members_list_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="invite_members_list_right">
                    ';

                    if($isobserver){
                        echo '
                            <select disabled>';
                    }else{

                        if($admin_count<=1){
                            echo '
                                <select disabled>';
                        }else{
                            echo '
                            <select onchange="change_workspace_invition(this,'."'Admin'".','."'".$admin_id."'".','."'".$url."'".')">';
                        }
                    }

                        echo '
                            <option selected value="Admin">Admin</option>
                            <option value="Member">Member</option>
                            <option value="Observer">Observer</option>
                        </select>
                        ';

                        if(!$isobserver){
                            

                            if($admin_count<=1){
                                echo '<button disabled class="invite_members_list_btn">Leave</button>
                                ';
                            }else{
                                echo '<button onclick="remove_workspace_invition('."'".'Admin'."'".','."'".$admin_id."'".','."'".$url."'".')" class="invite_members_list_btn">Leave</button>
                                ';
                            }
                        }
    
                            echo '</div>
                </div>';
                }
                } else {
                // echo "0 results";
                }
            }

        }
         

        
        $members = $row['members'];
        if(!empty($members)){
            $members_ids = explode(',', $members);
            
            foreach ($members_ids as $members_id) {
                $user_sql = "SELECT * FROM users WHERE id=$members_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="invite_members_list">
                    <div class="invite_members_list_left">
                        <div class="invite_members_list_icon">'.$user_row['name'][0].'</div>
                        <div class="invite_members_list_txt">
                            <div class="invite_members_list_name">'.$user_row['name'].'</div>
                            <div class="invite_members_list_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="invite_members_list_right">
                    ';

                    if($isobserver){
                        echo '
                            <select disabled>';
                    }else{
                    echo '
                    <select onchange="change_workspace_invition(this,'."'Member'".','."'".$members_id."'".','."'".$url."'".')">';
                    }

                        echo '
                            <option value="Admin">Admin</option>
                            <option selected value="Member">Member</option>
                            <option value="Observer">Observer</option>
                        </select>
                        ';

                        if(!$isobserver){
                        echo '     <button onclick="remove_workspace_invition('."'".'Member'."'".','."'".$members_id."'".','."'".$url."'".')" class="invite_members_list_btn">Remove</button>
                        ';
                        }
    
                            echo '

                    </div>
                </div>';
                }
                } else {
                // echo "0 results";
                }

            }
        }


        $observers = $row['observers'];
        if(!empty($observers)){
            $observers_ids = explode(',', $observers);
            
            foreach ($observers_ids as $observers_id) {
                $user_sql = "SELECT * FROM users WHERE id=$observers_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="invite_members_list">
                    <div class="invite_members_list_left">
                        <div class="invite_members_list_icon">'.$user_row['name'][0].'</div>
                        <div class="invite_members_list_txt">
                            <div class="invite_members_list_name">'.$user_row['name'].'</div>
                            <div class="invite_members_list_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="invite_members_list_right">
                    ';

                    if($isobserver){
                        echo '
                            <select disabled>';
                    }else{
                    echo '
                    <select onchange="change_workspace_invition(this,'."'Observer'".','."'".$observers_id."'".','."'".$url."'".')">';
                    }

                        echo '
                            <option value="Admin">Admin</option>
                            <option value="Member">Member</option>
                            <option selected value="Observer">Observer</option>
                        </select>

                        ';

                        if(!$isobserver){
                        echo '     <button onclick="remove_workspace_invition('."'".'Observer'."'".','."'".$observers_id."'".','."'".$url."'".')" class="invite_members_list_btn">Remove</button>
                        ';
                        }
    
                            echo '

                    </div>
                </div>';
                }
                } else {
                // echo "0 results";
                }

            }
        }

    }
}


                    ?>
                    
                 
                </div>
                
            </div>
        </div>

   

