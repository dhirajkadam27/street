
<?php
$url = $_GET['url'];
?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.settings_screen {
    padding: 15px;
    display: block;
}

.settings_title {
    font-size: 20px;
    font-weight: 600;
    color: #001930;
    margin-bottom: 20px;
}

.settings_tabs {
    display: flex;
    align-items: center;
}

.settings_tab {
    font-family: Inter;
    border:none;
    cursor: pointer;
    padding: 10px 10px;
    border-radius: 5px;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    margin: 0px 5px;
}
.settings_tab_active{
    background: #2698F0;
    color: white;
}


.popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 300px;
            padding: 20px;
            background-color: #f1f1f1;
            border: 1px solid #ddd;
        }


</style>
    <body>

        <div class="settings_screen">
            <div class="settings_title">Files</div>
           
        </div>
        
        
    

    <button onclick="openPopup()" class="upload">Upload File</button>


    <div id="filePopup" class="popup">
        <h3>Upload a File</h3>
        <form id="fileForm" method="post" enctype="multipart/form-data">
            <input type="text" name="file_name" placeholder="File Name"><br>
            <input type="file" name="file" accept=".txt, .pdf, .doc"><br>
            <input type="hidden" name="url" value="<?php echo $url;?>"><br>
            <input type="button" value="Upload" onclick="uploadFile()">
        </form>
        <br>
        <input type="button" value="Close" onclick="closePopup()">
    </div>

    <script>
        function openPopup() {
            var popup = document.getElementById("filePopup");
            popup.style.display = "block";
        }
    
        function uploadFile() {
            var form = document.getElementById("fileForm");
            var formData = new FormData(form);
    
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "file.api.php", true);
    
            xhr.onload = function () {
                if (xhr.status === 200) {
                    alert("File uploaded successfully!");
                    closePopup();
                } else {
                    alert("File upload failed. Please try again.");
                }
            };
    
            xhr.send(formData);
        }
    
        function closePopup() {
            var popup = document.getElementById("filePopup");
            popup.style.display = "none";
        }
    </script>
    



    <table>
        <tr>
          <th>Username</th>
          <th>File name</th>
        
            <th>Preview</th>
            <th>Download</th>
          
        </tr>
        
    <?php
// Replace these with your MySQL database credentials
$host = "localhost";
$username = "root";
$password = "";
$database = "clapstart";

// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Retrieve file information from the database
$query = "SELECT * FROM file WHERE workspace_url='$url'";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $username = $row['username'];
        $file_name = $row['filename'];

        echo "<tr>";
        echo "<td>$username</td>";
        echo "<td>$file_name</td>";
            echo "<td><a href='view_file.php?file_name=$file_name' target='_blank'>Preview</a></td>";
            echo "<td><a href='download_file.php?file_name=$file_name' target='_blank'>Download</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>No files uploaded.</td></tr>";
}

// Close the database connection
mysqli_close($connection);
?>
        <!-- Add more rows as needed -->
      </table>

     

    </body>
</html>