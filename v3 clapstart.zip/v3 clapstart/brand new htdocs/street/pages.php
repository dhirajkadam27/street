<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isadmin = false;
        $ismember = false;
        $isobserver = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 
    }

}
?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.pages {
    padding: 15px;
}

.pages_titles {
    font-size: 20px;
    font-weight: 600;
    color: #001930;
    margin-bottom: 20px;
}

.pages_box {
    display: flex;
    flex-wrap: wrap;
}

.create_page {
    width: 150px;
    height: 200px;
    background: #4E85F0;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    border-radius: 10px;
    margin: 10px;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.create_page:hover{   
    transform: scale(0.99);
}
.create_page:active{
    background: #3f79ed;
    transform: scale(0.98);
}

.create_page span {width: 100%;text-align: center;font-size: 20px;color: white;height: 20px;}

.create_page_txt {
    width: 100%;
    text-align: center;
    font-size: 15px;
    font-weight: 500;
    color: white;
    height: 20px;
}

.page_box {
    width: 150px;
    height: 200px;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    border-radius: 10px;
    box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.20);
    border: 1px solid #E1E6F0;
    margin: 10px;
    cursor: pointer;
    transition: all .2s ease-in-out;
}
.page_box:hover{   
    transform: scale(0.99);
}
.page_box:active{
    background: #f7f9fb;
    transform: scale(0.98);
}

.page_icon {
    width: 100%;
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.page_icon img {
    width: 60px;
    height: 60px;
}

.page_box_bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
}

.page_name {
    width: 70%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 12px;
    font-weight: 500;
    color: #001930;
    padding: 0px 5%;
}

.page_starred span {
    color: #001930;
    font-size: 17px;
}

.page_starred {
    width: 20%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.span_starred{
    color: #4E85F0 !important;
}



</style>
    <body>

        <div class="pages">
            <div class="pages_titles">Pages</div>
            <div class="pages_box">
                <?php
                if(!$isobserver){
                    echo '<div onclick="create_page_screen('."'".$url."'".')" class="create_page">
                    <div class="create_page_txt"></div>
                    <span class="material-icons">add</span>
                    <div class="create_page_txt">Create new</div>
                </div>';
                }
                ?>

<?php

$sql = "SELECT * FROM projects 
WHERE workspace_url = '$url' 
AND ((type != 'private') OR (type = 'Private' AND FIND_IN_SET('$id', members) OR FIND_IN_SET('$id', admin)))";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isstarred = false;
        $isstarreddata = explode(",", $row['starred']);

        if (in_array($id, $isstarreddata)) {
            $isstarred = true;
        } 

        echo '<div class="page_box">
        <div onclick="window.location.href='."'./p/?url=".$row['url']."'".'" class="page_icon">
            <img src="/assets/img/street.svg">
        </div>
        <div class="page_box_bottom">
            <div class="page_name">'.$row['name'].'</div>
            <div onclick="starred(this,'."'".$row['url']."'".','."'".$id."'".','."'page'".')" class="page_starred">
            ';
            if($isstarred){
                echo '
                <span class="material-icons-outlined span_starred">star</span>';
            }else{
                echo '
                <span class="material-icons">star_border</span>';
            }
            echo '
            </div>
        </div>
    </div>
    ';
    }
}

?>


            </div>
        </div>
        
    </body>
</html>