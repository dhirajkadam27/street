<?php
session_start();
// Replace these with your MySQL database credentials
$host = "localhost";
$username = "root";
$password = "";
$database = "clapstart";

// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get file name and file data from the form
$file_name = $_POST['file_name'];
$usn = $_SESSION["username"];
$wsurl = $_POST["url"];
if ($_FILES['file']['error'] === 0) {
    $file_data = file_get_contents($_FILES['file']['tmp_name']);
} else {
    die("File upload failed: " . $_FILES['file']['error']);
}

// Insert file information into the database
$query = "INSERT INTO file (workspace_url,username,filename, file) VALUES ('$wsurl','$usn','$file_name', ?)";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $file_data);
if (mysqli_stmt_execute($stmt)) {
    echo "File uploaded and inserted into the database successfully.";
} else {
    echo "File upload and insertion failed: " . mysqli_error($connection);
}

// Close the database connection
mysqli_close($connection);
?>
