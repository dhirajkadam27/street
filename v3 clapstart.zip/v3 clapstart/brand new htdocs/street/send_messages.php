<?php
   session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database (you should replace with your credentials)
    $conn = mysqli_connect("localhost", "root", "", "clapstart");

    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $username = $_SESSION["username"]; // Replace with the actual username or user identification method
    $workspace_url = $_POST['url']; // Replace with the actual username or user identification method

    $query = "INSERT INTO chats (workspace_id, username, content) VALUES ('$workspace_url', '$username', '$message')";
    mysqli_query($conn, $query);

    mysqli_close($conn);
}
