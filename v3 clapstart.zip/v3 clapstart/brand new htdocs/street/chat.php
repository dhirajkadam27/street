
<?php
$url = $_GET['url'];
?>

<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.settings_screen {
    padding: 15px;
    display: block;
}

.settings_title {
    font-size: 20px;
    font-weight: 600;
    color: #001930;
    margin-bottom: 20px;
}

.settings_tabs {
    display: flex;
    align-items: center;
}

.settings_tab {
    font-family: Inter;
    border:none;
    cursor: pointer;
    padding: 10px 10px;
    border-radius: 5px;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    margin: 0px 5px;
}
.settings_tab_active{
    background: #2698F0;
    color: white;
}



</style>
    <body>

        <div class="settings_screen">
            <div class="settings_title">Chat</div>
           
            <div id="chat-box">
        <!-- Chat messages will be displayed here -->
    </div>
    <form id="chat-form">
        <input type="text" id="message" placeholder="Type your message">
        <input type="hidden" id="url" value="<?php echo $url; ?>">
        <input type="submit" value="Send">
    </form>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
    function loadChat() {
        var url = $('#url').val();
        $.ajax({
            url: 'load_messages.php',
            type: 'GET',
            data: { url: url },
            success: function(response) {
                $('#chat-box').html(response);
            }
        });
    }

    loadChat(); // Load chat messages initially

    $('#chat-form').submit(function(e) {
        e.preventDefault();
        var message = $('#message').val();
        var url = $('#url').val();

        $.ajax({
            url: 'send_messages.php',
            type: 'POST',
            data: { message: message,url: url },
            success: function() {
                loadChat(); // Reload chat messages after sending
                $('#message').val(''); // Clear the input field
            }
        });
    });
});

    </script>


        </div>
        
        
     

    </body>
</html>