<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isadmin = false;
        $ismember = false;
        $isobserver = false;

        $isadmindata = explode(",", $row['admin']);

        if (in_array($id, $isadmindata)) {
            $isadmin = true;
        } 

        
        $ismemberdata = explode(",", $row['members']);

        if (in_array($id, $ismemberdata)) {
            $ismember = true;
        } 
        
        $isobserverdata = explode(",", $row['observers']);

        if (in_array($id, $isobserverdata)) {
            $isobserver = true;
        } 
    }

}
?>
<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}

.workspace_pending {
    margin-top: 20px;
}

.workspace_pending_subtitle {
    font-size: 15px;
    font-weight: 400;
    color: #78859D;
    margin-bottom: 20px;
}

.workspace_pending_list {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
}

.workspace_pending_list_left {
    display: flex;
    align-items: center;
}

.workspace_pending_icon {
    width: 40px;
    height: 40px;
    background: #FF6E05;
    border-radius: 100px;
    color: #FFF;
    font-size: 15px;
    font-weight: 400;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}

.workspace_pending_name {
    color: #001930;
    font-size: 13px;
    font-weight: 500;
}

.workspace_pending_username {
    color: #78859D;
    font-size: 10px;
    font-weight: 500;
    margin-top: 2px;
}

.workspace_pending_list_right {
    display: flex;
    align-items: center;
}

.workspace_pending_list_right select {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
}

.workspace_pending_btn {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-top: 20px;
    display: flex;
    align-items: center;
    margin-left: 15px;
    cursor: pointer;
}

.workspace_pending_btn:nth-child(2){
    background: #19A22F;
    color: white;
}
.workspace_pending_btn span {
    font-size: 15px;
    margin-right: 5px;
}




</style>
    <body>

        <div class="workspace_pending">
            <div class="workspace_pending_subtitle">Workspace pending can view and join all Workspace visible boards and create new boards in the Workspace.</div>
            <div class="workspace_pending_lists">

            <?php

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        $pendings = $row['pendings'];
        if(!empty($pendings)){
            $pendings_ids = explode(',', $pendings);
            
            foreach ($pendings_ids as $pendings_id) {
                $user_sql = "SELECT * FROM users WHERE id=$pendings_id";
                $user_result = $conn->query($user_sql);

                if ($user_result->num_rows > 0) {
                // output data of each row
                while($user_row = $user_result->fetch_assoc()) {
                    echo '<div class="workspace_pending_list">
                    <div class="workspace_pending_list_left">
                        <div class="workspace_pending_icon">'.$user_row['name'][0].'</div>
                        <div class="workspace_pending_txt">
                            <div class="workspace_pending_name">'.$user_row['name'].'</div>
                            <div class="workspace_pending_username">@'.$user_row['username'].'</div>
                        </div>
                    </div>
                    <div class="workspace_pending_list_right">
                        <button onclick="pending_workspace_invition('."'".$pendings_id."'".','."'".$url."'".','."'r'".')" class="workspace_pending_btn"><span class="material-icons-outlined">close</span>Cancel</button>
                        <button onclick="pending_workspace_invition('."'".$pendings_id."'".','."'".$url."'".','."'a'".')" class="workspace_pending_btn"><span class="material-icons-outlined">done</span>Accept</button>
                    </div>
                </div>';
                }
                } else {
                // echo "0 results";
                }

            }
        }



    }
}


                    ?>


            </div>
        </div>
        
    </body>
</html>