<?php
include '../api/config.php';
ob_start();

if(!isset($_SESSION['email'])){
    header("Location: /");
    ob_end_flush();
}else{
    $email = $_SESSION['email'];
    $name = $_SESSION['name'];
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $color = $_SESSION['color'];
    $url = $_GET['url'];
}

                    
$sql = "SELECT * FROM workspaces WHERE url='$url'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $name = $row['name'];
        $url = $row['url'];
        $type = $row['type'];
        $color = $row['color'];
    }

}
?>
<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}


.workspace_setting_edit {
    width: 500px;
    margin-top: 50px;
}

            .workspace_setting_edit_workspace_setting_img {
        position: relative;
    font-family: Inter;
        border:none;
        background:none;
    }
    
    
    .workspace_setting_edit_workspace_setting_icon {
        margin: 10px;
        width: 50px;
        height: 50px;
        border-radius: 10px;
        background: #63BEFF;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #FFF;
        font-size: 20px;
        font-weight: 600;
        transition: all .2s ease-in-out;
        cursor: pointer;
    }
    .workspace_setting_edit_workspace_setting_icon:active{
        background: #3596dc;
                transform: scale(0.99);
    }
    .color_btn {
        width: 30px;
        height: 30px;
        border-radius: 6px;
        margin: 5px;
    }
    
    .workspace_setting_edit input {
        border-radius: 7px;
        border: 1px solid #C5CEDF;
        background: #FFF;
        width: 95%;
        height: 30px;
        margin: 10px 2.5%;
        padding: 10px;
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
        outline-color:#1c83d1
    }
    
    .workspace_setting_edit input::placeholder {
        color: #78859D;
        font-size: 13px;
        font-weight: 500;
        font-family: Inter;
    }
    .workspace_setting_edit select {
    border-radius: 7px;
    border: 1px solid #C5CEDF;
    background: #FFF;
    width: 95%;
    margin: 10px 2.5%;
    padding: 10px;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    outline-color: #1c83d1;
}
    
    .workspace_setting_edit_workspace_setting_btn {
    font-family: Inter;
        border-radius: 5px;
        background: #2698F0;
        width: 100px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        margin: 10px;
        transition: all .2s ease-in-out;
        cursor: pointer;
        border:none
    }
    .workspace_setting_edit_workspace_setting_btn:active{
        background: #1c83d1;
                transform: scale(0.99);
    }

</style>
    <body>

        <div class="workspace_setting_edit">
            <button class="workspace_setting_edit_workspace_setting_img">
                <div onclick="workspace_color_label()" id="workspace_icon_color" style="background: <?php echo $color?>" class="workspace_setting_edit_workspace_setting_icon"><?php echo $name[0]?></div>
            </button>
            <input type="text" id="update_workspace_setting_name" placeholder="Full Name" value="<?php echo $name?>">
            <input type="text" id="update_workspace_setting_workspace_settingname" placeholder="@workspace_settingname" value="<?php echo $url?>">    
            <select id="workspace_type" value="<?php echo $type?>">
                <option>Public</option>
                <option>Private</option>
            </select>
            <button onclick="workspace_setting_update('<?php echo $url?>')" class="workspace_setting_edit_workspace_setting_btn">Save</button>
    
        </div>
    

    </body>
</html>