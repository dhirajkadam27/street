<html>
    <head>
        <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
       
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="/assets/js/clapstart.js"></script>
        <script src="/assets/js/street.js"></script>
        <style>
            body {
    margin: 0;
    padding: 0;
    font-family: Inter;
}



.workspace_premissions_edit_title {
    font-size: 17px;
    font-weight: 600;
    color: #001930;
    margin-bottom: 10px;
    margin-top: 30px;
}

.workspace_premissions_edit_line {
    width: 50%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 15px;
    font-weight: 400;
    color: #78859D;
    margin-bottom: 15px;
    margin-left: 20px;
}

.workspace_premissions_edit_line select {
    padding: 5px 10px;
    border: none;
    background: #E1E6F0;
    color: #78859D;
    font-size: 13px;
    font-weight: 500;
    font-family: Inter;
    border-radius: 5px;
    margin-left: 10px;
}



</style>
    <body>

        <div class="workspace_premissions_edit">
        <div class="workspace_premissions_edit_title">Page creation restrictions</div>
        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For public board</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For Private Page</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For Workspace visible Page</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        
        <div class="workspace_premissions_edit_title">Page Deletion restrictions</div>
        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For public board</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For Private Page</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">For Workspace visible Page</div>
            <select>
                <option>Anyone</option>
                <option>Admin</option>
                <option>Nobody</option>
            </select>
        </div>

        
        <div class="workspace_premissions_edit_title">Sharing Pages with guests</div>

        <div class="workspace_premissions_edit_line">
            <div class="workspace_premissions_edit_txt">Who can send or accept invitations?</div>
            <select>
                <option>Anyone</option>
                <option>Only workspace members</option>
            </select>
        </div>

        </div>
    

    </body>
</html>