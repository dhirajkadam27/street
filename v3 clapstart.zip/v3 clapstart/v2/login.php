<?php
   session_start();
   
   // Check if a specific session variable is set
   if (isset($_SESSION['email'])) {
       header("Location: apps.php");
   exit; 
   }
   
   ?>
<html>
    <head>
        <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
        <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
        <link rel="stylesheet" href="./assets/components/index.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
              rel="stylesheet">
              <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
                    rel="stylesheet">
        <style>
            body{
                margin: 0;
                padding: 0;
                background-image: url('https://4kwallpapers.com/images/wallpapers/ipados-stock-orange-white-background-ipad-ios-13-hd-1600x900-1551.jpg');
                background-size: cover;
    font-family: -apple-system, BlinkMacSystemFont, Inter, "Helvetica Neue", Helvetica, Arial, sans-serif;
            }
        </style>
    </head>
    <body>
        <button redirect="clapstart_landing">Home</button>
        <button auth="google">Login with Google</button>
        <button auth="apple">Login with Apple</button>

        

        <div id="components"></div>
        <script type="module">
            var stream = null;
            // Import the functions you need from the SDKs you need
            import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
            import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-analytics.js";
            // TODO: Add SDKs for Firebase products that you want to use
            // https://firebase.google.com/docs/web/setup#available-libraries
            
            // Your web app's Firebase configuration
            // For Firebase JS SDK v7.20.0 and later, measurementId is optional
            const firebaseConfig = {
            apiKey: "AIzaSyABfZ1GZ9Eti6e50EgOGkQqJ1s5nzCoIRc",
            authDomain: "clapstart-1492e.firebaseapp.com",
            projectId: "clapstart-1492e",
            storageBucket: "clapstart-1492e.appspot.com",
            messagingSenderId: "953994364799",
            appId: "1:953994364799:web:5269e513f208af7fca3c4a",
            measurementId: "G-HLT4ZP6LHC"
            };
            
            // Initialize Firebase
            const app = initializeApp(firebaseConfig);
            const analytics = getAnalytics(app);
            
            
            // Initialize Firebase
            firebase.initializeApp(firebaseConfig);
            </script>
        
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="./assets/js/clapstart.js"></script>
    </body>
</html>