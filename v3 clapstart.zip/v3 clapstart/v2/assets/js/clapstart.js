const clapstart_landing = "/";
const street_landing = "/street.html";
const login = "/login.php";
const create_account = "/get-started.php";

const paths = {
	clapstart_landing,
	street_landing,
	login,
	create_account
}


$.ajax({
	url: "/assets/components/index.html",
	type: "GET",
	dataType: "html",
	success: function(response) {
	  // The response contains the HTML content from the file
	  $("#components").html(response);
	},
	error: function(xhr, status, error) {
	  console.error("Error loading content:", error);
	}
  });


$('button').on('click', function() {
	const redirectPath = $(this).attr('redirect');
	const auth = $(this).attr('auth');
	if (redirectPath) {
		loader();
		if(redirectPath=="reload"){
			location.reload();
		}else{
			setTimeout(() => {
				window.location.href = paths[redirectPath];
			}, 1000);
		}
	}
	if (auth) {
		console.log(auth);
		if (auth == "google") {
			loader();
			google();
		}
		if (auth == "apple") {
			loader();
			apple();
		}
	}
});

function google() {
	const googleProvider = new firebase.auth.GoogleAuthProvider();
	firebase.auth().signInWithPopup(googleProvider).then((result) => {
		close_loader();
		const user = result.user;
		console.log('Signed in with Google:', user.email);
		account(user.email);
	}).catch((error) => {
		close_loader();
		oops();
		console.log('Something went wrong1');
	});
}

function apple() {
	const appleProvider = new firebase.auth.OAuthProvider('apple.com');
	firebase.auth().signInWithPopup(appleProvider).then((result) => {
		close_loader();
		const user = result.user;
		console.log('Signed in with Apple:', user.email);
		account(user.email);

	}).catch((error) => {
		close_loader();
		oops();
		console('Something went wrong');
	});
}

function account(email) {
	$.ajax({
		url: "/api/clapstart/account/account.php",
		type: "GET",
		data: {
			email: email
		},
		dataType: 'text',
		success: function(response) {
			if(response=="Email not found"){

			}else if(response=="Login"){
				
			}else if(response=="Account setup"){
				
			}else if(response=="Failed to create account"){
				
			}else{
				
			}
		},
		error: function(xhr, status, error) {
			console.log('Unable to connect the server');
		}
	});
}

function loader(){
	$('#blur').css('display','flex');
	$('#loading').css('display','flex');
}

function close_loader(){
	$('#blur').css('display','none');
	$('#loading').css('display','none');
}


function oops(){
	$('#blur').css('display','flex');
	$('#oops_popup').css('display','flex');
}


function close_oops(){
	$('#blur').css('display','none');
	$('#oops_popup').css('display','none');
}

