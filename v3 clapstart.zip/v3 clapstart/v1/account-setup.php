<?php
   include './api/config.php';
   
   
   // Check if a specific session variable is set
   if (!isset($_SESSION['email'])) {
       header("Location: login.php");
   exit; 
   }
   
   // Check if a specific session variable is set
   if (isset($_SESSION['username'])) {
       header("Location: apps.php");
   exit; 
   }
   $email = $_SESSION['email'];
   
   ?>
<html>
   <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
         rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
         rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: 'Inter', sans-serif;
         background: white;
         text-align: center;
         }
         img.logo {
         height: 40px;
         margin-top: 45px;
         }
         .title {
         margin-top: 50px;
         margin-bottom: 30px;
         color: #78859D;
         font-size: 25px;
         font-weight: 700;
         }
         form {width: 380px;margin: 10px auto;text-align: left;}
         label {
         display: block;
         color: #78859D;
         font-size: 12px;
         font-weight: 600;
         margin-top: 25px;
         margin-bottom: 5px;
         }
         input {
         width: 380px;
         height: 40px;
         border-radius: 5px;
         border: 1px solid #C5E1FF;
         background: #EAF4FF;
         padding: 10px;
         color: #526587;
         font-size: 12px;
         font-weight: 600;
         font-family: 'Inter', sans-serif;
         outline-color: #5ea4ef;
         }
         .btn {
         width: 380px;
         height: 40px;
         border-radius: 5px;
         background: #2698F0;
         display: flex;
         align-items: center;
         justify-content: center;
         color: #FFF;
         font-size: 15px;
         font-weight: 600;
         margin: 0px auto;
         margin-top: 30px;
         }
      </style>
   </head>
   <body>
      <img class="logo" src="./assets/logo/logo.svg">
      <div class="title">Account setup</div>
      <form>
         <label>Email</label>
         <input disabled value="<?php echo $email; ?>">
         <label>Full name</label>
         <input id="name" value="">
         <label>Username</label>
         <input id="username" value="">
      </form>
      <div onclick="create()" class="btn">Create</div>
      <script>
         function create(){
         $.ajax({
           url: "./api/account_setup.php",
           type: "POST",
           credentials: "include", 
           data: { name: document.getElementById('name').value,username:document.getElementById('username').value},
           dataType: 'text',
           success: function(response) {
             if(response=="Name not found"){
             console.log('Name not found');
             }else if(response=="Username not found"){
             console.log('Username not found');
             }else if(response=="Account Setup"){
               window.location.href = "apps.php";
             }else if(response=="Failed to Setup Account"){
             console.log('Failed to Setup Account');
             }else{
             console.log('Something went wrong');
             }
           },
           error: function(xhr, status, error) {
             console.log('Something went wrong');
           }
         });
         }
         
      </script>
   </body>
</html>