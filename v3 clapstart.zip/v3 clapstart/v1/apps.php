<?php
   session_start();
   
   // Check if a specific session variable is set
   if (!isset($_SESSION['email'])) {
       header("Location: login.php");
   exit; 
   }
   
   
   // Check if a specific session variable is set
   if (!isset($_SESSION['username'])) {
       header("Location: account-setup.php");
   exit; 
   }
   
   ?>
<html>
   <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
         rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
         rel="stylesheet">
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: 'Inter', sans-serif;
         background: #F0F2F7;
         text-align: center;
         }
         .nav {
         display: flex;
         align-items: center;
         justify-content: space-between;
         padding: 0px 20px;
         margin-top: 30px;
         }
         .nav img {
         height: 50px;
         }
         .profile:nth-child(1) {
         background: transparent;
         }
         .profile {
         width: 50px;
         height: 50px;
         background: #9A35FF;
         border-radius: 100px;
         font-size: 20px;
         font-weight: 600;
         color: white;
         display: flex;
         align-items: center;
         justify-content: center;
         cursor: pointer;
         }
         .main {
         width: 92%;
         height: 70vh;
         border-radius: 10px;
         background: #FFF;
         box-shadow: 0px 0px 20px 0px rgba(221, 221, 221, 0.25);
         margin: 10px auto;
         margin-top: 50px;
         padding: 2%;
         display: flex;
         }
         .btn {
         border-radius: 10px;
         border: 2px solid #EDF0F7;
         display: flex;
         align-items: center;
         justify-content: center;
         height: fit-content;
         padding: 12px;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         }
         .btn:hover{
         background: #f6f9ff;
         transform: scale(1.05); 
         }
         .btn img {
         width: 50px;
         height: 50px;
         margin-right: 15px;
         }
         .info {
         text-align: left;
         }
         .name {
         color: #001930;
         font-size: 30px;
         font-weight: 700;
         }
         .type {
         color: #7D8EAC;
         font-size: 12px;
         font-weight: 700;
         }
      </style>
   </head>
   <body>
      <div class="nav">
         <div class="profile"></div>
         <img class="logo" src="./logo.svg">
         <div class="profile">D</div>
      </div>
      <div class="main">
         <div class="btn">
            <img src="./street.svg">
            <div class="info">
               <div class="name">Street</div>
               <div class="type">A Project Management tool</div>
            </div>
         </div>
      </div>
   </body>
</html>