<html>
   <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
         rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
         rel="stylesheet">
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: 'Inter', sans-serif;
         background: #fff;
         background-image: url(./bg.svg);
         background-size: cover;
         }
         .nav {
         display: flex;
         align-items: center;
         justify-content: space-between;
         padding: 0px 5%;
         margin-top: 30px;
         }
         .nav img {
         height: 40px;
         border: 3px solid white;
         border-radius: 5px;
         cursor: pointer;
         }
         .login {
         background: #fff;
         border-radius: 2px;
         color: #001930;
         padding: 5px 15px;
         font-size: 15px;
         font-weight: 600;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .login:hover{
         transform: scale(1.03); 
         }
         .tagline {
         color: #001930;
         font-size: 50px;
         font-weight: 700;
         text-align: center;
         margin-top: 20vh;
         }
         .desc {
         color: #fff;
         font-size: 15px;
         font-weight: 600;
         text-align: center;
         margin-top: 10px;
         }
         .btn {
         background: #001930;
         border-radius: 2px;
         color: #fff;
         padding: 10px 25px;
         font-size: 15px;
         font-weight: 600;
         width: fit-content;
         margin: 10px auto;
         margin-top: 30px;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .btn:hover{
         transform: scale(1.03); 
         }
         .label {
         color: #FFF;
         font-size: 20px;
         font-weight: 700;
         margin-left: 5%;
         margin-top: 100px;
         }
         .product {
         border-radius: 10px;
         border: 2px solid #EDF0F7;
         background: rgba(255, 255, 255, 0.18);
         display: flex;
         align-items: center;
         justify-content: center;
         width: fit-content;
         height: fit-content;
         padding: 12px;
         margin-left: 5%;
         margin-top: 10px;
         margin-bottom: 10vh;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .product:hover{
         transform: scale(1.05); 
         }
         .product img {
         width: 50px;
         height: 50px;
         margin-right: 15px;
         }
         .info {
         text-align: left;
         }
         .name {
         color: #fff;
         font-size: 30px;
         font-weight: 700;
         }
         .type {
         color: #fff;
         font-size: 12px;
         font-weight: 700;
         }
      </style>
   </head>
   <body>
      <div class="nav">
         <img onclick="window.location.href='./'" class="logo" src="./assets/logo/logo.svg">
         <div onclick="window.location.href='./login.php'" class="login">Login</div>
      </div>
      <div class="tagline">Your Vision, Our Solutions</div>
      <div class="desc">Empowering businesses with innovative software solutions to streamline operations, boost productivity, and achieve growth</div>
      <div onclick="window.location.href='./get-started.php'" class="btn">Create your account for free</div>
      <div class="label">Product</div>
      <div onclick="window.location.href='./street.php'" class="product">
         <img src="./assets/logo/street.svg">
         <div class="info">
            <div class="name">Street</div>
            <div class="type">A Project Management tool</div>
         </div>
      </div>
   </body>
</html>