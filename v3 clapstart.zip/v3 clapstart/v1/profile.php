<?php
   include './api/config.php';
   
   
   // Check if a specific session variable is set
   if (!isset($_SESSION['email'])) {
       header("Location: login.php");
   exit; 
   }else{
       $email =$_SESSION['email'];
   }
   
   
     // Prepare the SELECT query
     $sql = "SELECT * FROM users WHERE email = '$email'";
   
     // Execute the query
     $result = mysqli_query($conn, $sql);
   
     // Check if any rows were returned
     if (mysqli_num_rows($result) > 0) {
         // Email exists in the record
         $row = mysqli_fetch_assoc($result);
         $username = $row['username'];
         $name = $row['name'];
     
     } else {
         // Email is not present in the record
         $username = "";
         $name = "";
     }
   
   ?>
<html>
   <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
         rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
         rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: 'Inter', sans-serif;
         background: #F0F2F7;
         text-align: center;
         }
         .nav {
         display: flex;
         align-items: center;
         justify-content: space-between;
         padding: 0px 20px;
         margin-top: 30px;
         }
         .back {
         display: flex;
         align-items: center;
         padding: 5px;
         border-radius: 5px;
         color: #526587;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         margin-left: 10px;
         }
         .back:hover{
         background: #ffffff;
         }
         .back span {
         font-size: 10px;
         margin-right: 5px;
         color: #526587;
         }
         .nav img {
         height: 50px;
         }
         .profile {
         width: 50px;
         height: 50px;
         background: #9A35FF;
         border-radius: 100px;
         font-size: 20px;
         font-weight: 600;
         color: white;
         display: flex;
         align-items: center;
         justify-content: center;
         cursor: pointer;
         margin-right: 10px;
         }
         .main {
         width: 92%;
         height: 70vh;
         border-radius: 10px;
         background: #FFF;
         box-shadow: 0px 0px 20px 0px rgba(221, 221, 221, 0.25);
         margin: 10px auto;
         margin-top: 50px;
         padding: 2%;
         display: block;
         text-align: left;
         }
         .title {color: #001930;font-size: 25px;font-weight: 700;}
         .data {
         display: flex;
         justify-content: start;
         }
         .txt {
         width: 60%;
         }
         label {
         display: block;
         color: #78859D;
         font-size: 12px;
         font-weight: 600;
         margin-top: 25px;
         margin-bottom: 5px;
         }
         .input {
         display: flex;
         }
         input {
         width: 380px;
         height: 40px;
         border-radius: 5px;
         border: 1px solid #C5E1FF;
         background: #EAF4FF;
         padding: 10px;
         color: #526587;
         font-size: 12px;
         font-weight: 600;
         font-family: 'Inter', sans-serif;
         outline-color: #5ea4ef;
         }
         .input .btn{
         margin-top: 0px;
         margin-left: 10px;
         display: flex;
         align-items: center;
         }
         .img .profile{
         background: #9A35FF;
         width: 80px;
         height: 80px;
         }
         .btn {
         width: fit-content;
         padding: 5px 10px;
         background: #2698F0;
         border-radius: 5px;
         font-size: 15px;
         font-weight: 500;
         color: white;
         margin-top: 20px;
         cursor: pointer;
         transition: all .2s ease-in-out; 
         }
         #btn1 , #btn2{
         display: none;
         }
         .btn:hover{
         transform: scale(1.05); 
         }
         .delete {
         color: #ff0d0d;
         margin-top: 20px;
         font-size: 12px;
         font-weight: 500;
         cursor: pointer;
         padding: 5px;
         width: fit-content;
         border-radius: 5px;
         }
         .delete:hover{
         background: #fff4f4;
         }
      </style>
   </head>
   <body>
      <div class="nav">
         <div class="back"><span class="material-icons-outlined">arrow_back_ios</span>Back</div>
         <img class="logo" src="./logo.svg">
         <div class="profile">D</div>
      </div>
      <div class="main">
         <div class="title">Profile</div>
         <div class="data">
            <div class="txt">
               <label>Full name</label>
               <div class="input">
                  <input id="input1" value="<?php echo $name; ?>">
                  <div class="btn" id="btn1">Save</div>
               </div>
               <label>Username</label>
               <div class="input">
                  <input id="input2" value="<?php echo $username; ?>">
                  <div class="btn" id="btn2">Save</div>
               </div>
               <div class="delete">Delete your account</div>
            </div>
            <div class="icon">
               <div class="img">
                  <div class="profile">D</div>
               </div>
               <div class="btn">Change</div>
            </div>
         </div>
      </div>
      <script>
         document.getElementById("input1").addEventListener("input", function() {
           if (document.getElementById("input1").value != "<?php echo $name; ?>") {
                         document.getElementById("btn1").style.display = "flex";
           } else {
                         document.getElementById("btn1").style.display = "none";
           }
         });
         
         document.getElementById("input2").addEventListener("input", function() {
           if (document.getElementById("input2").value != "<?php echo $username; ?>") {
                         document.getElementById("btn2").style.display = "flex";
           } else {
                         document.getElementById("btn2").style.display = "none";
           }
         });
         
         document.getElementById("btn1").addEventListener("click", function() {
             $.ajax({
           url: "./api/profile_name.php",
           type: "POST",
           credentials: "include", 
           data: { name: document.getElementById("input1").value},
           success: function(response) {
             if(response=="Changed"){
             console.log('Changed');
             }else if(response=="Failed to changed"){
             console.log('Failed to changed');
             }else{
             console.log('Something went wrong');
             }
           },
           error: function(xhr, status, error) {
             console.log('Something went wrong');
           }
         });
         });
         
         
         document.getElementById("btn2").addEventListener("click", function() {
             $.ajax({
           url: "./api/profile_username.php",
           type: "POST",
           credentials: "include", 
           data: { username: document.getElementById("input2").value},
           success: function(response) {
             if(response=="Changed"){
             console.log('Changed');
             }else if(response=="Failed to changed"){
             console.log('Failed to changed');
             }else{
             console.log('Something went wrong');
             }
           },
           error: function(xhr, status, error) {
             console.log('Something went wrong');
           }
         });
         });
         
                 
      </script>
   </body>
</html>