<?php
   session_start();
   
   // Check if a specific session variable is set
   if (isset($_SESSION['email'])) {
       header("Location: apps.php");
   exit; 
   }
   
   ?>
<html>
   <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;600;700;800;900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
         rel="stylesheet">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
         rel="stylesheet">
      <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
      <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      <style>
         body{
         margin: 0;
         padding: 0;
         font-family: 'Inter', sans-serif;
         background: white;
         text-align: center;
         }
         img.logo {
         height: 40px;
         margin-top: 45px;
         cursor: pointer;
         }
         .title {
         margin-top: 50px;
         margin-bottom: 30px;
         color: #78859D;
         font-size: 25px;
         font-weight: 700;
         }
         .btn {
         width: 350px;
         height: 40px;
         display: flex;
         align-items: center;
         justify-content: center;
         margin: 20px auto;
         background: #EAF4FF;
         border-radius: 5px;
         border: 1px solid #C5E1FF;
         cursor: pointer;
         color: #526587;
         font-size: 15px;
         font-weight: 600;
         transition: all .2s ease-in-out;
         }
         .btn:hover{
         transform: scale(1.03); 
         }
         .btn img {
         height: 20px;
         margin-right: 10px;
         }
         .links {
         margin-top: 30px;
         color: #78859D;
         font-size: 15px;
         font-weight: 500;
         display: flex;
         justify-content: center;
         }
         .links div {
         color: #2E71EB;
         font-weight: 600;
         cursor: pointer;
         transition: all .2s ease-in-out;
         }
         .links div:hover{
         color: #1553c5;
         }
      </style>
   </head>
   <body>
      <img onclick="window.location.href='./'" class="logo" src="./assets/logo/logo.svg">
      <div class="title">Login into your account</div>
      <div id="google" class="btn"><img src="./assets/brand/google.webp">Sign in with google</div>
      <div id="apple" class="btn"><img src="./assets/brand/apple.svg">Sign in with apple</div>
      <div class="links">
         I don't have a account,&nbsp;
         <div onclick="window.location.href='./get-started.php'">create a new account</div>
      </div>
      <script type="module">
         var stream = null;
         // Import the functions you need from the SDKs you need
         import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
         import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-analytics.js";
         // TODO: Add SDKs for Firebase products that you want to use
         // https://firebase.google.com/docs/web/setup#available-libraries
         
         // Your web app's Firebase configuration
         // For Firebase JS SDK v7.20.0 and later, measurementId is optional
         const firebaseConfig = {
         apiKey: "AIzaSyABfZ1GZ9Eti6e50EgOGkQqJ1s5nzCoIRc",
         authDomain: "clapstart-1492e.firebaseapp.com",
         projectId: "clapstart-1492e",
         storageBucket: "clapstart-1492e.appspot.com",
         messagingSenderId: "953994364799",
         appId: "1:953994364799:web:5269e513f208af7fca3c4a",
         measurementId: "G-HLT4ZP6LHC"
         };
         
         // Initialize Firebase
         const app = initializeApp(firebaseConfig);
         const analytics = getAnalytics(app);
         
         
         // Initialize Firebase
         firebase.initializeApp(firebaseConfig);
         
         // Google sign-in
         const googleProvider = new firebase.auth.GoogleAuthProvider();
         function google() {
         firebase.auth().signInWithPopup(googleProvider)
         .then((result) => {
           // Handle successful sign-in
           const user = result.user;
           console.log('Signed in with Google:', user.email);
         
           $.ajax({
         url: "./api/account.php",
         type: "POST",
         credentials: "include", 
         data: { email: user.email},
         success: function(response) {
         if(response=="Email not found"){
         console.log('Email not found');
         }else if(response=="User Loged in"){
           window.location.href = "apps.php";
         }else if(response=="User Account setup"){
           window.location.href = "account-setup.php";
         }else if(response=="Failed to create account"){
         console.log('Failed to create account');
         }else if(response=="Account created"){
           window.location.href = "account-setup.php";
         }else{
         console.log('Something went wrong');
         }
         },
         error: function(xhr, status, error) {
         console.log('Something went wrong');
         }
         });
         
         
         })
         .catch((error) => {
           // Handle errors
         console.log('Something went wrong1');
         });
         }
         
         // GitHub sign-in
         const appleProvider = new firebase.auth.OAuthProvider('apple.com');
         function apple() {
         firebase.auth().signInWithPopup(appleProvider)
         .then((result) => {
           // Handle successful sign-in
           const user = result.user;
           console.log('Signed in with Apple:', user.email);
         
         })
         .catch((error) => {
           // Handle errors
         console('Something went wrong');
         });
         }
         
         
         document.getElementById('google').addEventListener('click', () => {
         google();
         });
         document.getElementById('apple').addEventListener('click', () => {
         apple();
         });
         
         
         
      </script>
   </body>
</html>