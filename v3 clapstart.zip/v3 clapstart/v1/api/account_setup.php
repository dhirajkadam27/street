<?php
   include './config.php';
   
   $email = $_SESSION['email'];
   $username = false;
   $name = false;
   
   if(isset($_POST['username'])){
       $username = $_POST['username'];
   }
   if(isset($_POST['name'])){
       $name = $_POST['name'];
   }
   
   
   
   function accountSetup($conn, $email,$name,$username){
       // Prepare the UPDATE query
       $sql = "UPDATE users SET name = '$name', username = '$username' WHERE email = '$email'";
   
       // Execute the query
       if (mysqli_query($conn, $sql)) {
           $_SESSION['username'] = $username;
           echo "Account Setup";
       } else {
           echo "Failed to Setup Account";
       }
   }
   
   if($username!=false){
       if($name!=false){
           accountSetup($conn, $email, $name, $username);
       }else{
           echo "Name not found";
       }
   }else{
       echo "Username not found";
   }
   
   
   ?>