<?php
   include './config.php';
   
   $email = $_SESSION['email'];
   
   if(isset($_POST['username'])){
       $username = $_POST['username'];
       accountSetup($conn, $username,$email);
   }else{
       echo "Name not found";
   }
   
   
   
   function accountSetup($conn,$username,$email){
       // Prepare the UPDATE query
       $sql = "UPDATE users SET username = '$username' WHERE email = '$email'";
   
       // Execute the query
       if (mysqli_query($conn, $sql)) {
           echo "Changed";
       } else {
           echo "Failed to changed";
       }
   }
   
   
   ?>