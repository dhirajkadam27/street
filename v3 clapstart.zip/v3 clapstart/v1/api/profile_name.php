<?php
   include './config.php';
   
   $email = $_SESSION['email'];
   
   if(isset($_POST['name'])){
       $name = $_POST['name'];
       accountSetup($conn, $name, $email);
   }else{
       echo "Name not found";
   }
   
   
   
   function accountSetup($conn,$name,$email){
       // Prepare the UPDATE query
       $sql = "UPDATE users SET name = '$name' WHERE email = '$email'";
   
       // Execute the query
       if (mysqli_query($conn, $sql)) {
           echo "Changed";
       } else {
           echo "Failed to changed";
       }
   }
   
   
   ?>