<?php
   include './config.php';
   
   
   if(isset($_POST['email'])){
       $email = $_POST['email'];
       if(isEmailPresent($conn, $email)){
           isAccountSetup($conn, $email);
       }else{
           accountCreate($conn, $email);
       }
   }else{
       echo "Email not found";
   }
   
   function isEmailPresent($conn, $email) {
   
       // Prepare the SELECT query
       $sql = "SELECT * FROM users WHERE email = '$email'";
   
       // Execute the query
       $result = mysqli_query($conn, $sql);
   
       // Check if any rows were returned
       if (mysqli_num_rows($result) > 0) {
           // Email exists in the record
           return true;
       } else {
           // Email is not present in the record
           return false;
       }
   }
   
   function isAccountSetup($conn, $email) {
   
       // Prepare the SELECT query
       $sql = "SELECT * FROM users WHERE email = '$email'";
   
       // Execute the query
       $result = mysqli_query($conn, $sql);
   
       // Check if any rows were returned
       if (mysqli_num_rows($result) > 0) {
           // Email exists in the record
           $row = mysqli_fetch_assoc($result);
           if($row['username']==''){
               echo "User Account setup";
               $_SESSION['email'] = $email;
           }else{
               $_SESSION['username'] = $row['username'];
               $_SESSION['email'] = $email;
               echo "User Loged in";
           }
       } else {
           // Email is not present in the record
           accountCreate($conn, $email);
       }
   }
   
   function accountCreate($conn, $email){
       $sql = "INSERT INTO users (email,creation_log) VALUES ('$email', NOW())";
   
       // Execute the query
       if (mysqli_query($conn, $sql)) {
           echo "Account created";
           $_SESSION['email'] = $email;
       } else {
           echo "Failed to create account";
       }
   }
   
   
   ?>